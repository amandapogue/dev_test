
initLogger = function(vignetteName) {
	logDirectory = Sys.getenv("SB_VIGNETTE_LOG_DIR")
	if(logDirectory == "") {
		logDirectory = "."
	}
	
	logFileName = paste(logDirectory,"vignette.log",sep = "/")
	startTime = Sys.time()
	
	line = paste(startTime, "- Start", vignetteName, "vignette generation")
	write(line, file=logFileName, append=TRUE)
	
	logChunk = function(before, options, envir) {
		if (before) {
			startTime = Sys.time()
			
			line = paste(startTime, "- Start generation of chunk", options$label)
			
			write(line, file=logFileName, append=TRUE)
			
			
		} else {
			endTime = Sys.time()
			
			line = paste(endTime, "- Complete generation of chunk", options$label, "took:", format(endTime - startTime))
			
			write(line, file=logFileName, append=TRUE)
		}
	}
	
	knitr::knit_hooks$set(logChunk = logChunk)

	# Use cairo png device to record plots, otherwise X11 is needed and we don't want X11 because it's flaky:
	knitr::opts_chunk$set(logChunk = TRUE, dev = "CairoPNG")
}
