#' distinctBy
#'
#' Keep only distinct rows in the input as specified by parameter "by". When multiple rows are encountered for a certain combination the first row will be selected.
#' @param data: dataframe or data.table to be grouped
#' @param by: a list of column names to distinct by
#' @return a new data.table object with the distinct data
distinctBy = function(data, by) {
  grouped = groupBy(data, by)
  flattenCols(grouped, names(grouped))  #flatten all columns
  grouped
}


#' groupBy
#'
#' group the input data by certain columns. The output will be an object of type data.table in which each cell will contain a list of items.
#' @param data: dataframe or data.table to be grouped
#' @param keys: a list of column names to perform the groupBy
#' @param flatten: a boolean indicator for whether to flatten (into a vector) columns that after grouping are of size 1 for all keys. TRUE by default.
#' @return a new data.table object with the grouped data
#' @examples
#' grouped = groupBy(getData("titanic_train"), by ="pclass")
#' rownames(grouped)
#' colSizes(grouped)
#' head(grouped)
#' grouped2 = groupBy(getData("titanic_train"), by =list("pclass","sex"))
#' rownames(grouped2)
#' colSizes(grouped2)
#' head(grouped2)
groupBy = function(data, by, flatten = TRUE) {
  text = paste0("list(",paste(by, collapse = ","),")")
  data = data.table::as.data.table(data)
  grouped = data[,lapply(.SD,list), by = eval(parse(text = text))]

  #flatten when single value
  if (flatten) {
    rowsCount = nrow(grouped)
    #toFlatten = setdiff(names(which(rowsCount == apply(colSizes(grouped), 2, sum))), by)
    toFlatten = setdiff(names(which(rowsCount == apply(colSizesUnique(grouped), 2, sum) )), by)
    if (length(toFlatten) > 0) flattenCols(grouped, toFlatten)
  }
  grouped
}


#' colSizes
#'
#' Count the number of items in each column
#' @param data dataframe / data.table to be examined
#' @return a summary of items counts per row
#' @examples
#' grouped = groupBy(getData("titanic_train"), by ="pclass")
#' rownames(grouped)
#' colSizes(grouped)
#' head(grouped)
#' grouped2 = groupBy(getData("titanic_train"), by =list("pclass","sex"))
#' rownames(grouped2)
#' colSizes(grouped2)
#' head(grouped2)
colSizes = function(data) {
  colLengthFunc = function(y) {length(unlist(y))}
  sizes = sapply(data, function(x) sapply(x, function(y) colLengthFunc(y)), simplify = TRUE)
  rownames(sizes) = rownames(data)
  sizes
}

#' colSizesUnique
#'
#' Count the unique number of items in each column
#' @param data dataframe / data.table to be examined
#' @return a summary of unique items counts per row
#' @examples
#' grouped = groupBy(getData("titanic_train"), by ="pclass")
#' rownames(grouped)
#' colSizes(grouped)
#' colSizesUnique(grouped)
#' head(grouped)
#' grouped2 = groupBy(getData("titanic_train"), by =list("pclass","sex"))
#' rownames(grouped2)
#' colSizes(grouped2)
#' colSizesUnique(grouped2)
#' head(grouped2)
colSizesUnique = function(data) {
  colLengthFunc = function(y) {length(unique(unlist(y)))}
  sizes = sapply(data, function(x) sapply(x, function(y) colLengthFunc(y)), simplify = TRUE)
  rownames(sizes) = rownames(data)
  sizes
}


#' flattenCols
#'
#' Take the only the first element from each column defined in \code{cols} and set the column type into a vector
#' @param data: data.table to flatten
#' @param cols: list of columns to flatten
#' @param keepLast: Boolean. Indicates whether to keep the first or last element in the series.
#' @return nothing: operates on the input data object
#' @examples
#' grouped = groupBy(getData("titanic_train"), by =list("pclass","sex"))
#' typeof(grouped$age)
#' flattenCols(grouped, "age")
#' typeof(grouped$age) ## notice that the type of the column changed
flattenCols = function(data, cols, keepLast = FALSE) {
  flattenCol = function(data, colName) {
    if (!keepLast)
      data[,eval(as.symbol(colName)) := sapply(eval(as.symbol(colName)),`[[`,1,simplify = TRUE)]
    else
      data[,eval(as.symbol(colName)) := sapply(eval(as.symbol(colName)),last,simplify = TRUE)]
  }
  for (col in cols) {flattenCol(data,col)} # can possibly be written without the loop
}

#' typeofCols
#'
#' list the type of column for all columns in the input \code{data}
#' @param data: data.table to examine.
#' @return a vector of names for all \code{data} columns
#' @examples
#' grouped = groupBy(getData("titanic_train"), by =list("pclass","sex"))
#' typeofCols(grouped$age)
#' flattenCols(grouped, "age")
#' typeofCols(grouped)
typeofCols = function(data) {
  sapply(data, typeof)
}

#' classofCols
#'
#' list the class of column for all columns in the input \code{data}
#' @param data: data.table to examine.
#' @return a vector of names for all \code{data} columns
#' @examples
#' grouped = groupBy(getData("titanic_train"), by =list("pclass","sex"))
#' classofCols(grouped$age)
#' flattenCols(grouped, "age")
#' classofCols(grouped)
classofCols = function(data) {
	sapply(data, class)
}

#' writeToFile
#'
#' Convert all \code{data} columns into a serializable text/primitive representation and write them to a tab separated file.
#' @param data dataframe / data data.table to write.
#' @param useEscaping A binary indicator noting whether a forward slash in the data needs to be escaped
#' @examples
#' grouped = groupBy(getData("titanic_train"), by =list("pclass","sex"))
#' writeToFile(grouped, "titanic_grouped.tsv")
writeToFile = function(data, outputFile, useEscaping = TRUE) { #sugar for writing grouped data
  toWrite = cols2Text(data, useEscaping)
  write.table(toWrite, file = outputFile, sep = "\t", row.names = FALSE, quote = FALSE)
}

#' setTimeColumn
#'
#' Rename a requested column to "SB_times_col". When the exported data is read by the SparkBeyond engine, all other columns that contain lists that are of the same size as of the list in "SB_times_col" will be converted into time series data structures.
#' @param data: the dataframe / data.table to be modified.
#' @param timeCol: The column name in \code{data} to be renamed.
setTimeColumn = function(data, timeCol) { #assumption is can be called only if the data is grouped already, hence a data.table
  if (!timeCol %in% names(data)) stop(paste("error:", timeCol, "does not exist"))
  if ("SB_times_col" %in% names(data)) stop("error: time column is already defined")
  setnames(data, timeCol, "SB_times_col")
}

#' limitTimeSeries
#'
#' filter rows to contain only rows that are in a certain time frame based on a from/until date inputs (inclusive). All dates are assumed to be of the same format. This function should be called before any filtering is performed.
#'
#' @param data: the dataframe / data.table to be modified.
#' @param dateCol: The column name in \code{data} that will be used for filtering. "SB_times_col" by default
#' @param fromDate: The starting date to filter from. NA by default.
#' @param untilData: The end date to filter until. NA by default.
#' @param datesFormat: the format of the from/until dates.month/day/year by default.
#' @return a new data.table with the filtered rows will be returned.
#' @examples
#' randDate <- function(N, st="2014/01/01", et="2014/12/31") {
#'  st <- as.POSIXct(as.Date(st,tz = "EST"),tz = "EST")
#'  et <- as.POSIXct(as.Date(et,tz = "EST"),tz = "EST")
#'  dt <- as.numeric(difftime(et,st,unit="secs"))
#'  ev <- sort(runif(N, 0, dt))
#'  strftime(st+ev, format="%m/%d/%Y")
#' }
#' simulateData = function(n = 100, l = 10) {
#'  data.table(ID = rep(1:n,l), value = rnorm(n*l), date = randDate(n*l))
#' }
#' tsData = simulateData()
#' head(tsData)
#' nrow(tsData)
#' nrow(limitTimeSeries(tsData, "date", fromDate ="07/01/2014"))
#' nrow(limitTimeSeries(tsData, "date", untilDate ="11/01/2014"))
#' nrow(limitTimeSeries(tsData, "date", fromDate="07/01/2014", untilDate ="11/01/2014"))
limitTimeSeries = function(data, dateCol = "SB_times_col", fromDate = NA, untilDate = NA, datesFormat = "%m/%d/%Y") {
  fromDateFormatted = strptime(fromDate, datesFormat)
  untilDateFormatted = strptime(untilDate, datesFormat)

  if (is.na(fromDate) && !is.na(untilDate)) {
    data[strptime(eval(as.symbol(dateCol)), datesFormat) <= untilDateFormatted]
  } else if (!is.na(fromDate) && is.na(untilDate)) {
    data[strptime(eval(as.symbol(dateCol)), datesFormat) >= fromDateFormatted]
  } else if (!is.na(fromDate) && !is.na(untilDate))
    data[strptime(eval(as.symbol(dateCol)), datesFormat) >= fromDateFormatted & strptime(eval(as.symbol(dateCol)), datesFormat) <= untilDateFormatted]
}

#' offsetTime
#'
#' Offsets a time-date column by a reference date to create a relative time series with respect to the reference date. Currently work only on data.table
#'
#' @param data: data.table to be modified.
#' @param dateCol: The column name in \code{data} that will be modified. "SB_times_col" by default
#' @param refDate: The reference date to use.
#' @param datesFormat: the format of the from/until dates. "\%m/\%d/\%Y" by default.
#' @param units: the time span unit to use when creating the reference. Based on \code{\link[base]{difftime}} definitions. "days" by default.
#' @return NA will be returned and the input file will be modified.
offsetTime = function(data, dateCol = "SB_times_col", refDate, datesFormat = "%m/%d/%Y", units = "days") {
  ref = strptime(refDate, datesFormat)

  offsetDateInternal = function(colDate) {
    d = strptime(colDate, datesFormat)
    difftime(d, ref, units = units)
  }

  data[,eval(as.symbol(dateCol)) := sapply(eval(as.symbol(dateCol)),offsetDateInternal)]
  NA
}

#' join
#'
#' Joins two dataframes. Wrapper around data.table's \code{\link[data.table]{merge}}. It is required that the join will be on a unique set of keys, and that the join key columns will have the same name in both inputs.
#' @param x, y: data tables. y is coerced to a data.table if it isn't one already.
#' @param all: logical; all = TRUE is shorthand to save setting both all.x = TRUE and all.y = TRUE.
#' @param all.x: logical; if TRUE, then extra rows will be added to the output, one for each row in x that has no matching row in y. These rows will have 'NA's in those columns that are usually filled with values from y. The default is FALSE, so that only rows with data from both x and y are included in the output.
#' @param all.y: logical; analogous to all.x above.
#' @param suffixes: A character(2) specifying the suffixes to be used for making non-by column names unique. The suffix behavior works in a similar fashion as the \code{\link[base]{merge}} method does.
#' @return if the input \code{data} is a dataframe than a dataframe with the excluded columns will be return. If the input \code{data} is a data.table object, nothing will be returned and the input object will be modified.
#' @examples
#' data1 = data.table(id=1:2, text=c("a","b"))
#' data2 = data.table(id=rep(1:2,each=3), num=1:6)
#' grouped2 = groupBy(data2, "id")
#' join(data1,grouped2,"id")
join = function(x, y, by, all = FALSE, all.x =all, all.y=all, suffixes = c(".x", ".y")) {
  merge(x,y, by, all, all.x, all.y, suffixes)
}

#' addTimeWindow
#'
#' Add a sliding window column to the data
#'
#' @param data data frame with the training data to which the time window definition should be added.
#' @param dateCol The column name in \code{data} that will be used.
#' @param window The window length (numeric)
#' @param unit The window length unit. Should be one of: "Seconds", "Minutes", "Hours", "Days", "Years"
#' @param dateFormat provide date format for parsing. defaults to "\%m/\%d/\%Y " see strtptime for more examples i.e. "\%m/\%d/\%Y \%I:\%M:\%S \%p"
#' @param keyCol An optional key for the sliding window (NA as default)
#' @param includeUntil a boolean indicator for whether the very last time point should be included in the time window search space. FALSE by default.
#' @param relativeTime a boolean indicator for whether the time series should be coded with absolute timestamps or relative to the last point. In this case all time stamps will be negative using the defined time unit (e.g. -10 days). TRUE by default.
#' @param offset allows defining an additional time gap between that will be masked for the feature search. The entire time series will be shifted accordingly using the time window that was picked. 0 by default.
#' @param sample allows defining the maximum number of time points to be included in each time series. Random points are sampled from the time series to reduce the time series resolution in order to better capture global trends and increase runtime performance. By default set to 100.
#' @return The new data
addTimeWindow = function(data, dateCol, keyCol = NA, window, unit = "Days", dateFormat ="%m/%d/%Y",includeUntil = FALSE, relativeTime = TRUE, sample = 100, offset = 0, ...) {
	.Defunct(msg = .deprecationMessage(old = "addTimeWindow", new = 'timeWindowControl', version = "1.13"))
	
	unitVal = switch(unit,
									"Seconds" = 1,
									"Minutes" = 60,
									"Hours"   = 3600,
									"Days"    = 86400,
									"Years"   = 31536000,
									stop("Invalid time unit. Should be one of: 'Seconds', 'Minutes', 'Hours', 'Days', 'Years'")
									)
		prevTZ = Sys.timezone() 
		Sys.setenv(TZ = "UTC")
		prevLocale = Sys.getlocale("LC_TIME")
		Sys.setlocale("LC_TIME", "en_US.UTF-8")
	   
		newCol = if (is.na(keyCol)) {
	  	  			paste0("last_", window, "_", unit)
	  	  		} else {
	  		  		paste0("last_keyed_", window, "_", unit)
	  		  	}
	 
		#TODO: support non-dates,  support offset calculation, Date POSix objects
	    
		extraParams = list(...)
	   
		prefix = ifelse(is.na(keyCol), "TW:", "SKTW:")
	 
		datePOSIXformatOut = "%m/%d/%Y %I:%M:%S %p %Z" #TODO: check if multiple output formats are possible
		dateColIndex = which(colnames(data) == dateCol)
		dateColData = data[[dateColIndex]]
	   
		dateType = sapply(data, class)[dateColIndex] #charachter, integer, numeric, date, POSIXct
		if (length(class(dateType)) > 1) dateType = dateType[1] 
	   
		datesFromNAcount = 0
		datesUntilNAcount = 0
		generateWindow = function(dateVal, keyVal = NA) {
		dates = if (dateType == "character") {
					convertDateToString = function(dValue) as.character(as.POSIXct(dValue),format = datePOSIXformatOut)
					dt = convertDateToString(strptime(dateVal,dateFormat) - offset*unitVal)
					dt_from = convertDateToString(strptime(dateVal,dateFormat) - (window + offset)*unitVal) #seconds based
					c(dt_from, dt)
				} else if (dateType == "Date") {
					dt = as.character(as.POSIXct(dateVal) - offset*unitVal,format = datePOSIXformatOut)
					dt_from = as.character(as.POSIXct(dateVal) - (window + offset)*unitVal,format = datePOSIXformatOut)
					c(dt_from, dt)			
				} else if ("POSIXct" %in% unlist(dateType)) {
					dt = as.character(dateVal - offset*unitVal, format = datePOSIXformatOut)
					dt_from = as.character(dateVal - (window + offset)*unitVal, format = datePOSIXformatOut)
					c(dt_from, dt)
				} else {
					stop(paste("Date column", dateCol,"type should be one of 'character', 'date', 'POSIXct'."))
				}
			if (is.na(dates[1])) datesFromNAcount <<- datesFromNAcount + 1
			if (is.na(dates[2])) datesUntilNAcount <<- datesUntilNAcount + 1
			paste0(prefix, keyVal,",",dates[1],",",dates[2],",",includeUntil,",",relativeTime,",",unit,",",sample)
		}
		if (data.table::is.data.table(data)){
			if (is.na(keyCol)) {
				data[,(newCol) := sapply(dateColData, generateWindow)]
			} else {    
				data[,(newCol) := mapply(generateWindow,dateColData,eval(as.symbol(keyCol)))]
			}
		} else {
			if (is.na(keyCol)) {
				data[,newCol] = sapply(dateColData, generateWindow)
			} else {    
				keyColData = colsWhiteList(data, keyCol)
				data[,newCol] = mapply(generateWindow,dateColData,keyColData)
			}
		}
	    
		percentNAFrom = datesFromNAcount / nrow(data) * 100
		percentNAUntil = datesUntilNAcount / nrow(data) * 100
		if (percentNAFrom > 10)
			warning(paste0(percentNAFrom, "% of the time window start times are NA - are the function parameter correct?"))
		if (percentNAUntil > 10)
			warning(paste0(percentNAUntil, "% of the time window end times are NA - are the function parameter correct?"))
		
		if (!is.na(prevTZ)) Sys.setenv(TZ = prevTZ)
		Sys.setlocale("LC_TIME", prevLocale)
	 
		data[]
}
	
