#### LocalFile ####
.LocalFile <- R6::R6Class(
  "LocalFile",
  public = list(
    initialize = function(name, source, emptyValuePolicy = NULL) {
      if (!all(c(.FileReference$classname, "R6") %in% class(source))) {
        stop("source is not an instance of .FileReference")
      }
      private$name = name
      private$source = .FileDataSet$new(source)
      private$emptyValuePolicy = emptyValuePolicy
    },
    toJson = function(){
      list(
        name = private$name,
        source = private$source$toJson(),
        emptyValuePolicy = private$emptyValuePolicy,
        jsonClass = "com.sparkbeyond.runtime.data.transform.LocalFile"
      )
    }
  ),
  private = list(
    name = NULL,
    source = NULL,
    emptyValuePolicy = NULL
  )
)

#### TabularInput ####
.TabularInput <- R6::R6Class(
  "TabularInput",
  public = list(
    name = NULL,
    source = NULL,
    initialize = function(name, source) {
      if (!all(c(.FormattedSource$classname, "R6") %in% class(source))) {
        stop("source is not an instance of .FormattedSource")
      }
      self$name = name
      self$source = source
    },
    toJson = function(){
      list(
        name = self$name,
        source = self$source$toJson(),
        jsonClass = "com.sparkbeyond.runtime.data.transform.TabularInput"
      )
    }
  )
)

#### TypedTabularInput ####
.TypedTabularInput <- R6::R6Class(
  "TypedTabularInput",
  public = list(
    initialize = function(tabularInput, typingAndColumnTransformationSettings, typeAndTransformationDetectionSettings) {
      if (!all(c(.TabularInput$classname, "R6") %in% class(tabularInput))) {
        stop("tabularInput is not an instance of .TabularInput")
      }
      private$tabularInput = tabularInput
      private$typingAndColumnTransformationSettings = typingAndColumnTransformationSettings
      private$typeAndTransformationDetectionSettingsStoredByClient = typeAndTransformationDetectionSettings
    },
    toJson = function(){
      list(
        tabularInput = private$tabularInput$toJson(),
        typingAndColumnTransformationSettings = private$typingAndColumnTransformationSettings,
        typeAndTransformationDetectionSettingsStoredByClient = private$typeAndTransformationDetectionSettingsStoredByClient,
        jsonClass = "com.sparkbeyond.runtime.data.transform.TypedTabularInput"
      )
    }
  ),
  private = list(
    tabularInput = NULL,
    typingAndColumnTransformationSettings = NULL,
    typeAndTransformationDetectionSettingsStoredByClient = NULL
  )
)

#### LocalFileSource ####
.LocalFileSource <- R6::R6Class(
  "LocalFileSource",
  public = list(
    initialize = function(source) {
      if (!all(c(.FileReference$classname, "R6") %in% class(source))) {
        stop("source is not an instance of .FileReference")
      }
      private$source = source
    },
    toJson = function(){
      list(
        location = private$source$toJson(),
        jsonClass = "com.sparkbeyond.runtime.data.source.LocalFileSource"
      )
    }
  ),
  private = list(
    source = NULL
  )
)

#### FormattedSource ####
.FormattedSource <- R6::R6Class(
  "FormattedSource",
  public = list(
    initialize = function(source, parsingSettings) {
      if (!all(c(.LocalFileSource$classname, "R6") %in% class(source))) {
        stop("source is not an instance of .LocalFileSource")
      }
      private$source = source
      private$settings = parsingSettings
    },
    toJson = function(){
      list(
        source = private$source$toJson(),
        settings = private$settings,
        jsonClass = "com.sparkbeyond.runtime.data.parse.FormattedSource"
      )
    }
  ),
  private = list(
    source = NULL,
    settings = NULL
  )
)

#### FileDataSet ####
.FileDataSet <- R6::R6Class(
  "FileDataSet",
  public = list(
    initialize = function(location, encoding = NULL, isQuoted = NULL, useEscaping = NULL, emptyValuePolicy) {
      if (!all(c(.FileReference$classname, "R6") %in% class(location))) {
        stop("location is not an instance of .FileReference")
      }
      private$location = location
    },
    toJson = function(){
      list(
        location = private$location$toJson(),
        jsonClass = "com.sparkbeyond.runtime.data.source.FileDataSet"
      )
    }
  ),
  private = list(
    location = NULL
  )
)

#### FileReference ####
.FileReference <- R6::R6Class(
  "FileReference",
  public = list(
    location = NULL,
    path = NULL,
    projectName = NULL,
    initialize = function(location, path, projectName = NULL) {
      self$location = location
      self$path = path
      self$projectName = projectName
    },
    toJson = function(){
      list(
        location = self$location,
        path = self$path,
        projectName = self$projectName,
        jsonClass = "com.sparkbeyond.runtime.data.source.FileReference"
      )
    }
  )
)
