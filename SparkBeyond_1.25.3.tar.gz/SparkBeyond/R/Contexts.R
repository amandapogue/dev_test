#' Container for context definition helpers
#' 
#' @description
#' \itemize{
#'   \item geospatial(data, timeColumn, name, partitionBy, maxPartitions) This context allows looking for geo spatial features. All rows are indexed based on their coordinate information, allowing properties from the surrounding environment to be searched for by KNN. A coordinate column is required for this context object to be created.
#'   \item lookup(data, keyColumns, name, partitionBy, maxPartitions) This context creates a lookup table for each key column using all other columns as properties that can be associated with the key. The key column should be unique and can be defined in the keyColumns parameter.
#'   \item categoricalEncoding(data, targetColumn, keyColumns, smoothingCoefficient, asDiscrete, maxRows, maxCardinalityThreshold, name, partitionBy, maxPartitions) This context creates categorical likelihood encodings for each categorical column in the context using the specified key column as the encoding. It is never advised to include test data in this context.
#'   \item collaborativeFiltering(data, name, userLookupKeyColumns, itemLookupKeyColumns, numDimensions, maxRows, coldStartPolicy, partitionBy, maxPartitions) This context train a Collaborative Filtering Model from each boolean or numeric column value of the data-frame with SVD-like algorithm as implemented by the Surprise python package.  Note that you need to define a custom column subset with the user column and item column and complexity 3.5 to use this context.
#'   \item textIndex(data, keyColumn, name, partitionBy, maxPartitions) This context creates an inverted index out of text column provided in a context. The properties of each text can be search for in a KNN-fashion. A text column is required for this context object.
#'   \item graph(data, sourceNodeColumn, targetNodeColumn, name, partitionBy, maxPartitions) This context allows looking for features on a graph or a network. This context requires defining the edges in the graph by setting the source column and target column.
#'   \item timeSeries(data, timeColumn, keyColumns, name, partitionBy, maxPartitions) This context creates a single time series per column for all the rows provided. The context is sorted by the time/data column. It is necessary that at least one time window column should appear in the data.
#'   \item codeFile(codeFile, name) add functions from external code file
#'   \item featuresFromRevision(revision, name) start the learning with features discovered in a previous revision
#'   \item openStreetMap(filePath, name) define a context based on Open Street Map file
#'   \item shapeFile(filePath, name, partitionBy, maxPartitions) define a context based on Shape File. filePath should point to a <FILE_NAME>.shp file.
#'   Additionally at least 2 files should be present in the same directory: <FILE_NAME>.shx, <FILE_NAME>.dbf.
#'   \item word2Vec can be used in several ways:
#'   \itemize{
#'     \item pretrainedS3(modelName, name) Word2Wec using pretrained models from S3
#'     \item pretrainedLocal(data, name) Word2Wec using supplied pretrained vectors
#'     \item trainOnData(data, keyColumns, name, partitionBy, maxPartitions) Word2Wec trained on the supplied data
#'   }
#' }
#' 
#' @usage
#' geospatial(data, timeColumn, name, partitionBy, maxPartitions)
#'   data - a data frame
#'   name - name of the context, all context names should be unique
#'   timeColumn - defines the time column in context data
#'   partitionBy - partition the context data frame into many parts
#'   maxPartitions - maximum number of partitions to be used, if partitionBy is specified
#'
#' lookup(data, keyColumns, name, partitionBy, maxPartitions)
#'   data - a data frame
#'   keyColumns - names of the columns to be used as a key
#'   name - name of the context, all context names should be unique
#'   partitionBy - partition the context data frame into many parts
#'   maxPartitions - maximum number of partitions to be used, if partitionBy is specified
#'
#' categoricalEncoding(data, targetColumn, keyColumns, smoothingCoefficient, asDiscrete, maxRows, maxCardinalityThreshold, name, partitionBy, maxPartitions)
#'   data - a data frame
#'   targetColumn - the name of the column to be used to encode categorical columns. This is usually the training target column. If not specified, a column name matching the training target name will be used.
#'   keyColumns - the category columns. These columns will be used as lookups during learning.
#'   smoothingCoefficient - taking only positive values, larger values can be used to mitigate overfitting, default: 3.0
#'   asDiscrete - under some scenarios it may be desirable to encode a numeric target/key as discrete
#'   maxRows - a sample to maxRows will be used to encode categorical columns, default: 100,000
#'   maxCardinalityThreshold - the maximum cardinality threshold can be used to mitigate overfitting, expressed as a percentage of the number of context rows. For example 0.8 will require that the context object column cardinality be less than 80% of the context data frame size. Default: 0.5
#'   name - name of the context, all context names should be unique
#'   partitionBy - partition the context data frame into many parts
#'   maxPartitions - maximum number of partitions to be used, if partitionBy is specified
#'
#' collaborativeFiltering(data, name, userLookupKeyColumns, itemLookupKeyColumns, numDimensions, maxRows, coldStartPolicy, partitionBy, maxPartitions)
#'   data - a data frame
#'   name - name of the context, all context names should be unique
#'   userLookupKeyColumns - specifies the columns to be used that represent the user
#'   itemLookupKeyColumns - specifies the columns to be used that represent the item
#'   numDimensions - the number of latent factors used in the collaborative filtering model, default: 10
#'   maxRows - the first maxRows will be used to train the collaborative filtering. default: 5,000,000
#'   coldStartPolicy - "NaN" or "By existing Entity", control the imputation of a new entity (user and/or item) that was not present in the context input, default: "NaN"
#'   partitionBy - partition the context data frame into many parts
#'   maxPartitions - maximum number of partitions to be used, if partitionBy is specified
#'
#' contexts$textIndex(data, keyColumn, name, partitionBy, maxPartitions)
#'   data - a data frame
#'   keyColumn (optional) - column name to crate an index
#'   name - name of the context, all context names should be unique
#'   partitionBy - partition the context data frame into many parts
#'   maxPartitions - maximum number of partitions to be used, if partitionBy is specified
#'
#' graph(data, sourceNodeColumn, targetNodeColumn, name, partitionBy, maxPartitions)
#'   data - a data frame
#'   sourceNodeColumn - allows to specify the graph source node column
#'   targetNodeColumn - allows to specify the graph target node column
#'   name - name of the context, all context names should be unique
#'   partitionBy - partition the context data frame into many parts
#'   maxPartitions - maximum number of partitions to be used, if partitionBy is specified
#'
#' timeSeries(data, timeColumn, keyColumns, name, partitionBy, maxPartitions)
#'   data - a data frame
#'   timeColumn (optional) - define a time column
#'   keyColumns (optional) - names of the columns to be used as a key
#'   name - name of the context, all context names should be unique
#'   partitionBy - partition the context data frame into many parts
#'   maxPartitions - maximum number of partitions to be used, if partitionBy is specified
#'
#' contexts$codeFile(codeFile, name)
#'   codeFile - url to a file containing the functions
#'   name - name of the context, all context names should be unique
#'   
#' contexts$featuresFromRevision(revision, name)
#'   revision - revision to take the features from
#'   name - name of the context, all context names should be unique
#'   
#' contexts$openStreetMap(filePath, name)
#'   filePath - local path to the OSM file
#'   name - name of the context, all context names should be unique
#'   
#' contexts$shapeFile(filePath, name, partitionBy, maxPartitions)
#'   filePath - local path to the shape file
#'   name - name of the context, all context names should be unique
#'   partitionBy - partition the context data frame into many parts
#'   maxPartitions - maximum number of partitions to be used, if partitionBy is specified
#'
#' contexts$word2Vec$pretrainedS3(modelName, name)
#'   modelName name of one of the pretrained models. Available models: "Wikipedia", "Wikipedia-Gigaword", "CommonCrawl", "Twitter", "GoogleNews"
#'   name - name of the context, all context names should be unique
#'   
#' contexts$word2Vec$pretrainedLocal(data, name)
#'   data a data frame which contains texts column followed by Word2Vec vector columns
#'   name - name of the context, all context names should be unique
#'   
#' contexts$word2Vec$trainOnData(data, keyColumns, name, partitionBy, maxPartitions)
#'   data - dataframe based on which a Word2Vec model will be created
#'   keyColumns - names of columns to be used for building word2Vec model
#'   name - name of the context, all context names should be unique
#'   partitionBy - partition the context data frame into many parts
#'   maxPartitions - maximum number of partitions to be used, if partitionBy is specified
#'
#' @examples
#' Features from revision example, reusing features discovered in revision 5
#' \donttest{
#'   model = learn(
#'     projectName = "titanic_using_featuresFromRevision",
#'     trainData = data,
#'     target = "survived",
#'     contextDatasets = list(contexts$featuresFromRevision(revision = 5, name="rev5_features")))
#' }
#' 
#' Geospatial example
#' \donttest{
#'   langData =  getData("languages")
#'   
#'   model = learn(
#'     projectName = "languages", 
#'   	 trainData = langData, 
#'   	 target = "lang", 
#'   	 contextDatasets = list(contexts$geospatial(data=langData, name=contextName))
#'   )
#' }
#' 
#' Time Series example
#' \donttest{
#'   model = learn(
#'     projectName = "time_series_example",
#'     trainData = train,
#'     target = "target",
#'     contextDatasets = list(contexts$timeSeries(data=contextDataset, name="ts_context_name", timeColumn = "date")),
#'     problemDefinition = problemDefinitionControl(
#'       timeWindowsDefinition = list(timeWindowControl(dateCol = "date", window = 10, unit = "Days"))
#'     )
#'   )
#' }
#' 
#' @format 
#' 
contexts = list(
	
	geospatial = function(data, timeColumn = NULL, name, partitionBy = NULL, maxPartitions = NULL) {
		contextDefinition = list(
			data = data,
			timeColumn = timeColumn,
			name = name,
			partitionBy = partitionBy,
			maxPartitions = maxPartitions
		)
		class(contextDefinition) = c("geospatialContextDefinition", "contextDefinition")
		contextDefinition
	},
	
	lookup = function(data, keyColumns=list(), name, partitionBy = NULL, maxPartitions = NULL) {
		contextDefinition = list(
			data = data,
			keyColumns = .wrapWithListIfNeeded(keyColumns),
			name = name,
			partitionBy = partitionBy,
			maxPartitions = maxPartitions
		)
		class(contextDefinition) = c("lookupTableContextDefinition", "contextDefinition")
		contextDefinition
	},

	categoricalEncoding = function(data, targetColumn = NULL, keyColumns = list(), smoothingCoefficient = NULL, asDiscrete = NULL, maxRows = NULL, maxCardinalityThreshold = NULL, name, partitionBy = NULL, maxPartitions = NULL) {
		contextDefinition = list(
		data = data,
		targetColumn = targetColumn,
		keyColumns = .wrapWithListIfNeeded(keyColumns),
		smoothingCoefficient = smoothingCoefficient,
		asDiscrete = asDiscrete,
		maxRows = maxRows,
		maxCardinalityThreshold = maxCardinalityThreshold,
		name = name,
		partitionBy = partitionBy,
		maxPartitions = maxPartitions
		)
		class(contextDefinition) = c("categoricalEncodingContextDefinition", "contextDefinition")
		contextDefinition
	},

	collaborativeFiltering = function(data, name, userLookupKeyColumns=list(), itemLookupKeyColumns=list(), numDimensions = NULL, maxRows = NULL, coldStartPolicy = NULL, partitionBy = NULL, maxPartitions = NULL) {
	    contextDefinition = list(
	        data = data,
	        name = name,
	        userLookupKeyColumns = .wrapWithListIfNeeded(userLookupKeyColumns),
	        itemLookupKeyColumns = .wrapWithListIfNeeded(itemLookupKeyColumns),
	        numDimensions = numDimensions,
	        maxRows = maxRows,
	        coldStartPolicy = coldStartPolicy,
	        partitionBy = partitionBy,
	        maxPartitions = maxPartitions
	    )
	    class(contextDefinition) = c("collaborativeFilteringContextDefinition", "contextDefinition")
        		contextDefinition
	},
	
	textIndex = function(data, keyColumn = NULL, name, partitionBy = NULL, maxPartitions = NULL) {
		contextDefinition = list(
			data = data,
			keyColumn = keyColumn,
			name = name,
			partitionBy = partitionBy,
			maxPartitions = maxPartitions
		)
		class(contextDefinition) = c("textIndexContextDefinition", "contextDefinition")
		contextDefinition
	},

	graph = function(data, sourceNodeColumn, targetNodeColumn, name, partitionBy = NULL, maxPartitions = NULL) {
		structure(
			class = c("graphContextDefinition", "contextDefinition"),
			list(
				data = data,
				sourceNodeColumn = sourceNodeColumn,
				targetNodeColumn=targetNodeColumn,
				name = name,
				partitionBy = partitionBy,
				maxPartitions = maxPartitions)
		)
	},
	
	timeSeries = function(data, timeColumn = NULL, keyColumns = list(), name, partitionBy = NULL, maxPartitions = NULL) {
		structure(
			class = c("timeSeriesContextDefinition", "contextDefinition"),
			list(
				data = data,
				timeColumn = timeColumn,
				keyColumns = .wrapWithListIfNeeded(keyColumns),
				name = name,
				partitionBy = partitionBy,
				maxPartitions = maxPartitions
			)
		)
	},
	
	codeFile = function(codeFile, name) {
		contextDefinition = list(
			url = codeFile,
			name = name
		)
		class(contextDefinition) = c("codeFileContextDefinition", "contextDefinition")
		contextDefinition
	},
	
	word2Vec = list(
		trainOnData = function(data, keyColumns, name, partitionBy = NULL, maxPartitions = NULL) {
			if(!any(c("data.frame", "dataFrameSource")  %in% class(data))) {
				stop("data must be of type data.frame")
			}

			contextDefinition = list(
				data = data,
				keyColumns = .wrapWithListIfNeeded(keyColumns),
				name = name,
				partitionBy = partitionBy,
				maxPartitions = maxPartitions
			)
			class(contextDefinition) = c("word2VecBasedOnDataContextDefinition", "contextDefinition")
			contextDefinition
		},
		
		pretrainedS3 = function(modelName="Wikipedia", name) {
			contextDefinition = list(
				modelName = modelName,
				name = name
			)
			class(contextDefinition) = c("word2VecPretrainedS3ContextDefinition", "contextDefinition")
			contextDefinition
		},
		
		pretrainedLocal = function(data, name) {
			if(!any(c("data.frame", "dataFrameSource")  %in% class(data))) {
				stop("data must be of type data.frame")
			}
			
			contextDefinition = list(
				data = data,
				name = name
			)
			class(contextDefinition) = c("word2VecPretrainedLocalContextDefinition", "contextDefinition")
			contextDefinition
		}
	),
	
	featuresFromRevision = function(revision, name) {
		contextDefinition = list(
			revision = revision,
			name = name
		)
		class(contextDefinition) = c("featuresFromRevisionContextDefinition", "contextDefinition")
		contextDefinition
	},
	
	openStreetMap = function(filePath, name) {
		contextDefinition = list(
			filePath = filePath,
			name = name
		)
		class(contextDefinition) = c("openStreetMapContextDefinition", "contextDefinition")
		contextDefinition
	},
	
	shapeFile = function(filePath, name, partitionBy = NULL, maxPartitions = NULL) {
		contextDefinition = list(
			filePath = filePath,
			name = name,
			partitionBy = partitionBy,
			maxPartitions = maxPartitions
		)
		class(contextDefinition) = c("shapeFileContextDefinition", "contextDefinition")
		contextDefinition
	}
)
