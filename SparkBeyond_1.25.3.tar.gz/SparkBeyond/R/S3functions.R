# S3 functions (De facto constructors of Session)

#' timeWindowControl
#'
#' Defines a time window used with Time Series contexts.
#' Used in \code{\link{problemDefinitionControl}}.
#'
#' @param dateCol The column name in training set that will be used.
#' @param window The window length (numeric)
#' @param unit The window length unit. Should be one of: "Seconds", "Minutes", "Hours", "Days", "Weeks", "Years"
#' @param keyCol An optional key for the sliding window (NULL as default).
#' @param relativeTime a boolean indicator for whether the time series should be coded with absolute timestamps or relative to the last point. In this case all time stamps will be negative using the defined time unit (e.g. -10 days). TRUE by default.
#' @param offset allows defining an additional time gap between that will be masked for the feature search. The entire time series will be shifted accordingly using the time window that was picked. 0 by default.
#' @param sample allows defining the maximum number of time points to be included in each time series. Random points are sampled from the time series to reduce the time series resolution in order to better capture global trends and increase runtime performance. By default set to 100.
#' @param allowHistoricalStats when true, statistics for various historical quantities of the corresponding key will be calculated over the entire history (e.g. the average historical price of an item since the beginning of time), as opposed to just within the time-window (e.g. the average price for an item within the past 3 days). TRUE by default."
#' @param naturalModality usefull if there are natural time cycle dependencies such as daily or monthly. Multiple will cause the system to try them all and None to try none. Possible values: None, Hour_Of_Day, Day_Of_Week, Month_Of_Year, Multiple. None by default."
#' @param applyModalityFilter a boolean indicator for whether to use only dates with the same modality as the date column, or search on both the whole window and the modal version. FALSE by default."
#' @param removeKeyColumn a boolean indication for whether to remove the key column from the main training set. Default to FALSE.
#' @param removeDateColumn a boolean indication for whether to remove the date column from the main training set. Default to FALSE.
#' @param includeUntil a boolean indication for whether to include the last timestamp. Default to FALSE.
#' @return timeWindowControl object
#' @seealso \code{\link{contexts}} for Time Series context documentation and usage example
#' @seealso \code{\link{problemDefinitionControl}}
timeWindowControl = function(dateCol, keyCol = NULL, window, unit = "Days", relativeTime = TRUE, sample = 100, offset = 0, allowHistoricalStats = TRUE, naturalModality = "None", applyModalityFilter = FALSE, removeKeyColumn = FALSE, removeDateColumn = FALSE, includeUntil = FALSE) {
	def = list(
		dateColumn = dateCol,
		keyColumn = keyCol,
		windowSize = window,
		timeUnit = unit,
		relativeTime = relativeTime,
		sampleSize = sample,
		offsetFromTarget = offset,
		allowHistoricalStats = allowHistoricalStats,
		naturalModality = naturalModality,
		applyModalityFilter = applyModalityFilter,
		removeKeyColumn = removeKeyColumn,
		removeDateColumn = removeDateColumn,
		includeUntil = includeUntil
	)

	class(def) = "timeWindowControl"
	def
}

#' problemDefinitionControl
#'
#' @param forceRegression Boolean. Force the problem to be regression problem instead of classification. Optional - NA by default will choose the best problem definition based on the target.
#' @param forceQuantileRegression Boolean. Force the problem to be quantile regression problem.
#' @param weightColumn Optional. String of the name of of one of the column that indicate a weighting that is assigned to each example. NA by default.
#' @param trainTestSplitRatio Optional. Double value in [0,1] to split the train file data in order to keep some data for test. 0.8 by default. Ignored if test filename was provided.
#' @param temporalSplitColumn Optional. A column name containing temporal information by which the data will be splitted to train and test based on trainTestSplitRatio.
#' @param partitionColumn Optional. A column name containing information by which the data will be split to tain/test/validation set. Allowed values: "Train", "Validation", "Test".
#' @param timeWindowsDefinition Optional. List of \code{\link{timeWindowControl}} objects, used for creation of Time Series contexts.
problemDefinitionControl = function(
	forceRegression = NA,
	forceQuantileRegression = NA,
	weightColumn = NA,
	trainTestSplitRatio = NA,
	temporalSplitColumn = NA,
	partitionColumn = NA,
	timeWindowsDefinition = NA
){
	structure(
		class = c("ProblemDefinitionControl"),
		list(
			forceRegression = forceRegression,
			forceQuantileRegression = forceQuantileRegression,
			trainTestSplitRatio = trainTestSplitRatio,
			temporalSplitColumn = temporalSplitColumn,
			weightColumn = weightColumn,
			partitionColumn = partitionColumn,
			timeWindowsDefinition = .wrapWithListIfNeeded(timeWindowsDefinition)
		)
	)
}

#' preProcessingControl
#'
#' @param fileEncoding Optional. Options are: "ISO-8859-1", "UTF-8", "US-ASCII". NA by default will try to automatically find the best encoding.
#' @param linesForTypeDetection maximum number of lines that should be used for type detection. 10000 by default.
#' @param emptyValuePolicy Controls how empty values in numeric columns in the input data are being handled. DoubleNan is default see \code{\link{emptyValuePolicyList}}.
preProcessingControl = function(
	fileEncoding = NA,
	linesForTypeDetection = NA,
	emptyValuePolicy = NA
) {
	structure(
		class = c("PreProcessingControl"),
		list(
			emptyValuePolicy = emptyValuePolicy,
			fileEncoding = fileEncoding,
			linesForTypeDetection = linesForTypeDetection
		)
	)
}

#' emptyValuePolicyList
#'
#' Defines how empty values in numeric columns in the original data are being handled.
#' Please note - only one of the following should be set to true
#' @param median Median value of a column
#' @param average Average value of a column
#' @param nan Not a number
#' @param negativeInfinity Negative infinity
emptyValuePolicyList = function(
	median = FALSE,
	average = FALSE,
	nan = FALSE,
	doubleNan = FALSE,
	negativeInfinity = FALSE
) {
	policy = NA
	if (median) policy = "Median"
	if (average) policy = "Average"
	if (nan) policy = "NaN"
	if (doubleNan) policy = "DoubleNaN"
	if (negativeInfinity) policy = "NegativeInfinity"
	policy
}

#' featureGenerationControl
#'
#' @param maxFeaturesCount A list of integers indicating how many features should be created by the SparkBeyond engine. Optional 300 by default. Please note that if several feature cuts are defined they will be evaluated during the model building by cross validation and may result in increased running time.
#' @param automaticSelectionOfNumberOfFeatures. A heuristic that aims to produce a one or more feature counts that will improve the cumulative RIG for the set of features. (All automatically produced cutoffs are guaranteed to be below the maximum limit defined in maxFeaturesCount). Please note that as several feature cuts can be produced and evaluated during the model building using cross validation, setting this feature to TRUE may result in increased running time. FALSE by default.
#' @param supportThresholdType Optional. The type of support threshold ("absolute" or "relative"). For absolute, this is the absolute number of samples for which the feature must be true (default 3). For relative, this is the relative number (ratio) of samples for which feature needs to be true (default 0).
#' @param minSupport Optional The number of samples (either in absolute or relative terms) for which the feature must be true. For absolute support threshold, valid inputs are greater than 0 (default 3).  For relative support threshold, valid inputs are between 0 and 0.5 (default 0).
#' @param maxDepth Optional. Double < 8 which represent the maximum number of transformations allowed during the feature search phase. Increasing this value should be considered with cautious as the feature search phase is exponential. 2.5 by default.
#' @param expandedTimeSeries Optional. A boolean indicator for whether to use depth of 3.5 for time window columns. TRUE by default.
#' @param featureSearchMode Deprecated.
#' @param functionsWhiteList Optional. A list of strings that represents a set of functions that will be used to guide the feature search. NA by default.
#' @param functionsBlackList Optional. A list of strings that represents a set of function that will be excluded from the feature search. Can also include function domains including('math','arithmetics', 'collections', 'booleanOperators', 'semantics', 'nlp', 'trigonometry', 'bitwise'). NA by default.
#' @param localTopFeatureCount The maximal number of top features that should be created from a single column. 1000 by default.
#' @param regressionDiscretizerBinsOverride Define the bin boundaries that should be created for regression problem bins. By default 6 bins will be created, with boundaries defined by equal mass (in order to not create a bias towards any of the bins). Should be a list of numbers spanning the entire target range. An example would be list(0,25,50,75,100) to create 4 bins spanning the entire 0-100 range. These bins will be used only for feature search purposes and not for model building.
#' @param regressionNumberOfBins: Explicitly specify the number of bins for equal mass discretization of the continuous target (ignored when \code{regressionDiscretizerBinsOverride} is defined). 6 by default.
#' @param booleanNumericFeatures A boolean indicating whether to transform all features to boolean values. (i.e., when FALSE the continuous value of the feature left-hand-side will be passed to the algorithm, without taking into account the specific cutoff chosen during the feature search phase). NA by default indicating that it will be TRUE for classification problems and FALSE for regression problems.
#' @param numericEqualityFeatures A boolean indicator for whether to include features that compare numeric fields with specific values. TRUE by default.
#' @param allowRangeFeatures A boolean indicator for whether to include features that define range over a set of numeric values. TRUE by default.
#' @param useRawNumericColumns Optional. Use the original numeric columns as features when building the model. This will automatically attempt to also build a model based only on the numeric columns with applying additional transformations on the data. TRUE by default.
#' @param useCategoricalColumns Optional. Use the original categorical columns as features when building models which support categoricals. Currently supported models are KerasDeepLearning and LightGBM. TRUE by default.
#' @param autoColumnSubSets Optional. A list of values contain any of the following: "CONCEPT", "NUMERIC_PAIRS", "ALL_PAIRS". "CONCEPT" will aim to generate column subset from fields that are from similar non-numeric types or combination of date and non-numeric elements. "NUMERIC_PAIRS" will create all column subsets for numeric columns. "ALL_PAIRS" will create subsets of size 2 from all columns. "CONCEPT" by default.
#' @param customColumnSubsets Optional. A List of lists containing specific column subsets to examine. In order to set a certain depth to the subset, add an element in the end of the customSubSet with one digit as a string representing the requested depth. If not such element was defined the regular depth definitions will be used. NA by default.
#' @param maxFeatureDuration Optional. A numeric value representing the maximum allowed time a feature may take during search per row in milliseconds. 100 by default.
#' @param overrideMaxFeatureDurationForExternalData A boolean indicating whether the maxFeatureDuration parameter should not be used for features that use external data. TRUE by default.
#' @param allocatedMemoryMB Optional. Integer value representing how to chunk the memory during feature search . 1000 by default.
#' @param maxCollectionSize Optional. Integer  value representing what is the maximum cardinality allowed for a transformation during feature search. NA by default corresponding to 200K.
#' @param useCachedFeatures Optional. A boolean indicating whether to use cached features (from previous run). TRUE by default.
#' @param featureSelectionMethod Optional. A character value representing the method of selecting the final features. Defaults to "PairwiseInformationGain". Valid values are:
#' "SemiSupervisedAnomalyDetection (based on rareEvent column)" -Intended to be used only with anomaly detection problems. The method is supposed to be operated in conjunction with the data characterization transformation and also assumes the existence of a Boolean column termed “rareEvent”. The method will then prioritize features that both characterize the data and correlate with the rareEvent column.
#' "RobustInfoGain" - This measure decreases the importance of features with fluctuating information gain across different folds of the data. Expects to receive a column to sort by before taking folds, otherwise assumes that data is presorted. Useful for fluctuating time series data because assumes that features that are consistent over all time periods are more likely to be robust on test data.
#' "SimpleByRigAndSegmentation" - Intended to be used only with unsupervised problems and in particular segmentation. The method is supposed to be operated in conjunction with the characterization transformation. It will look for features that both characterize the data but also divide it well (e.g. if half of the population is below 1.77 and half above it the method will give high score to the feature height < 1.77 or even more so to height in range (0, 1.77) )
#' "PairwiseInformationGain" - Calculates the conditional mutual information between each feature and the target conditioned on the set of already selected features. On each iteration, select the feature that contributes the most information to the already selected set.
#' "SemiSupervisedAnomalyDetectionRelaxed (based on rareEvent column)" - Intended to be used only with anomaly detection problems. Method seeks features that identifying anomalies, but with decreased importance for anomalies relative to SemiSupervised Anomaly Detection.
#' "PairwiseInformationGainWithLinearRegularization" - Calculates the conditional mutual information between each feature and the target conditioned on the set of already selected features. On each iteration, select the feature that contributes the most information to the already selected set. Includes a stronger regularization parameter to penalize complex features.
#' "SimpleLinearSelection" - Scores each feature according to its coefficient in a simple linear regression model that includes only that feature.
#' "PairwiseLinear" - Computes pairwise scores using a multivariate linear regression that includes pairs of features. Relevant only for regression problems.
#' "SimpleByRig" - Select the top features based on RIG score. Usually results in many correlated features. Often use for anomaly detection in conjunction with the data characterization transformation.
#' @param gainThreshold: Optional. Remove features with information gain below the specified threshold. 0.0005 by default.
#' @param naNPolicy: Sets the policy for imputing Double NaN values found in the output of the feature. MINMAX, MEDIAN, ZERO.
#' @param missingValuesAllowed: Only select features whose total (true & false) percentage of missing values are less than the specified threshold. Default: 0.15 Range: [0, 1].
#' @param timeVSQualityFactor: Optional. For large datasets, consider decreasing if a long feature search runtime is expected. 1.0 by default.
#' @param timeVSSmallSupportFactor: Optional. For large datasets, consider increasing if many small support features are expected (e.g. in some text processing problems). May slow down feature search. 1.0 by default.
#' @param deduplicationSimilarityThreshold: Optional. Prune features by empirical similarity. 0.9 by default.
#' @param acceleratedFeatureSearch: Optional. Attempt to rule out hypotheses faster. This often reduces feature search time drastically without impacting the insights and model's accuracy. FALSE by default.
#' @param equalityFeatures A boolean indicator for whether to include features of the form form ƒ(x) = y. TRUE by default.
#' @param timeSeriesInteraction A Boolean. Enable time series interaction by creating time series of pairs of elements. This is useful for expressing memberwise relationships between time series, and more. Note that feature search may take longer with this option active.
featureGenerationControl = function(
	maxFeaturesCount = NA,
	automaticSelectionOfNumberOfFeatures = NA,
	supportThresholdType = NA,
	minSupport = NA,
	maxDepth = NA,
	expandedTimeSeries = NA,
    featureSearchMode = NA,
	functionsWhiteList = NA,
	functionsBlackList = NA,
	localTopFeatureCount = NA,
	regressionDiscretizerBinsOverride = NA,
	regressionNumberOfBins = NA,
	booleanNumericFeatures = NA,
	numericEqualityFeatures = NA,
	allowRangeFeatures = NA,
	useRawNumericColumns = NA,
	useCategoricalColumns = NA,

	autoColumnSubSets = list("CONCEPT"),
	customColumnSubsets = NA,
	maxFeatureDuration = NA,
	overrideMaxFeatureDurationForExternalData = NA,
	allocatedMemoryMB = NA,
	maxCollectionSize = NA,
	useCachedFeatures = NA,
	featureSelectionMethod = NA,
	gainThreshold = NA,
	naNPolicy = NA,
	missingValuesAllowed = NA,
	timeVSQualityFactor = NA,
	timeVSSmallSupportFactor = NA,
	deduplicationSimilarityThreshold = NA,
	acceleratedFeatureSearch = NA,
	equalityFeatures = NA,
	timeSeriesInteraction = NA
) {
    if(!is.na(featureSearchMode)) {
      .Defunct(msg = .deprecationMessage(old = "featureSearchMode",  version = "1.24"))
    }

	structure(
		class = c("FeatureGenerationControl"),
		list(
            maxFeaturesCount = .wrapWithListIfNeeded(maxFeaturesCount),
            supportThresholdType = supportThresholdType,
            minSupport = minSupport,
            maxDepth = maxDepth,
            expandedTimeSeries = expandedTimeSeries,
            functionsWhiteList = .wrapWithListIfNeeded(functionsWhiteList),
            functionsBlackList = .wrapWithListIfNeeded(functionsBlackList),
            localTopFeatureCount = localTopFeatureCount,
            regressionDiscretizerBinsOverride = .wrapWithListIfNeeded(regressionDiscretizerBinsOverride),
            regressionNumberOfBins = regressionNumberOfBins,
            booleanNumericFeatures = booleanNumericFeatures,
            numericEqualityFeatures = numericEqualityFeatures,
            equalityFeatures = equalityFeatures,
            allowRangeFeatures = allowRangeFeatures,
            useRawNumericColumns = useRawNumericColumns,
            useCategoricalColumns = useCategoricalColumns,

            autoColumnSubSets = .wrapWithListIfNeeded(autoColumnSubSets),
            customColumnSubsets = customColumnSubsets,
            maxFeatureDuration = maxFeatureDuration,
            overrideMaxFeatureDurationForExternalData = overrideMaxFeatureDurationForExternalData,
            allocatedMemoryMB = allocatedMemoryMB,
            maxCollectionSize = maxCollectionSize,
            useCachedFeatures = useCachedFeatures,
            featureSelectionMethod = featureSelectionMethod,
            gainThreshold = gainThreshold,
            naNPolicy = naNPolicy,
            missingValuesAllowed = missingValuesAllowed,
            timeVSQualityFactor = timeVSQualityFactor,
            timeVSSmallSupportFactor = timeVSSmallSupportFactor,
            deduplicationSimilarityThreshold = deduplicationSimilarityThreshold,
            acceleratedFeatureSearch = acceleratedFeatureSearch,
            timeSeriesInteraction = timeSeriesInteraction
		)
	)
}

#' knowledge Control
#'
#' @param linkedDataCore Includes DBPedia, Yago2, Wordnet and OpenLibrary. DBpedia is a crowd-sourced community effort to extract structured information from Wikipedia. Matches training data by Text elements. False by default.
#' @param openStreetMap OpenStreetMap (OSM) is a collaborative project to create a free editable map of the world. Matches training data by location (coordinate). False by default.
#' @param weather Weather data from NOAA Climate.gov. Matches the training data by date and location. False by default.
#' @param holidays National holidays for over 20 countries. Matches the training data by date and country/location. False by default.
knowledgeControl = function(
	linkedDataCore = NA,
	openStreetMap = NA,
	weather = NA,
	holidays = NA,
	...
) {
	extraParams = list(...)

	deprecatedLookupFlags = extraParams[names(extraParams) %in% list('usCensus', 'news', 'twitter')]

	if (length(deprecatedLookupFlags) > 0) {
		list2String = function(l) paste(l, collapse = ", ")
		errorMessage = paste("The following knowledge options are deprecated:", list2String(names(deprecatedLookupFlags)))
		if ('usCensus' %in% names(deprecatedLookupFlags)) {
			errorMessage = paste0(errorMessage, ". US Census data can be found in the new World Knowledge datasets. See help for \"worldKnowledge\" (?worldKnowledge) for more details.")
		}
		.Defunct(msg = errorMessage)
	}

	if ('customDatasets' %in% names(extraParams)) {
		.Defunct(msg = "customDatasets flag is deprecated")
	}

	if (length(extraParams) > 0) {
		warning("Unexpected parameters were passed to knowledgeControl: ", paste(names(extraParams), collapse = ", "))
	}

	structure(
		class = c("KnowledgeControl"),
		list(
			linkedDataCore = linkedDataCore,
			openStreetMap = openStreetMap,
			weather = weather,
			holidays = holidays
		)
	)
}


#' modelBuildingControl
#'
#' @param algorithmsWhiteList: Optional. A list of strings that represents the set of algorithms to run. Uses \code{\link{algorithms}}
#' @param extraModels: Optional. A named list of algorithms to run, along with the hyperparameters to set for these algorithms.
#' @param evaluationMetric: Optional. A string representing the evaluation metric. SNA by default automatically selects AUC for classification and RMSE for regression. Valid values are:
#' "RMSE" - Root Mean Square Error - calculates the difference between the predicted and actual for each observation, squares that difference, and then takes the average across all observations. RMSE gives a larger penalty to larger errors, so is useful when large errors need to be minimized. Used for regression.
#' "GINILIFT" - The Gini coefficient measures the purity of the resulting classes, or the expected chance of misclassification. Used for both regression and classification problems.
#' "PREC" - Precision measures the probability that a positive prediction is actually true. It is the ratio between the number of true positives relative to all the positives identified by the model. Used for classification problems.
#' "LOGLOSS" - Log loss evaluates  a classifier based on its probability outputs instead of on discrete predictions. It takes into account the uncertainty of the prediction based on how much it varies from the actual label. Useful in classification cases where the actual prediction probabilities is important.
#' "AUC" - The AUC is the area under the ROC curve, which is created by plotting the true positive rate against the false positive rate at various threshold settings. The AUC measures the probability that a classifier will rank a positive instance as more likely than a negative instance. Used for classification problems.
#' @param crossValidation: Optional. Integer value representing the number of cross-validation folds to use during the model-building phase, in order to select the best model and hyper-parameters. If left undefined, validation set will be used for model evaluation. If both crossValidation and validationSetRatio are defined, validation set will be used for model evaluation.
#' @param validationSetRatio: Optional. Numeric value between 0 and 1, representing the ratio for validation set (out of the training data) to use during the model-building phase, in order to select the best model and hyper-parameters. Default value: 0.2. If both crossValidation and validationSetRatio are defined, validation set will be used for model evaluation.
#' @param maxRecordsForModelBuild: The maximal number of records to use for model training. 100K by default.
modelBuildingControl = function(
	algorithmsWhiteList = NA,
	extraModels = list(),
	evaluationMetric = NA,
	crossValidation = NA,
	validationSetRatio = NA,
	maxRecordsForModelBuild = NA
) {
	structure(
		class = c("ModelBuildingControl"),
		list(
			algorithmsWhiteList = .wrapWithListIfNeeded(algorithmsWhiteList),
			extraModels = extraModels,
			evaluationMetric = evaluationMetric,
			crossValidation = crossValidation,
			validationSetRatio = validationSetRatio,
			maxRecordsForModelBuild = maxRecordsForModelBuild
		)
	)
}

#' reportingControl
#'
#' @param showWebView control for whether to show a dynamic web view of the analysis in a browser.
#' @param emailNotification An optional email to notify when the learning is finished.
#' @param scoreOnTestSet Optional. A boolean representing whether scoring should be provided for the test set. FALSE by default.
#' @param featureClustersReport Produce feature cluster visualization. FALSE by default.
#' @param evaluatedFunctionsReport Creates a report with the entire list of functions that were evaluated. For contexts will also show for each object which functions directly used the context.
reportingControl = function(
	showWebView = TRUE,
	emailForNotification = NA,
	scoreOnTestSet = FALSE,
	featureClustersReport = FALSE,
	evaluatedFunctionsReport = FALSE
) {
	structure(
		class = c("ReportingControl"),
		list(
			featureClustersReport = featureClustersReport,
			eevaluatedFunctionsReport = evaluatedFunctionsReport,
			scoreOnTestSet = scoreOnTestSet,
			emailForNotification = emailForNotification,
			showWebView = showWebView
		)
	)
}

#' learn
#'
#' Runs SparkBeyond feature enrichment and learning process.
#' @param projectName: Optional string of the session name. Setting a session name is highly recommended. "temp" by default.
#' @param trainData: train data to analyze.
#' @param target String of the column name of in the training file that contains the target of the prediction.
#' @param testData: Optional. test data to validate model results. NA by default.
#' @param contextDatasets: Optional. A list of contexts to be added to the learning. See examples in \code{\link{contexts}}.
#' @param problemDefinition: A \code{\link{problemDefinitionControl}} object with specific problem definition parameters.
#' @param preProcessing: A \code{\link{preProcessingControl}} object with specific preprocessing parameters.
#' @param featureGeneration: A \code{\link{featureGenerationControl}} object with specific feature generation parameters.
#' @param knowledge: A \code{\link{knowledgeControl}} object with specific external knowledge parameters.
#' @param modelBuilding: A \code{\link{modelBuildingControl}} object with specific model building parameters.
#' @param reporting: A \code{\link{reportingControl}} object with specific reporting parameters.
#' @param runBlocking: Block the R console while the session is running. TRUE by default.
#' @param revisionDescription: String revision comment
#' @param learningMode: Optional. Select default settings consistent with a given learning strategy: Insight, OptimizeModel. NA by default.
#'                      Insight Mode: Fast learning iterations with an emphasis on qualitative feature discovery. Features will convey insights into the problem while avoiding extended learning sessions intended to maximize predictive performance.
#'                      OptimizeModel Mode: Predictive performance is paramount. This mode aims to provide a starting point for achieving strong predictive performance. The features may be less human friendly as they attempt to maximize signal extracted from the data. Runtime may be longer as larger and more models are built in the pursuit of performance.
#' @param parentRevision: parent revision for this learning. Set parentRevision = 0 to put this revision under root. If no parent revision is specified, the server will find the most suitable (default NA)
#' @return \code{\link{Session}} object that encapsulates the model.
#' @examples
#' #session = learn("titanic", getData("titanic_train"), target = "survived")
learn <- function(
			 projectName,
			 trainData,
			 target,
			 testData = NULL,
			 contextDatasets = NULL,
			 problemDefinition = problemDefinitionControl(),
			 preProcessing = preProcessingControl(),
			 featureGeneration = featureGenerationControl(),
			 knowledge = knowledgeControl(),
			 modelBuilding = modelBuildingControl(),
			 reporting = reportingControl(),
			 runBlocking = TRUE,
			 revisionDescription = "",
			 learningMode = NA,
			 parentRevision = NA,
			 ...
){
	extraParams = list(...)

	if (length(extraParams) > 0) {
		warning("Unexpected parameters were passed to learn function: ", paste(names(extraParams), collapse = ", "))
	}

	if (.isServerVersionOlderThan(1.18) && !is.na(parentRevision)){
		warning("parentRevision is supported from version 1.18")
	}

	assertClass = function(obj, expectedType) {
		if (!expectedType %in% class(obj)) {
			stop(paste0("Unexpected argument type. Expected: ", expectedType, ", received: ", class(obj)))
		}
	}

	assertClass(problemDefinition, "ProblemDefinitionControl")
	assertClass(preProcessing, "PreProcessingControl")
	assertClass(featureGeneration, "FeatureGenerationControl")
	assertClass(knowledge, "KnowledgeControl")
	assertClass(modelBuilding, "ModelBuildingControl")
	assertClass(reporting, "ReportingControl")

	if (!currentUser(FALSE)) stop("Please login before calling the learn function. Thank you.")

	projectName = gsub(" ", "_", projectName)
	project = getOrCreateProject(projectName)

	trainTestSplitRatio = problemDefinition$trainTestSplitRatio
	if (!is.null(testData) && !is.na(trainTestSplitRatio)) message("Note: test data was provided - ignoring trainTestSplitRatio defintion.")

	if (!is.null(testData) && setequal(names(trainData),names(testData)) == FALSE) {
		message("trainData:")
		message(paste0(names(trainData),","))
		message("testData:")
		message(paste0(names(testData),","))
		stop("testData and trainData have different schemas")
	}

	url <- paste0(getSBserverURL(),"/api/learn")
	message(paste("Calling:", url))

	if (is.na(preProcessing$emptyValuePolicy)) {
		preProcessing$emptyValuePolicy = NULL
	}

	contextDatasets = .handleContexts(contextDatasets, projectName = project$name, preProcessing$emptyValuePolicy, detectTypes = TRUE)

	algorithmsWhiteList = modelBuilding$algorithmsWhiteList
	extraModels = modelBuilding$extraModels

	params <- list(
		projectName = project$name,
		revisionDescription = revisionDescription,
		parentRevision = parentRevision,
		learningMode = learningMode,
		target = target,

		contextDatasets = contextDatasets,

		#problem definition
		regressionMode = problemDefinition$forceRegression,
		quantileMode = problemDefinition$forceQuantileRegression,
		trainTestSplitRatio = trainTestSplitRatio,
		temporalSplitColumn = problemDefinition$temporalSplitColumn,
		weightColumn = problemDefinition$weightColumn,
		partitionColumn = problemDefinition$partitionColumn,
		timeWindowsDefinition = problemDefinition$timeWindowsDefinition,

		# preprocessing control
		fileEncoding = preProcessing$fileEncoding,
		linesForTypeDetection = preProcessing$linesForTypeDetection,

		#feature search parameters
		maxFeaturesCount = featureGeneration$maxFeaturesCount,
		automaticSelectionOfNumberOfFeatures = featureGeneration$automaticSelectionOfNumberOfFeatures,
		supportThresholdType = featureGeneration$supportThresholdType,
		supportThresholdAbsolute = featureGeneration$minSupport,
		supportThresholdRelative = featureGeneration$minSupport,
		functionsWhiteList = featureGeneration$functionsWhiteList,
		functionsBlackList = featureGeneration$functionsBlackList,
		localTopFeatureCount = featureGeneration$localTopFeatureCount,
		regressionDiscretizerBinsOverride = featureGeneration$regressionDiscretizerBinsOverride,
		regressionNumberOfBins = featureGeneration$regressionNumberOfBins,
		booleanNumericFeatures = featureGeneration$booleanNumericFeatures,
		numericEqualityFeatures = featureGeneration$numericEqualityFeatures,
		equalityFeatures = featureGeneration$equalityFeatures,
		allowRangeFeatures = featureGeneration$allowRangeFeatures,
		useRawNumericColumns = featureGeneration$useRawNumericColumns,
		useCategoricalColumns = featureGeneration$useCategoricalColumns,
		autoColumnSubSets = featureGeneration$autoColumnSubSets,
		customColumnSubsets = featureGeneration$customColumnSubsets,
		maxFeatureDuration = featureGeneration$maxFeatureDuration,
		overrideMaxFeatureDurationForExternalData = featureGeneration$overrideMaxFeatureDurationForExternalData,
		useCachedFeatures = featureGeneration$useCachedFeatures,
		allocatedMemoryMB = featureGeneration$allocatedMemoryMB,
		maxCollectionSize = featureGeneration$maxCollectionSize,
		maxDepth = featureGeneration$maxDepth,
		expandedTimeSeries = featureGeneration$expandedTimeSeries,
		featureSelectionMethod = featureGeneration$featureSelectionMethod,
		gainThreshold = featureGeneration$gainThreshold,
		naNPolicy = featureGeneration$naNPolicy,
		missingValuesAllowed = featureGeneration$missingValuesAllowed,
		timeVSQualityFactor = featureGeneration$timeVSQualityFactor,
		timeVSSmallSupportFactor = featureGeneration$timeVSSmallSupportFactor,
		deduplicationSimilarityThreshold = featureGeneration$deduplicationSimilarityThreshold,
		acceleratedFeatureSearch = featureGeneration$acceleratedFeatureSearch,
		timeSeriesInteraction = featureGeneration$timeSeriesInteraction,

		#knowledge parameters
		linkedDataCore = knowledge$linkedDataCore,
		openStreetMap = knowledge$openStreetMap,
		weather = knowledge$weather,
		holidays = knowledge$holidays,

		# model building parameters
		algorithmsWhiteList = algorithmsWhiteList,
		extraModels = extraModels,
		evaluationMetric = modelBuilding$evaluationMetric,
		crossValidation = modelBuilding$crossValidation,
		validationSetRatio = modelBuilding$validationSetRatio,
		maxRecordsForModelBuild = modelBuilding$maxRecordsForModelBuild,

		#reporting parameters
		produceFeatureClusteringReport = reporting$featureClustersReport,
		produceEvaluatedFunctionsReport = reporting$evaluatedFunctionsReport,
		scoreOnTestSet = reporting$scoreOnTestSet,
		emailForNotification = reporting$emailForNotification,

		externalPrefixPath = NA
	)

	params$trainingProvider = .handleData(data = trainData,projectName = project$name, name = "train", emptyValuePolicy = preProcessing$emptyValuePolicy, detectTypes = TRUE)
	params$testProvider =
		if (!is.null(testData) && (any(grep("data.frame", class(testData))) || class(testData) == "character") || is(testData, "Dataset")) {
		  .handleData(data = testData,projectName = project$name, name = "test")
		} else {
			NA
		}

	params = params[!is.na(params)]

	if (.isServerVersionOlderThan('1.23')) {
		message(paste("Training on ",params$trainingProvider$source$location$path))
	} else {
		message(paste("Training on ",params$trainingProvider$tabularInput$name))
	}

	body = rjson::toJSON(params)
	#if (verbose) print(body)
	res = .executeRequest(
		function() httr::POST(url, body = body, httr::content_type_json()),
		errorHandling = .withErrorHandling(message = "Train error"),
		responseSerializer = .responseSerializers$JSON
	)

	session = Session(artifact_loc = res$artifactPath,
							jobId = as.character(if (is.null(res$jobId)) -1 else res$jobId)
					)

	if (reporting$showWebView == TRUE) session$webView()
	if (runBlocking) session$waitForProcess()

	return(session)

}

#' algorithmsList
#'
#' @param isClassification A boolean indicator for whether to use only classification algorithms or only regression algorithms. If is NA the relevant algorithms are selected based on the target type and cardinality using the learning process.
#' @param randomForest random forest algorithm from the randomForest package.
#' @param zeroR predicts the mean (for a numeric class) or the mode (for a nominal class). This method requires almost no computation and will be the fastest to apply.
#' @param xgBoost eXtreme gradient boosted machine algorithm from the xgBoost package.  (currently does not support multiclass)
#' @param GBM gradient boosted machine algorithm from the xgBoost package.
#' @param rpart decision tree algorithm from the rpart package.
#' @param lassoGlmnet logistic regression / linear regression algorithm with alpha = 0 from the glmnet package.
#' @param ridgeGlmnet logistic regression / linear regression algorithm with alpha = 1 from the glmnet package.
#' @param linearRegression linear regression algorithm. lm from the base package.
#' @param linearEnsemble A linear ensemble of a collection of GBM and rpart algorithms.
#' @param naiveBayes.weka Classification algorithm. A naive Bayes classifier is a simple probabilistic classifier based on applying Bayes' theorem with strong independence assumptions.
#' @param bagging.weka bagging a classifier to reduce variance Can do classification and regression.
#' @param votedPerceptron.weka Classification algorithm. The perceptron is an algorithm for supervised classification of an input into one of several possible non-binary outputs.
#' @param classificationViaClustering.weka A simple meta-classifier that uses a clusterer for classification. For cluster algorithms that use a fixed number of clusterers.
#' @param classificationViaRegression.weka Doing classification using regression methods. Class is binarized and one regression model is built for each class value.
#' @param randomSubSpace.weka Constructs a decision tree based classifier that maintains highest accuracy on training data and improves on generalization accuracy as it grows in complexity. The classifier consists of multiple trees constructed systematically by pseudorandomly selecting subsets of components of the feature vector, that is, trees constructed in randomly chosen subspaces.
#' @param bayesNet.weka A Bayes Network classifier. Provides datastructures (network structure, conditional probability distributions, etc.) and facilities common to Bayes Network learning algorithms like K2 and B.
#' @param libSVM.weka Wrapper for the libSVM library, an integrated software for support vector classification, (C-SVC, nu-SVC), regression (epsilon-SVR, nu-SVR) and distribution estimation (one-class SVM). It supports multi-class classification.
#' @param adaBoostM1.weka Algorithm for boosting a nominal class classifier using the Adaboost M1 method. Only nominal class problems can be tackled.
#' @param decisionTable.weka Algorithm for building and using a simple decision table majority classifier.
#' @param smo.weka Implements John Platt's sequential minimal optimization algorithm for training a support vector classifier.
#' @param repTree.weka Fast decision tree learner. Builds a decision/regression tree using information gain/variance and prunes it using reduced-error pruning (with backfitting).
#' @param smo.regression.weka SMOreg implements the support vector machine for regression.A regression scheme that employs any classifier on a copy of the data that has the class attribute (equal-width) discretized.
#' @param regressionByDiscretization.weka A regression scheme that employs any classifier on a copy of the data that has the class attribute (equal-width) discretized.
algorithmsList = function(
			isClassification = NA,
			randomForest = FALSE,
			zeroR = FALSE,
			xgBoost = FALSE,
			GBM = FALSE,
			rpart = FALSE,
			lassoGlmnet = FALSE,
			ridgeGlmnet = FALSE,
			linearRegression = FALSE,
			linearEnsemble = FALSE,
			naiveBayes.weka = FALSE,
			bagging.weka = FALSE,
			votedPerceptron.weka = FALSE,
			classificationViaClustering.weka = FALSE,
			classificationViaRegression.weka = FALSE,
			randomSubSpace.weka = FALSE,
			bayesNet.weka = FALSE,
			libSVM.weka = FALSE,
			adaBoostM1.weka = FALSE,
			decisionTable.weka = FALSE,
			smo.weka = FALSE,
			repTree.weka = FALSE,
			smo.regression.weka = FALSE,
			regressionByDiscretization.weka = FALSE,
			scikit = TRUE
		){
			.Deprecated(msg = .deprecationMessage(old = "algorithmsList", new="algorithms", version = "1.16"))
			algsList = vector()
			if (randomForest) algsList = c(algsList, "RRandomForestClassifier", "RRandomForestRegressor")
			if (xgBoost) algsList = c(algsList, "RXGBoostClassifier" , "RXGBoostRegressor")
			if (GBM) algsList = c(algsList, "RCaretGBMClassifier","RCaretGBMRegressor")
			if (rpart) algsList = c(algsList, "RRpartDecisionTreeClassifier", "RRpartDecisionTreeRegressor")
			if (lassoGlmnet) algsList = c(algsList, "RLassoLogisticRegressionGlmnetClassifier", "RLassoLinearRegressionGlmnetRegressor")
			if (ridgeGlmnet) algsList = c(algsList, "RRidgeLogisticRegressionGlmnetClassifier",  "RRidgeLinearRegressionGlmnetRegressor")
			if (linearEnsemble) algsList = c(algsList, "RLinearEnsembleGBM_with_RpartClassifier", "RLinearEnsembleGBM_with_RpartRegressor")

			if (linearRegression) algsList = c(algsList, "RLinearRegressionLMRegressor")

			toKeep = if (!is.na(isClassification)){
				if (isClassification == TRUE) which(grepl("Classifier", algsList))
				else if (isClassification == FALSE) which(grepl("Regressor", algsList))
			} else NULL

			if (!is.null(toKeep)) algsList = algsList[toKeep]

			if (naiveBayes.weka) algsList = c(algsList, "weka.classifiers.bayes.NaiveBayes")
			if (bagging.weka) algsList = c(algsList, "weka.classifiers.meta.Bagging(-I 20)")
			if (votedPerceptron.weka) algsList = c(algsList, "weka.classifiers.functions.VotedPerceptron")
			if (classificationViaClustering.weka) algsList = c(algsList, "weka.classifiers.meta.ClassificationViaClustering")
			if (classificationViaRegression.weka) algsList = c(algsList, "weka.classifiers.meta.ClassificationViaRegression")
			if (randomSubSpace.weka) algsList = c(algsList, "weka.classifiers.meta.RandomSubSpace")
			if (bayesNet.weka) algsList = c(algsList, "weka.classifiers.bayes.BayesNet")
			if (libSVM.weka) algsList = c(algsList, "weka.classifiers.functions.LibSVM")
			if (adaBoostM1.weka) algsList = c(algsList, "weka.classifiers.meta.AdaBoostM1")
			if (decisionTable.weka) algsList = c(algsList, "weka.classifiers.rules.DecisionTable")
			if (smo.weka) algsList = c(algsList, "weka.functions.SMO")
			if (repTree.weka) algsList = c(algsList, "weka.classifiers.trees.REPTree(-M 5)")
			if (smo.regression.weka) algsList = c(algsList, "weka.classifiers.functions.SMOreg")
			if (regressionByDiscretization.weka) algsList = c(algsList, "weka.classifiers.meta.RegressionByDiscretization(-B 3 -W weka.classifiers.trees.RandomForest)")
			if (zeroR) algsList = c(algsList, "ZeroR")
			if (scikit) algsList = c(algsList, algorithms$scikit$RandomForest)
			algsList
	}
