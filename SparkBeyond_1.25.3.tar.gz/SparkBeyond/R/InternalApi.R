.jobStatusFromJson <- function(json) {
	validate = function(value) {
		is.character(value$projectName) && is.integer(value$revision) && is.integer(value$rowCount) && is.character(value$state) &&
			(is.null(value$result) || is.character(value$result)) &&
			(is.null(value$error) || is.character(value$error)) &&
			(is.null(value$result) || is.null(value$error))
	}

	value = list()

	tryCatch(
		{
			value = list(
				projectName = json$projectName,
				revision = json$revision,
				rowCount = json$rowCount,
				state = json$state,
				result = json$result,
				error = json$error
			)
			if(!validate(value))
				message("Invalid json received, can't deserialize into jobStatus")
		},
			error = function(cond) {
				message("Failed to deserialize ")
			}
	)

	attr(value, "class") <- "jobStatus"
	value
}

.enrichPredictStatusFromJson = function(json) {
	tryCatch({
		structure(
			class = c("enrichPredictJobStatus"),
			list(builtContexts = if(is.null(json$builtContexts)) FALSE else json$builtContexts,
					 processedRows = ifelse(is.null(json$processedRows), 0, json$processedRows$amount),
					 typerErrorsReport = json$typerErrorsReport
			))
		},
		error = function(cond) {
			stop(paste("Invalid json received, can't deserialize into job status:", json))
		}
	)
}

.generatePredictionReports = function(predictJobId, desiredClassOverride = NA, percentOfPopulationToPlot = 0.2, outputName = "lift") {
	url = paste0(getSBserverURL(),"/api/generatePredictionJobReports")
	params = list(
		predictJobId = predictJobId,
		desiredClassOverride = desiredClassOverride,
		percentOfPopulationToPlot = percentOfPopulationToPlot
	)
	params = params[!is.na(params)]
	body = rjson::toJSON(params)

	response = .executeRequest(
		function() httr::POST(url, body = body, httr::content_type_json()),
		responseSerializer = .responseSerializers$JSON
	)

	.jobStateFromJson(response)
}

.showPredictResultReport = function(jobId, filename) {
	url = paste0(getSBserverURL(),"/api/predictionReportFile/", jobId, "/", filename)
	token = .executeRequest(
		function() httr::GET(paste0(getSBserverURL(),paste0("/getToken"))),
		responseSerializer = .responseSerializers$TEXT
	)
	htmlSource = paste0(url, "?token=", token)
	browseURL(htmlSource)
}

.showEnrichPredictTyperErrorsOverview = function(enrichPredictStatus) {
	if(!is.null(enrichPredictStatus$typerErrorsReport)) {

		inputReports = enrichPredictStatus$typerErrorsReport$inputs[lapply(enrichPredictStatus$typerErrorsReport$inputs, function(inp) inp$rowsWithErrors > 0) > 0]

		hasAnyErrors = (!is.null(inputReports) && length(inputReports) > 0)

		if(hasAnyErrors) {
			message("\nStarting typing error report summary")
			message("====================================\n")
		}

		if(!is.null(inputReports) && length(inputReports) > 0) {
			inputsWithErrors = names(inputReports)
			message("Typer errors detected in ",length(inputsWithErrors)," inputs.")
			lapply(inputsWithErrors, function(inputName) {
				report = inputReports[[inputName]]
				message(inputName, ":")
				message("\tRows processed: ", report$rowsSeen)
				message("\tRows with typer errors: ", report$rowsWithErrors)
				message("\tPercent of rows with typer errors: ", paste0(formatC(100 * (report$rowsWithErrors / report$rowsSeen)), "%"))
			})
		}

		if(hasAnyErrors) {
			message("\nCompleted typing error report summary")
			message("You can get a breakdown of typing errors by column from typer errors report:")
			message("job$typerErrorsReport() or job$jobReports()")
			message("=====================================\n")
		}
	}
}

.getTyperErrorsReportFromJson = function(jobId) {
	url = paste0(getSBserverURL(),"/api/predictionReportFile/", jobId, "/typerErrorsReport.json")
	.executeRequest(
		function() httr::GET(url),
		responseSerializer = .responseSerializers$JSON
	)
}

.convertTyperErrorToDataFrame = function(typerErrorReport) {
	errorsDataFrame = data.table::rbindlist(lapply(typerErrorReport$columns, function(column){
		errors = column$errors
		examples = column$examples$value
		rowNames = c("error_num", "example1")
		if(!is.null(examples)) {
			examples = paste("Row ",column$examples$row, ": ",column$examples$value, sep="")
			rowNames = c("error_num",paste("example", c(1:length(examples)), sep=""))
		} else {
			examples = NA
		}

		data.frame(t(data.frame(c(errors, examples), row.names = rowNames, stringsAsFactors = F)), row.names = NULL, stringsAsFactors = F)
	}), fill = TRUE)

	errorsDataFrame$error_num <- as.integer(errorsDataFrame$error_num)
	errorPercentPerColumn = formatC(100 * (errorsDataFrame$error_num/typerErrorReport$rowsSeen))
	errorsDataFrame = cbind(names(typerErrorReport$columns), errorPercentPerColumn, errorsDataFrame)
	names(errorsDataFrame) <- c("column", "error_pct", tail(names(errorsDataFrame),-2))
	if(sum(errorsDataFrame$error_num) == 0) {
		errorsDataFrame = errorsDataFrame[,!(names(errorsDataFrame) %in% c("example1", "error_pct"))]
	}
	errorsDataFrame
}

.getPredictEvaluation = function(jobId) {
	url = paste0(getSBserverURL(),"/api/predictionReportFile/", jobId, "/evaluation.json")
	.executeRequest(
		function() httr::GET(url),
		responseSerializer = .responseSerializers$JSON
	)
}

.jobResultFromJson = function(resultJson) {
	if(is.na(resultJson)) {
		stop(paste("Invalid json received, can't deserialize into job result:", resultJson))
	}

	structure(
		class = c("jobResult"),
		list(error = resultJson$failure,
				 success = resultJson$success,
				 isSucceeded = is.null(resultJson$failure)))
}

.jobStateFromJson <- function(json) {
	extractTimestampMillis = function(json, name) {
		if(is.null(json[[name]])) {
			NULL
		} else {
			json[[name]] %/% 1000
		}
	}
	tryCatch({
		enqueuedMillis = extractTimestampMillis(json, "enqueued")
		startedMillis = extractTimestampMillis(json, "started")
		endedMillis = extractTimestampMillis(json, "ended")
		structure(
			class = c("jobState"),
			list(jobId = json$id,
					 enqueuedMillis = enqueuedMillis,
					 startedMillis = startedMillis,
					 endedMillis = endedMillis,
					 workerId = if(is.null(json$worker)) { NULL } else { json$worker$logicalId },
					 status = json$status,
					 result = json$result,
					 isEnqueued = !is.null(enqueuedMillis) && is.null(startedMillis),
					 isRunning = !is.null(startedMillis) && is.null(endedMillis),
					 isCompleted = !is.null(endedMillis)))
		},
		error = function(cond) {
			stop(paste("Invalid json received, can't deserialize into job state:", json, "-", cond$message))
		}
	)
}

.getJobState = function(jobId) {
	url <- paste0(getSBserverURL(),"/api/jobState/", jobId)

	res = .executeRequest(
		function() httr::GET(url, httr::content_type_json()),
		errorHandling = .withErrorHandling(onError = .onErrorBehavior$MESSAGE),
		responseSerializer = .responseSerializers$JSON
	)

	if(is.null(res))
		NULL
	else
		.jobStateFromJson(res)
}

.cancelJob = function(jobId, onError = .onErrorBehavior$STOP) {
	url <- paste0(getSBserverURL(),"/api/cancelOrAbortJob/", jobId)
	.executeRequest(function() httr::POST(url), errorHandling = .withErrorHandling(onError = onError))
}

.initJob = function(jobId) {
	structure(
		class = c("job"),
		list(jobId = jobId,
			currentState = function() {
				.getJobState(jobId)
			},
			cancel = function() {
				.cancelJob(jobId)
			},
			# STATE_UPDATE_FUN - callback that is executed on polling. Returns TRUE to continue polling, FALSE otherwise.
			pollState = function(STATE_CALLBACK_FUN, pollingIntervalSeconds = 5) {
				state = .getJobState(jobId)
				while(STATE_CALLBACK_FUN(state)) {
					Sys.sleep(pollingIntervalSeconds)
					state = .getJobState(jobId)
				}
			})
	)
}

.runPipeline = function(projectName, inputs, revision = NULL, targetProject = NULL) {
	url <- paste0(getSBserverURL(),"/api/runPipeline")

	# Workaround to produce '{}' in json. Without this list() is serialized as '[]'
	if(length(inputs)==0) {
		inputs = setNames(inputs, character(0))
	}

	params = list(
		project = projectName,
		revision = revision,
		targetProject = targetProject
	)

	params$inputs = inputs

	body = rjson::toJSON(params)

	res = .executeRequest(
		function() httr::POST(url, body=body, httr::content_type_json()),
		errorHandling = .withErrorHandling(message = "Retraining error"),
		responseSerializer = .responseSerializers$JSON
	)

	Session(ifelse(!is.null(targetProject), targetProject, projectName), res$revision, jobId=res$jobId)
}

.getNotificationLogReport = function(projectName, revision, path, responseSerializer = .responseSerializers$JSON, onError = .onErrorBehavior$STOP) {
	url = paste0(getSBserverURL(),"/api/notificationsLog/",projectName,"/",revision, "?path=", path)
	.executeRequest(
		function() httr::GET(url),
		errorHandling = .withErrorHandling(onError = onError),
		responseSerializer = responseSerializer
	)
}

.download = function(url, localFile = NA_character_, description = NA_character_) {
	tempFileName = "downloaded.tmp"
	tempFileCreated = FALSE
	downloadDescription = ifelse(!is.na(description), description,
											 ifelse(!is.na(localFile), localFile, "..."))
	if(is.na(localFile)) {
		tempFileCreated = TRUE
		localFile = tempFileName
	}

	message(paste("Downloading", downloadDescription))
  downloadResult = .executeRequest(
  	function() httr::GET(url, config = httr::progress(type = "down"), httr::write_disk(localFile, overwrite = TRUE)),
    errorHandling = .withErrorHandling(retries = 2)
  )

	if(httr::status_code(downloadResult) == 200) {
		if(tempFileCreated) {
			contentDispositionFileName <- stringr::str_match(httr::headers(downloadResult)$`content-disposition`, "\"(.*)\"")[2]
			if(!is.na(contentDispositionFileName)) {
				file.rename(tempFileName, contentDispositionFileName)
				localFile = contentDispositionFileName
			} else {
				stop(paste0("Error in download from ", url, ": Local file name is not defined"))
			}
		}
		message(paste("File", localFile, "saved to:", normalizePath(localFile)))
	} else {
		stop(paste("Failed to download a file from:", url))
	}
	normalizePath(localFile)
}

.downloadWorldKnowledgeObject = function(objectName) {
	url = paste0(getSBserverURL(),"/api/v1/worldKnowledgeObjects/", objectName, "/download")
	localFile = .download(url)
	read.csv(localFile, header=TRUE, stringsAsFactors = FALSE, comment.char = "")
}

.getAvailablePackageVersion = function() {
	url = paste0(getSBserverURL(), "/sdk/r/version")
	result = .executeRequest(
		function() httr::GET(url),
		errorHandling = .withErrorHandling(onError = .onErrorBehavior$SILENT),
		responseSerializer = .responseSerializers$JSON
	)
	if(!is.null(result)) {
		result$version
	} else {
		NULL
	}
}

.exportModelToPredictionBox = function(project, revision,
																			 predictionBoxUrl, authKey = "",
																			 uploadExtractor = TRUE, uploadModel = TRUE, uploadContexts = TRUE,
																			 overwriteExisting = TRUE, overrideTargetGroupName = NULL) {
	url = paste0(getSBserverURL(), "/api2/predictionBoxClient/uploadModel")
	params = list(project = project, revision = revision, baseRevision = revision,
								predictionBoxUrl = predictionBoxUrl, authKey = authKey,
								uploadExtractor = uploadExtractor, uploadModel = uploadModel, uploadContexts = uploadContexts,
								overwriteExisting = overwriteExisting, overrideTargetGroupName = overrideTargetGroupName)
	.executeRequest(function() httr::POST(url, body = rjson::toJSON(params), httr::content_type_json()))
	message(paste0("Model from project: ", project, ", revision: ", revision, " was exported successfully"))
}

.handleContexts = function(contextDatasets, projectName, emptyValuePolicy = NULL, detectTypes=FALSE) {
	if (!is.null(contextDatasets)) {
		if (class(contextDatasets) != "list") {
			warning("contextDatasets should be a list")
			contextDatasets=list(contextDatasets)
		}
		contextDatasets = as.list(contextDatasets)
		contextNames = sapply(contextDatasets, function(contextDef) {
			if (any(c("contextObject", "contextDefinition", "WorldKnowledgeObject") %in% class(contextDef))) {
				contextDef$name
			} else {
				stop("Not all provided context objects are of type 'contextDefinition'")
			}
		})
		if(any(duplicated(contextNames))) stop("Context names should be unique: ", paste(contextNames, collapse = ", "))
		contextDatasets = lapply(contextDatasets, function(context) {
			if(any(c("contextDefinition", "WorldKnowledgeObject") %in% class(context))) {  # the new way of defining contexts

				createContextObject = function(contextProvider=NULL, contextTypes=NULL, name = NULL, keyColumns = list(),
					timeColumn = NULL, graphSourceNodeColumn = NULL, graphTargetNodeColumn= NULL,
					smoothingCoefficient = NULL, asDiscrete = NULL, maxRows = NULL,
					maxCardinalityThreshold = NULL, targetColumn = NULL, userLookupKeyColumns = NULL, itemLookupKeyColumns = NULL,
					numDimensions = NULL, coldStartPolicy = NULL, partitionBy = NULL, maxPartitions = NULL) {
					provider = contextProvider
					if(!is.null(emptyValuePolicy)) {
						provider$emptyValuePolicy = emptyValuePolicy
					}
					list(contextProvider = provider, contextTypes = contextTypes, name = name, keyColumns = keyColumns,
						timeColumn = timeColumn, graphSourceNodeColumn = graphSourceNodeColumn, graphTargetNodeColumn = graphTargetNodeColumn,
						smoothingCoefficient = smoothingCoefficient, asDiscrete = asDiscrete, maxRows = maxRows,
						maxCardinalityThreshold = maxCardinalityThreshold, targetColumn = targetColumn,
						userLookupKeyColumns = userLookupKeyColumns, itemLookupKeyColumns = itemLookupKeyColumns,
                        numDimensions = numDimensions, coldStartPolicy = coldStartPolicy,
						partitionBy = partitionBy, maxPartitions = maxPartitions)
				}

				if("WorldKnowledgeObject" %in% class(context)) {
					context$asContext()
				} else if("geospatialContextDefinition" %in% class(context)) {
					contextName = ifelse(!is.null(context$name), paste0("_", context$name),"")

					provider = if ("WorldKnowledgeObject" %in% class(context$data)) {
						context$data$asContextProvider()
					} else {
					  .handleData(data = context$data, projectName = projectName, name = paste0("context", contextName), emptyValuePolicy = emptyValuePolicy, detectTypes)
					}

					createContextObject(contextProvider = provider, timeColumn = context$timeColumn, name = context$name, partitionBy = context$partitionBy, maxPartitions = context$maxPartitions, contextTypes = list("GeoSpatial"))
				} else if("lookupTableContextDefinition" %in% class(context)) {
					contextName = ifelse(!is.null(context$name), paste0("_", context$name),"")

					provider = if ("WorldKnowledgeObject" %in% class(context$data)) {
						context$data$asContextProvider()
					} else {
					  .handleData(data = context$data, projectName = projectName, name = paste0("context", contextName), emptyValuePolicy = emptyValuePolicy, detectTypes)
					}

					createContextObject(contextProvider=provider, keyColumns = context$keyColumns, name = context$name, partitionBy = context$partitionBy, maxPartitions = context$maxPartitions, contextTypes = list("LookupTables"))
				} else if ("categoricalEncodingContextDefinition" %in% class(context)) {
					contextName = ifelse(!is.null(context$name), paste0("_", context$name),"")

					provider = if ("WorldKnowledgeObject" %in% class(context$data)) {
						context$data$asContextProvider()
					} else {
					  .handleData(data = context$data, projectName = projectName, name = paste0("context", contextName), emptyValuePolicy = emptyValuePolicy, detectTypes)
					}

					createContextObject(
						contextProvider = provider,
						keyColumns = context$keyColumns,
						name = context$name,
						asDiscrete = context$asDiscrete,
						smoothingCoefficient = context$smoothingCoefficient,
						maxRows = context$maxRows,
						targetColumn = context$targetColumn,
						maxCardinalityThreshold = context$maxCardinalityThreshold,
						contextTypes = list("CategoricalEncoding"),
						partitionBy = context$partitionBy,
						maxPartitions = context$maxPartitions
					)
				} else if("collaborativeFilteringContextDefinition" %in% class(context)) {
				    contextName = ifelse(!is.null(context$name), paste0("_", context$name),"")

				    provider = if ("WorldKnowledgeObject" %in% class(context$data)) {
                    	context$data$asContextProvider()
                    } else {
                        .handleData(data = context$data, projectName = projectName, name = paste0("context", contextName), emptyValuePolicy = emptyValuePolicy, detectTypes)
                    }

                    createContextObject(
                        contextProvider = provider,
                        name = context$name,
                        userLookupKeyColumns = context$userLookupKeyColumns,
                        itemLookupKeyColumns = context$itemLookupKeyColumns,
                        numDimensions = context$numDimensions,
                        maxRows = context$maxRows,
                        coldStartPolicy = context$coldStartPolicy,
                        contextTypes = list("CollaborativeFiltering"),
                        partitionBy = context$partitionBy,
                        maxPartitions = context$maxPartitions
                    )
				} else if("textIndexContextDefinition" %in% class(context)) {
					contextName = ifelse(!is.null(context$name), paste0("_", context$name),"")
					keyColumns = if(is.null(context$keyColumn)) {
						list()
					} else {
						list(context$keyColumn)
					}

					provider = if ("WorldKnowledgeObject" %in% class(context$data)) {
						context$data$asContextProvider()
					} else {
					  .handleData(data = context$data, projectName = projectName, name = paste0("context", contextName), emptyValuePolicy = emptyValuePolicy, detectTypes)
					}

					createContextObject(contextProvider=provider, keyColumns = keyColumns, name = context$name, partitionBy = context$partitionBy, maxPartitions = context$maxPartitions, contextTypes = list("TextIndex"))
				} else if("graphContextDefinition" %in% class(context)) {
					contextName = ifelse(!is.null(context$name), paste0("_", context$name),"")

					provider = if ("WorldKnowledgeObject" %in% class(context$data)) {
						context$data$asContextProvider()
					} else {
					  .handleData(data = context$data, projectName = projectName, name = paste0("context", contextName), emptyValuePolicy = emptyValuePolicy, detectTypes)
					}

					createContextObject(contextProvider=provider, graphSourceNodeColumn = context$sourceNodeColumn, graphTargetNodeColumn = context$targetNodeColumn,
															name = context$name, partitionBy = context$partitionBy, maxPartitions = context$maxPartitions, contextTypes = list("Graph"))
				} else if("timeSeriesContextDefinition" %in% class(context)) {
					contextName = ifelse(!is.null(context$name), paste0("_", context$name),"")
					contextType = ifelse(length(context$keyColumns)>0, "TimeSeriesMap", "TimeSeries")

					provider = if ("WorldKnowledgeObject" %in% class(context$data)) {
						context$data$asContextProvider()
					} else {
					  .handleData(data = context$data, projectName = projectName, name = paste0("context", contextName), emptyValuePolicy = emptyValuePolicy, detectTypes)
					}

					createContextObject(contextProvider=provider, timeColumn = context$timeColumn, keyColumns = context$keyColumns,
															name = context$name, partitionBy = context$partitionBy, maxPartitions = context$maxPartitions, contextTypes = list(contextType))
				} else if("codeFileContextDefinition" %in% class(context)) {
					createContextObject(contextProvider = list(url = context$url, name = "Code file", jsonClass = "com.sparkbeyond.runtime.data.transform.CodeFile"),
															name = context$name)
				} else if("word2VecBasedOnDataContextDefinition" %in% class(context)) {
					contextName = ifelse(!is.null(context$name), paste0("_", context$name),"")

					provider = if ("WorldKnowledgeObject" %in% class(context$data)) {
						context$data$asContextProvider()
					} else {
					  .handleData(data = context$data, projectName = projectName, name = paste0("context", contextName), emptyValuePolicy = emptyValuePolicy, detectTypes)
					}

					createContextObject(contextProvider=provider, name = context$name, keyColumns = context$keyColumns, partitionBy = context$partitionBy, maxPartitions = context$maxPartitions, contextTypes = list("Word2Vec"))
				} else if("word2VecPretrainedS3ContextDefinition" %in% class(context)) {
					createContextObject(contextProvider = list(source = context$modelName, name = context$name, jsonClass = "com.sparkbeyond.runtime.data.transform.Word2Vec"),
															name = context$name,
															contextTypes = list("Word2VecPretrainedS3"))
				} else if("word2VecPretrainedLocalContextDefinition" %in% class(context)) {
					contextName = ifelse(!is.null(context$name), paste0("_", context$name),"")

					provider = if ("WorldKnowledgeObject" %in% class(context$data)) {
						context$data$asContextProvider()
					} else {
					  .handleData(data = context$data, projectName = projectName, name = paste0("context", contextName), emptyValuePolicy = emptyValuePolicy, detectTypes)
					}

					createContextObject(contextProvider=provider, name = context$name, contextTypes = list("Word2VecPretrainedLocal"))
				} else if("featuresFromRevisionContextDefinition" %in% class(context)) {
					createContextObject(contextProvider = list(revisionId = context$revision, name = "FeaturesFromRevision", jsonClass = "com.sparkbeyond.runtime.data.transform.FeaturesFromRevision"),
															name = context$name)
				} else if("openStreetMapContextDefinition" %in% class(context)) {
					contextName = ifelse(!is.null(context$name), paste0("_", context$name), "")
					fileReference = uploadFileToServer(filePath = context$filePath, projectName = projectName, name = paste0("context", contextName))

					contextProvider = list(
					  jsonClass = "com.sparkbeyond.runtime.data.transform.OpenStreetMapFileInput",
					  location = fileReference$toJson(),
					  name = context$name
					)
					createContextObject(contextProvider = contextProvider,
															name = context$name,
															contextTypes = list("OSMFile"))
				} else if("shapeFileContextDefinition" %in% class(context)) {
					findFilesRelatedToShapeFile = function(shapeFilePath) {
						stopifnot(tools::file_ext(shapeFilePath) == "shp")

						fileNameWithoutExtention = tools::file_path_sans_ext(shapeFilePath)
						possibleExts = c("cpg", "dbf", "prj", "shx")
						relatedFiles = paste0(fileNameWithoutExtention,".",possibleExts)
						existingRelatedFiles = relatedFiles[file.exists(relatedFiles)]

						requiredExts = c("dbf", "shx")
						requiredFiles = paste0(fileNameWithoutExtention,".",requiredExts)
						if(!all(requiredFiles %in% existingRelatedFiles)) {
							vec2String = function(vec) paste(vec, collapse = ", ")
							stop(paste0("Missing some of the mandatory files for shape file: ", shapeFilePath, ".\n Required: ", vec2String(requiredFiles), ".\n Found: ", vec2String(existingRelatedFiles)))
						}
						relatedFiles
					}

					if(! tools::file_ext(context$filePath) == "shp") {
						stop(paste("filePath in shapeFile context should point to a file with .shp extension. Instead received:", context$filePath))
					}

					shapeComplimentaryFiles = findFilesRelatedToShapeFile(context$filePath)
					uploadFiles = Vectorize(uploadFileToServer, c("filePath"))

					contextName = ifelse(!is.null(context$name), paste0("_", context$name), "")
					uploadFiles(shapeComplimentaryFiles, projectName = projectName, name = paste0("context", contextName), generateHash=FALSE)
					fileReference = uploadFileToServer(filePath = context$filePath, projectName = projectName, name = paste0("context", contextName), generateHash=FALSE)
					contextProvider = list(
					  jsonClass = "com.sparkbeyond.runtime.data.transform.ShapeFileInput",
					  location = fileReference$toJson(),
					  name = context$name
					)
					createContextObject(contextProvider = contextProvider,
															name = context$name,
															partitionBy = context$partitionBy,
															maxPartitions = context$maxPartitions,
															contextTypes = list("SpatialIndexFromShapes"))
				}
			} else {
				.Defunct("Using old contextObject implementation, please use contexts instead")
				contextName = ifelse(!is.null(context$name), paste0("_", context$name),"")
				context$data = .handleData(data = context$data, projectName = projectName, name = paste0("context", contextName), emptyValuePolicy = emptyValuePolicy, detectTypes)
				context
			}
		})
	}
	contextDatasets
}

.showReport = function(report_path = NA, projectName, revision){ #confine to a specific list
	"\\code{report_path} path of report to show"
	suppressWarnings({
		url <- paste0(getSBserverURL(),paste0("/getToken"))
		token = .executeRequest(
			function() httr::GET(url),
			responseSerializer = .responseSerializers$TEXT
		)
		htmlSource = paste0(getSBserverURL(), "/analytics/report/", projectName, "/", revision, "/", report_path,"?token=", token)
		browseURL(htmlSource)
	})
}

.getWorldKnowledgeMetadata = function() {
	url <- paste0(getSBserverURL(),"/api/v1/worldKnowledgeObjects")

	res = .executeRequest(
		function() httr::GET(url, httr::content_type_json()),
		errorHandling = .withErrorHandling(message = 'Failed to get World Knowledge Objects list'),
		responseSerializer = .responseSerializers$JSON
	)

	structure(
		class = c("WorldKnowledgeMetadata"),
		list(
			metadata=res$objectsMetadata,
			updated=res$updated,
			syncFailure=res$syncFailure
		)
	)
}

	# Serialization
.responseSerializers = list(
	NONE = "NONE",
	JSON = "JSON",
	JSON_RAW = "JSON_RAW",
	TEXT = "TEXT",
	DATA_FRAME = "DATA_FRAME"
)

# Error handling
.onErrorBehavior = list(
	STOP = "stop",
	WARNING = "warning",
	MESSAGE = "message",
	SILENT = "silent"
)

.withErrorHandling = function(retries = 0, extractErrorFromJson=TRUE, onError = .onErrorBehavior$STOP, message = NA_character_) {
	structure(
		class = c("ErrorHandlingSettings"),
		list(retries = retries, extractErrorFromJson=extractErrorFromJson, onError = onError, message = message)
	)
}

.signalApiCondition = function(type, message, call = sys.call(-1), isRetriable=TRUE) {
	exc = structure(
		class = c(type, "RequestFailedError", "condition"),
		list(message = message, isRetriable = isRetriable, call = call)
	)
	stop(exc)
}

.sdkError = function(message, call) {
	structure(
		class = c("SdkError", "error", "condition"),
		list(message = message, call = call)
	)
}

.executeRequest = function(httpCall, errorHandling = .withErrorHandling(), responseSerializer = .responseSerializers$NONE) {
	externalCallStack = sys.call(-1)
	error = NA_character_
	trimUnparsableContentInErrorMessagesLength = 400
	handleError = function(message, onError, stackTrace) {
		if(onError == .onErrorBehavior$STOP) {
			stop(.sdkError(message, stackTrace))
		} else if(onError == .onErrorBehavior$WARNING) {
			warning(message)
		} else if(onError == .onErrorBehavior$MESSAGE) {
			message(message)
			NULL
		} else if(onError == .onErrorBehavior$SILENT) {
			NULL
		} else {
			stop("Incorrect onError behavior defined, should be one of the following: [stop, warning, message, silent]")
		}
	}

	exceptions = list(
		CONNECTION_CURL = "ConnectionCurl",
		AUTHENTICATION = "Authentication",
		AUTHORIZATION = "Authorization",
		APPLICATION_FAILURE = "ApplicationFailure",
		APPLICATION_ERROR = "ApplicationError",
		UNEXPECTED_RESPONSE_FORMAT = "ResponseFormatError"
	)

	extractApplicationError = function(httpResponse, expectJson=FALSE) {
		tryCatch({
			text = suppressMessages(httr::content(httpResponse, as="text"))
			res <- jsonlite::fromJSON(txt = text, simplifyDataFrame=FALSE)
			if(!is.null(res$error)) {
				res$error
			} else if(!is.null(res$message)) {
				res$message
			} else {
				NA_character_
			}
		}, error = function(e) {
			if(expectJson) {
				.signalApiCondition(exceptions$UNEXPECTED_RESPONSE_FORMAT, "Failed to parse the response")
			} else {
				NA_character_
			}
		})
	}
	
	parseJsonResponse = function(response, simplifyDataFrame=TRUE) {
	  responseText = NA_character_
	  tryCatch({
	    responseText <- suppressMessages(httr::content(response, as="text"))
	    jsonlite::fromJSON(txt = responseText, simplifyDataFrame=simplifyDataFrame)
	  },error = function(e) {
	    truncatedResponse = ifelse(is.na(responseText), "Failed to parse context as text", strtrim(responseText, trimUnparsableContentInErrorMessagesLength))
	    if(nchar(responseText)>trimUnparsableContentInErrorMessagesLength) {
	      truncatedResponse = paste0(truncatedResponse, "...")
	    }
	    .signalApiCondition(exceptions$APPLICATION_FAILURE, paste0("Failed to parse response as json for url: ", response$url,
	                                                               "\nHTTP Status: ", httr::status_code(response),
	                                                               "\nResponse: ", truncatedResponse),
	                        call = externalCallStack, isRetriable = FALSE)
	  })
	}

	responseSerializersFactory = list(
		NONE = function(response) { response },
		JSON = function(response) { parseJsonResponse(response) },
		JSON_RAW = function(response) { parseJsonResponse(response, simplifyDataFrame = FALSE) },
		TEXT = function(response) { httr::content(response, as="text") },
		DATA_FRAME = function(response) { suppressWarnings(read.table(textConnection(httr::content(response, as="text")),sep="\t", header=TRUE, stringsAsFactors = FALSE, quote = "", comment.char = "", check.names=FALSE)) }
	)


	processRequest = function(httpCall) {
		# Request execution
		response = tryCatch(
			if (!authIsEnabled()) {
				httpCall()
			} else {
				httr::with_config(
					authAddHeaders(),
					httpCall()
				)
			},
			error = function(e) {
				.signalApiCondition(exceptions$CONNECTION_CURL, paste0(e$message, ", usually indicates a connectivity problem"), call = externalCallStack)
			}
		)

		# Checking HTTP status
		status = httr::status_code(response)
		statusMessage = httr::http_status(response)$message
		applicationError = ifelse(errorHandling$extractErrorFromJson, extractApplicationError(response), NA_character_)
		if(status==401) {
			.signalApiCondition(exceptions$AUTHENTICATION, "Authentication error, please login", call = externalCallStack, isRetriable = FALSE)
		} else if(status==403) {
			.signalApiCondition(exceptions$AUTHORIZATION, "Unauthorized: you don't have the required permissions", call = externalCallStack, isRetriable = FALSE)
		} else if(status >= 400) {
			ifelse(is.na(applicationError),
						 {
						 	responseText = strtrim(suppressMessages(httr::content(response, as="text")), trimUnparsableContentInErrorMessagesLength)
						 	.signalApiCondition(exceptions$APPLICATION_FAILURE, paste0(statusMessage, ", for url: ", response$url, "\nerror: ", responseText), call = externalCallStack, isRetriable = FALSE)
						 	},
						 .signalApiCondition(exceptions$APPLICATION_ERROR, applicationError, isRetriable = FALSE))
		} else if(status == 303) {
			if(grepl(response$headers$location, "login")) {
				.signalApiCondition(exceptions$AUTHENTICATION, "Authentication error, please login", call = externalCallStack, isRetriable = FALSE)
			} else {
				warning(paste("Redirecting from:", response$url, "to:", response$headers$location))
			}
		}

		# Handling application errors in successfull HTTP requests
		if(!is.na(applicationError)) {
			.signalApiCondition(exceptions$APPLICATION_ERROR, applicationError, call = externalCallStack)
		}

		response
	}

	attempts = 0
	requestFinished = FALSE
	result = NULL
	while (!requestFinished && attempts <= errorHandling$retries) {
		tryCatch( {
				response = processRequest(httpCall)
				requestFinished = TRUE
				responseSerializerImpl = responseSerializersFactory[[responseSerializer]]
				result = responseSerializerImpl(response)
				# print(paste("Result:", result))
			},
			RequestFailedError = function(e) {
				# print(paste("RequestFailedError handler called. Error:", e))
				if(attempts >= errorHandling$retries || !e$isRetriable) {
					requestFinished <<- TRUE
					errorMessage = e$message
					if(!is.na(errorHandling$message)) {
						errorMessage = paste0(errorHandling$message, ":\n", errorMessage)
					}
					result = handleError(errorMessage, errorHandling$onError, stackTrace = e$call)
				} else {
					attempts <<- attempts + 1
					message(paste0("Request failed with error: ", e$message, ", retrying in 5 seconds"))
					Sys.sleep(5)
				}
			},
			error = function(e) {
				requestFinished <<- TRUE
				if("SdkError" %in% class(e)) {
					stop(e)
				} else {
					errorMessage = e$message
					if(!is.na(errorHandling$message)) {
						errorMessage = paste0(errorHandling$message, ":\n", errorMessage)
					}
					result = stop(errorMessage)
				}
			}
		)
	}
	result
}

.assertUserAuthenticated = function(message=NULL) {
	url <- paste0(getSBserverURL(), "/api/v1/users/current")
	tryCatch({
		userInfo = .executeRequest(
			function() httr::GET(url, encode = "form"),
			responseSerializer = .responseSerializers$JSON
		)
	}, error = function(e) {
		if(!is.null(message)) {
			stop(message)
		} else {
			stop(e)
		}
	})

}

#### Project ####
.getProject = function(projectName) {
	url <- paste0(getSBserverURL(), "/api/v1/projects/", projectName)

	res = .executeRequest(
		function() httr::GET(url, httr::content_type_json()),
		errorHandling = .withErrorHandling(onError = .onErrorBehavior$SILENT),
		responseSerializer = .responseSerializers$TEXT
	)

	if(is.null(res)) {
		NULL
	} else {
		project = Project$new()
		project$fromJsonString(res)
		project
	}
}

.createProject = function(projectName, createdBy, description="", displayName="", domain = NULL) {
	url <- paste0(getSBserverURL(), "/api/v1/projects?exactProjectName=false")
	params = list(
		'name' = projectName,
    'displayName' = displayName,
		'created' = 0,
		'domain' = domain,
		'createdBy' = createdBy,
		'description' = description,
		'etag' = uuid::UUIDgenerate(),
		'resourceId' = uuid::UUIDgenerate()
	)

	body = rjson::toJSON(params)

	res = .executeRequest(
		function() httr::PUT(url, body = body, httr::content_type_json()),
		errorHandling = .withErrorHandling(onError = .onErrorBehavior$STOP),
		responseSerializer = .responseSerializers$TEXT
	)

	if (is.null(res)) {
		stop("Faild to create project")
	} else {
		project = Project$new()
		project$fromJsonString(res)
		project
	}
}

.getProjectRevisions = function(projectName) {
	url <- paste0(getSBserverURL(), "/api/v1/projects/", projectName, "/revisions?includeExtraProps=true")

	res = .executeRequest(
		function() httr::GET(url, httr::content_type_json()),
		errorHandling = .withErrorHandling(onError = .onErrorBehavior$SILENT),
		responseSerializer = .responseSerializers$JSON
	)

	if (is.null(res)) {
		list()
	} else {
		res
	}
}

.getProjectDatasets = function(projectName) {
	url = paste0(getSBserverURL(), "/api/v1/files?location=Project&project=", projectName)
	res = .executeRequest(
		function() httr::GET(url, httr::content_type_json()),
		errorHandling = .withErrorHandling(onError = .onErrorBehavior$STOP),
		responseSerializer = .responseSerializers$JSON
	)
	if (is.null(res)) {
		list()
	} else {
		res
	}
}
