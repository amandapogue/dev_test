#' SparkBeyond Dataset instance.
#'
#' @docType class
#' @keywords data
#' @return Object of \code{\link{R6Class}} with methods for Discovery Platform dataset.
#' @format \code{\link{R6Class}} object.
#' @field fileReference File Reference
#' @field project Project name.
#' @field parsingOptions Parsing options.
#' @field name Dataset name prefix.
#' @section Methods:
#' \describe{
#'   \item{\code{toJson()}}{Json representation of the current project instance.}
#'   \item{\code{fromJson(projectJson)}}{Set the current project instance fields with the values from the json.}
#'   \item{\code{uploadData(data, name)}}{Upload data to the project.}
Dataset <- R6::R6Class(
  "Dataset",
  public = list(
    fileReference = NULL,
    project = NULL,
    parsingOptions = NULL,
    name = NULL,
    initialize = function(fileReference, project) {
      self$name = fileReference$path
      self$fileReference = fileReference
      self$project = project
      self$parsingOptions = preProcessingControl()
    }
  )
)