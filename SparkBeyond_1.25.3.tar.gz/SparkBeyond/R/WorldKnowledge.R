
#' @title WorldKnowledgeObject
#' @description SB object that encapsulates a World Knowledge Object. 
#' Contains information about the object, parameters allowing to download the object and return a DataFrame holding the data. 
#' Additionally, contains a recommendation for context to use the data with. 
#' It can be passed as a context directly to learn function. 
#' It's also possible to pass it as data to any of the contexts based on data and override the context recommendations.
#'
#' @field id object id.
#' @field name object name
#' @field category object category (Geospatial, Financial etc.)
#' @field description description of the data in the object
#' @field contextType context type (LookUp, TimeSeries etc.) recommended to be used with the object
#' @field contextKeyColumns recommended context key columns
#' @field contextTimeColumn recommended context time column (if applicable)
#' @field rows number of rows in the object
#' @field columns number of columns in the object
#' @field sizeMb size of the original file in Mb
#' @field uploadedBy name of the user who has uploaded the object
#' @field updatedOn time when the object was last updated
#' 
#' @section Methods:
#' 
#' \subsection{\code{data()}}{
#' \emph{Get the data as DataFrame}
#' }
#' 
#' 
#' @usage
#' # WorldKnowledgeObject example
#' \donttest{
#' census = worldKnowledge$get$census
#' # Load the data from World Knowledge Object as DataFrame
#' df = census.data()
#' }
WorldKnowledgeObject <- R6::R6Class("WorldKnowledgeObject",
    lock_objects = TRUE,
    lock_class = TRUE,
    cloneable = FALSE,
    private = list(
        cachedData = NULL,
        contextProvider = NULL,
        convertContextType = function(){
        	if(self$contextType == "lookup") {
        		"LookupTables"
        	} else if(self$contextType == "timeSeries") {
        		if (length(self$contextKeyColumns) > 0) {
        			"TimeSeriesMap"
        		} else {
        			"TimeSeries"
        		}
        	} else {
        		"unknown"
        	}
        }
    ),
    public = list(
        id = NA_character_,
        name = NA_character_,
        category = NA_character_, 
        description = NA_character_,
        contextType = NA_character_,
        contextKeyColumns = list(),
        contextTimeColumn = NA_character_,
        rows = NA_integer_,
        columns = NA_integer_,
        sizeMb = numeric(),
        uploadedBy = NA_character_,
        updatedOn = NA_character_,
        url = NA_character_,
        
        initialize = function(id, name, category, description, contextType, contextKeyColumns, contextTimeColumn, rows, columns, sizeMb, uploadedBy, updatedOn, url) {
            "Initializes an DataSet with name"
            self$id <- id
            self$name <- name
            self$category <- category
            self$description <- description
            self$contextType <- contextType
            self$contextKeyColumns <- contextKeyColumns
            self$contextTimeColumn <- contextTimeColumn
            self$rows <- rows
            self$columns <- columns
            self$sizeMb <- sizeMb
            self$uploadedBy <- uploadedBy
            self$updatedOn <- updatedOn
            self$url <- url
        },
        data = function() {
        	if(is.null(private$cachedData)) {
        		private$cachedData = .downloadWorldKnowledgeObject(self$id)
        	}
        	private$cachedData
        },
        head = function(rows=5) {
        	head(self$data(), rows)
        },
        print = function() {
        		listToString = function(l) paste(sapply(names(l),function(x) paste(x,l[[x]], sep = ":")), collapse = ", ")
            str = paste("World Knowledge Object:\n id:", self$id,
            						"\n name:", self$name,
            						"\n category:", self$category, 
            						"\n description:", self$description,
            						"\n rows:", self$rows, 
            						"\n columns:", self$columns, 
            						"\n size:", self$sizeMb, " Mb", 
            						"\n contextKeyColumns:", listToString(self$contextKeyColumns),
            						"\n contextType:", self$contextType,
            						"\n uploadedBy:", self$uploadedBy,
            						"\n updatedOn:", self$updatedOn
            )
            str = ifelse(is.null(self$contextTimeColumn), str, paste(str, "\n contextTimeColumn:", self$contextTimeColumn))
            cat(str)
            invisible(self)
        },
        asContextProvider = function() {
					if(is.null(private$contextProvider)) {
						private$contextProvider = list(
								jsonClass="com.sparkbeyond.runtime.data.transform.WebFile",
								source=list(
									jsonClass="com.sparkbeyond.runtime.data.source.UrlFileDataSet",
									url=self$url
								),
								name=self$name
						)
					}
        	private$contextProvider
        },
				asContext = function() {
					list(
						data = NULL,
						contextProvider = self$asContextProvider(), 
						keyColumns = .wrapWithListIfNeeded(names(self$contextKeyColumns)),
						timeColumn = self$contextTimeColumn,
						name = self$id,
						contextTypes = list(private$convertContextType())
					)
				}
    )
)

.createWorldKnowledgeStructure = function(objects, metadataDf) {
	structure(
		class = c("WorldKnowledge"),
		list(get = objects, listAll=metadataDf)
	)
}


#' worldKnowledge
#' 
#' @description
#' Container for world knowledge objects that are collected and stored. 
#' These objects are initialized on login.
#' Each object has a designated type of context as well as key columns that are assigned to it by a curator. 
#' This allows easy usage as context as documented below. 
#' Additionally, they can be used as regular data frames in other context types.
#' 
#' @usage
#' worldKnowledge$get$census
#'   
#' worldKnowledge$get['census']
#'   
#' worldKnowledge$get$census$data()
#' 
#' @examples
#' Using one of the objects as a context
#' \donttest{
#'   model = learn(
#'     projectName = "zipcode_project",
#'     trainData = zip_data,
#'     target = "target",
#'     contextDatasets = list(worldKnowledge$get$census))
#' }
#' 
#' @format 
#' 
worldKnowledge <<- { warning("World Knowledge is not initialized. Please login in order to use it.") }

.updateWorldKnowledge = function() {
	metadata = .getWorldKnowledgeMetadata()
	# Populate worldKnowledge
	meta = metadata$metadata
	
	if(length(meta) ==0) {
		worldKnowledge <<- .createWorldKnowledgeStructure(list(), data.frame(id=character(0), name=character(0), sizeMb=numeric(0), category=character(0), context=character(0), rows=numeric(0), columns=numeric(0), uploadedBy=character(0), updatedOn=character(0), url=character(0)))
		if(!is.null(metadata$syncFailure)) {
			warning("Could not initialize World Knowledge due to the following error: ", metadata$syncFailure$error)
		}
	}
	else {
		names(meta)[names(meta) == "name"] <- 'id'
		names(meta)[names(meta) == "displayName"] <- 'name'
		names(meta)[names(meta) == "sizeBytes"] <- 'sizeMb'
		meta$sizeMb = ceiling(meta$sizeMb/1024/1024*100)/100
		
		# Flatten the context column
		meta$contextType = meta$context$contextType
		meta$contextKeyColumns = meta$context$keyColumns
		meta$contextTimeColumn = meta$context$timeColumn$name
		
		# Flatten the legal
		meta$license = meta$legal$license
		meta$licenseUrl = meta$legal$licenseUrl
		meta$licenseNotice = meta$legal$licenseNotice

		meta = meta[, sapply(meta, class) != "data.frame"]
		
		objects = apply(meta, 1, function(row){
			kColsDf = row[['contextKeyColumns']]
			keyColumnsList = setNames(as.list(kColsDf$columnType), kColsDf$name)
			WorldKnowledgeObject$new(row[['id']], row[['name']], row[['category']], row[['description']], row[['contextType']], keyColumnsList, row[['contextTimeColumn']], row[['rows']], row[['columns']], row[['sizeMb']], row[['uploadedBy']], as.POSIXct(row[['updatedOn']]/1000, origin="1970-01-01"), row[['url']])
		})
		
		ts = meta$updatedOn/1000
		meta$updatedOn <- as.POSIXct(ts, origin="1970-01-01")
		
		names(objects) <- meta$id
		rownames(meta) <- meta$id
		worldKnowledge <<- .createWorldKnowledgeStructure(objects, meta[names(meta) != "url"])
	}
	
	
}
