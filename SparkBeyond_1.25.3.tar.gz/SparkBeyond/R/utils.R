
# Change vector to list, wrap a single value with list
# NA and NULL are left unchanged, since they are allowed in API and server might handle them differently than an empty list
.wrapWithListIfNeeded = function(param) {
	if ("list" %in% class(param)) {
		param
	} else if (is.null(param) || is.na(param)) {
		param
	} else if (is.vector(param)) {
		as.list(param)
	} else {
		list(param)
	}
}