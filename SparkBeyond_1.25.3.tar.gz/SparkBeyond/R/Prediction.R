
#' @title PredictionJob
#' @description SB object that encapsulates a prediction job
#' 
#' @section Methods:
#' 
#' \subsection{\code{currentStatus()}}{
#' \emph{Print the current job status to console}
#' }
#' 
#' \subsection{\code{data(localFileName, runBlocking)}}{
#' \emph{Retreive the job result as a DataFrame. By default, if the data is not currently available, the function will block until the result is ready, and download it}
#' \itemize{
#'   \item \code{localFileName} - chose the name of the file the result will be stored in 
#'   \item \code{runBlocking} - if TRUE - wait for the result to be available and downloaded, and then return the result. If FALSE - return the data immediately if available, return NULL otherwise. Defaults to TRUE.  
#' }
#' }
#' 
#' \subsection{\code{cancel()}}{
#' \emph{Cancel the job}
#' }
#' 
#' \subsection{\code{jobReports()}}{
#' \emph{Browse the list of the available predict job reports.}
#' Job reports are available when prediction result is ready.
#' You can choose to view a specific report from the list of the available reports.
#' }
#' 
#' \subsection{\code{scoringReports(percentOfPopulationToPlot, downloadReports, downloadedFileName)}}{
#' \emph{Browse the list of the available scoring reports.}
#' Scoring reports are not available when prediction job finishes and are generated upon request.
#' You can get several reports for prediction results: lift plots, evaluation, etc.
#' Most of the reports require the target column to be present in the prediction input
#' You can choose to view a specific report from the list of the available reports.
#' \itemize{
#'   \item \code{percentOfPopulationToPlot} - percentage of population for lift plots. Defaults to 0.2.
#'   \item \code{downloadReports} Set to TRUE in order to download an archive file containing all the reports. Interactive list reports will not be shown in this case.
#'   \item \code{downloadedFileName} changes the downloaded reports archive file name, when \code{downloadReports} is set to TRUE, else is not used"
#' }
#' }
#' 
#' \subsection{\code{evaluate()}}{
#' \emph{Get prediction evaluation. Also available via scoringReports.}
#' }
#' 
#' @usage
#' # Prediction example
#' \donttest{
#' session = learn("titanic", getData("titanic_train"), target="survived")
#' 
#' # predict function returns a PredictionJob object
#' predictionJob = session$predict(getData("titanic_test"))
#' 
#' # currentStatus() function can be used to show job's status
#' predictionJob$currentStatus()
#' 
#' # Use data() function to retreive the job result as a DataFrame
#' data = predictionJob$data()
#' head(data)
#'
#' # It's possible to view the list of the available prediction job reports using jobReports() function and chose to view a specific report
#' predictionJob$jobReports()
#'
#' # You can view the list of the available prediction scoring reports using scoringReports() function and chose to view a specific report
#' predictionJob$scoringReports()
#' 
#' # You can use scoringReports(downloadReports=TRUE) to download a zip file containing all reports
#' predictionJob$scoringReports(downloadReports=TRUE)
#' 
#' # Prediction evaluation is available both as one of the scoring reports and via dedicated function, evaluate()
#' predictionJob$evaluate()
#' }
#' 
#' # A job can be canceled using the cancel() function
#' \donttest{
#' session = learn("titanic", getData("titanic_train"), target="survived")
#' predictionJob = session$predict(getData("titanic_test"))
#' predictionJob$cancel()
#' }
PredictionJob = R6::R6Class("PredictionJob",
		lock_objects = TRUE,
		lock_class = TRUE,
		cloneable = FALSE,
		private = list(
			jobId = NA_character_,
			totalRows = NA_integer_,
			job = NULL,
			dataFrame = NULL,
			reportJobsCache = list(),
			printCurrentState = function(state) {
				if (state$isEnqueued) {
					message("Prediction job is waiting in queue")
				} else if (state$isRunning) {
					status = .enrichPredictStatusFromJson(state$status)
					if (!status$builtContexts) {
						message(paste("Prediction job is running. Parsing contexts..."))
					} else {
						totalRowsMessage = ifelse(is.na(private$totalRows), "", paste0("out of ", private$totalRows))
						cat("\r", "Prediction job is running. So far processed", status$processedRows, totalRowsMessage, "rows\r")
					}
				} else if (state$isCompleted) {
					result = .jobResultFromJson(state$result)
					status = .enrichPredictStatusFromJson(state$status)
					
					.showEnrichPredictTyperErrorsOverview(status)
					
					if (result$isSucceeded) {
						totalRowsMessage = ifelse(is.na(private$totalRows), "", paste0(" out of ", private$totalRows))
						message(paste0("Prediction has finished successfully. Processed ", status$processedRows, totalRowsMessage, " rows",
													 ". Started: ", as.POSIXct(state$startedMillis, origin = "1970-01-01"),
													 ". Ended: ", as.POSIXct(state$endedMillis, origin = "1970-01-01")))
					} else {
						stop(paste0("Prediction failed: ", result$error, ". Worker ID: ", state$workerId, 
												". Started: ", as.POSIXct(state$startedMillis, origin = "1970-01-01"),
												". Ended: ", as.POSIXct(state$endedMillis, origin = "1970-01-01")))
					}
				} else {
					stop(paste("Unexpected job state:", state))
				}
			},
			
			executeReportsGeneration = function(percentOfPopulationToPlot = 0.2) {
				printCurrentEvaluationState = function(state) {
					if (state$isEnqueued) {
						message("Prediction reports job is waiting in queue")
					} else if (state$isRunning) {
						message("Prediction reports job is running...")
					} else if (state$isCompleted) {
						result = .jobResultFromJson(state$result)
						if (result$isSucceeded) {
							message("Prediction reports were generated successfully.")
						} else {
							stop(paste("Prediction reports generation failed:", result$error))
						}
					} else {
						stop(paste("Unexpected job state:", state))
					}
				}
				
				cachedJobId = private$reportJobsCache[[as.character(percentOfPopulationToPlot)]]
				
				cachedJobId = if (!is.null(cachedJobId)) {
					job = .initJob(cachedJobId)
					state = job$currentState()
					if (!is.null(state) && state$isCompleted) {
						cachedJobId
					} else {
						private$reportJobsCache[[as.character(percentOfPopulationToPlot)]] <- NULL
						NULL
					}
				}
				
				if (!is.null(cachedJobId)) {
					cachedJobId
				} else {
					jobState = .generatePredictionReports(private$jobId, percentOfPopulationToPlot = percentOfPopulationToPlot)
					evaluationJob = .initJob(jobState$jobId)
					
					successfulEvaluationJobId = NULL
					
					evaluationJob$poll(function(state) {
						printCurrentEvaluationState(state)
						
						if (state$isCompleted) {
							result = .jobResultFromJson(state$result)
							if (result$isSucceeded && !is.null(result$success$createdFilenames)) {
								private$reportJobsCache[[as.character(percentOfPopulationToPlot)]] = evaluationJob$jobId
								successfulEvaluationJobId <<- evaluationJob$jobId
							} else {
								stop(paste("Prediction reports generation failed with an error:", result$failure))
							}
						
							FALSE
						} else {
							TRUE
						}
					})
				
					successfulEvaluationJobId
				}
			}
		),
		public = list(
			initialize = function(jobId, totalRows = NA_integer_) {
				"Initializes a PredictionJob with jobId."
				private$jobId <- jobId
				private$totalRows <- totalRows
				private$job = .initJob(jobId)
			},
			
			print = function(...) {
				cat("Prediction job id: ", private$jobId, sep = "")
				invisible(self)
			},
			
			currentStatus = function() {
				"Get prediction job status - Started/Finished, number of lines processed, etc."
				jobState = private$job$currentState()
				private$printCurrentState(jobState)
			},
			
			data = function(localFileName = NA_character_, runBlocking=TRUE) {
				"Set \\code{localFileName} to change the default result file name. If \\code{runBlocking} is TRUE, block until the job finishes while showing processed rows counter, and return the result when available. If \\code{runBlocking} is FALSE return the data if available, else return NULL"
				
				if (!is.null(private$dataFrame)) {
					private$dataFrame
				} else if (runBlocking) {
					jobState = private$job$currentState()
					if (!jobState$isCompleted) {
						message("Blocking the R console until prediction is finished.")
					}
					
					private$job$pollState(function(state) {
						private$printCurrentState(state)

						if (state$isCompleted) {
							result = .jobResultFromJson(state$result)
							if (result$isSucceeded) {
								downloadUrl = paste0(getSBserverURL(),"/api/downloadJobResult/", private$jobId)
								outputName = ifelse(is.na(localFileName), paste("predicted", private$jobId, sep = "-"), localFileName)
								predictedFile = .download(downloadUrl, localFile = paste0(outputName, ".tsv.gz"), description = paste("prediction result for job:", private$jobId))
								private$dataFrame = read.table(predictedFile, sep = "\t", header = TRUE, stringsAsFactors = FALSE, comment.char = "")
							} else {
								stop(paste("Prediction failed with an error:", result$failure))
							}
							
							FALSE
						} else {
							TRUE
						}
					})
					private$dataFrame
					
				} else {
					message("Data isn't available locally. Use blockWaitingForData=TRUE to get the data when prediction is ready")
					NULL
				}
			},
			
			jobReports = function() {
				"Show interactive list of the available predict job reports - enter a report number to browse to the report."
				# Get prediction execution reports
				state = private$job$currentState()
				result = .jobResultFromJson(state$result)
				reportList = if (is.null(result$success$reportFilenames)) list() else result$success$reportFilenames
				
				reportList = reportList[reportList != "typerErrorsReport.json"]
				names(reportList) = NULL
				reportListWithIndex = cbind(paste0("[",1:length(reportList),"]"), reportList)
				reportListWithIndex = apply(reportListWithIndex,1,paste, collapse = " ")
				writeLines(paste(unlist(reportListWithIndex), collapse = "\n"))
				n <- readline("Enter a number of report to show or <enter> otherwise:")
				n <- ifelse(grepl("\\D",n),-1,as.integer(n))
				if (!is.na(n) && n >= 1 && n <= length(reportList)) {
					message(paste("Showing",n))
					.showPredictResultReport(private$jobId, reportList[n])
				}
			},

			scoringReports = function(percentOfPopulationToPlot = 0.2, downloadReports = FALSE, downloadedFileName = "prediction_reports") {
				"Show interactive list of the available prediction scoring reports - enter a report number to browse to the report. 
				\\code{percentOfPopulationToPlot} percentage of population for lift plots.
				\\code{downloadReports} Set to TRUE in order to download an archive file containing all the reports. Interactive list reports will not be shown in this case.
				\\code{downloadedFileName} changes the downloaded reports archive file name, when \\code{downloadReports} is set to TRUE, else is not used"
				
				completedReportsGenerationJobId = private$executeReportsGeneration(percentOfPopulationToPlot)
				
				if (downloadReports) {
					downloadUrl = paste0(getSBserverURL(),"/api/downloadJobResult/", completedReportsGenerationJobId)
					.download(downloadUrl, localFile = paste0(downloadedFileName, ".zip"), description = paste("prediction reports for job:", completedReportsGenerationJobId))
				} else {
					evaluationJob = .initJob(completedReportsGenerationJobId)
					state = evaluationJob$currentState()
					result = .jobResultFromJson(state$result)
					reportList = result$success$createdFilenames
					names(reportList) = NULL
					reportListWithIndex = cbind(paste0("[",1:length(reportList),"]"), reportList)
					reportListWithIndex = apply(reportListWithIndex,1,paste, collapse = " ")
					writeLines(paste(unlist(reportListWithIndex), collapse = "\n"))
					n <- readline("Enter a number of report to show or <enter> otherwise:")
					n <- ifelse(grepl("\\D",n),-1,as.integer(n))
					if (!is.na(n) && n >= 1 && n <= length(reportList)) {
						message(paste("Showing",n))
						.showPredictResultReport(evaluationJob$jobId, reportList[n])
					}
					reportList
				}
			},
			
			evaluate = function() {
				"Returns an evaluation object containing various information on the run including evaluation metric that was used, evaluation score, precision, confusion matrix, number of correct and incorrect instances, AUC information and more."
				completedReportsGenerationJobId = private$executeReportsGeneration()
				evaluation = .getPredictEvaluation(completedReportsGenerationJobId)
				if (evaluation$isRegression) {
					writeLines(evaluation$evaluation$summary)
				} else {
					writeLines(evaluation$evaluation$classDetails)
				}
				evaluation
			},

			cancel = function() {
				"Cancel the job"
				private$job$cancel()
			}
		)
)
