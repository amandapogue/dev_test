
#' @title EnrichmentJob
#' @description SB object that encapsulates a enrichment job
#' 
#' @section Methods:
#' 
#' \subsection{\code{currentStatus()}}{
#' \emph{Print the current job status to console}
#' }
#' 
#' \subsection{\code{data(localFileName, runBlocking)}}{
#' \emph{Retreive the job result as a DataFrame. By default, if the data is not currently available, the function will block until the result is ready, and download it}
#' \itemize{
#'   \item \code{localFileName} - chose the name of the file the result will be stored in 
#'   \item \code{runBlocking} - if TRUE - wait for the result to be available and downloaded, and then return the result. If FALSE - return the data immediately if available, return NULL otherwise. Defaults to TRUE.  
#' }
#' }
#' 
#' \subsection{\code{jobReports()}}{
#' \emph{Browse the list of the available enrich job reports.}
#' Job reports are available when enrichment result is ready.
#' You can choose to view a specific report from the list of the available reports.
#' }
#' 
#' \subsection{\code{cancel()}}{
#' \emph{Cancel the job}
#' }
#' 
#' @usage
#' # Enrichment example
#' \donttest{
#' # Learn
#' session = learn("titanic", getData("titanic_train"), target="survived")
#' 
#' # enrich function returns EnrichmentJob object
#' enrichmentJob = session$enrich(getData("titanic_test"))
#' 
#' # currentStatus() function can be used to show job's status
#' enrichmentJob$currentStatus()
#' 
#' # Use data() function to retreive the job result as a DataFrame
#' data = enrichmentJob$data()
#' head(data)
#' 
#' # You can  view the list of the available enrichment job reports using jobReports() function and chose to view a specific report
#' predictionJob$jobReports()
#' 
#' }
#' 
#' # A job can be canceled using the cancel() function
#' \donttest{
#' session = learn("titanic", getData("titanic_train"), target="survived")
#' enrichmentJob = session$enrich(getData("titanic_test"))
#' enrichmentJob$cancel()
#' }
EnrichmentJob = R6::R6Class("EnrichmentJob",
	 lock_objects = TRUE,
	 lock_class = TRUE,
	 cloneable = FALSE,
	 private = list(
	 	jobId = NA_character_,
	 	totalRows = NA_integer_,
	 	job = NULL,
	 	dataFrame = NULL,
	 	printCurrentState = function(state) {
	 		if (state$isEnqueued) {
	 			message("Enrichment job is waiting in queue")
	 		} else if (state$isRunning) {
	 			status = .enrichPredictStatusFromJson(state$status)
	 			if (!status$builtContexts){
	 				message(paste("Enrichment job is running. Parsing contexts..."))
	 			} else {
	 				totalRowsMessage = ifelse(is.na(private$totalRows), "", paste0("out of ", private$totalRows))
	 				cat("\r", "Enrichment job is running. So far processed", status$processedRows, totalRowsMessage, "rows\r")
	 			}
	 		} else if (state$isCompleted) {
	 			result = .jobResultFromJson(state$result)
	 			status = .enrichPredictStatusFromJson(state$status)
	 			.showEnrichPredictTyperErrorsOverview(status)
	 			if (result$isSucceeded) {
	 				totalRowsMessage = ifelse(is.na(private$totalRows), "", paste0(" out of ", private$totalRows))
	 				message(paste0("Enrichment has finished successfully. Processed ", status$processedRows, totalRowsMessage, " rows"))
	 			} else {
	 				stop(paste("Enrichment failed:", result$error))
	 			}
	 		} else {
	 			stop(paste("Unexpected job state:", state))
	 		}
	 	}
	 ),
	 public = list(
	 	initialize = function(jobId, totalRows = NA_integer_) {
	 		"Initializes an EnrichmentJob with jobId."
	 		private$jobId = jobId
	 		private$totalRows = totalRows
	 		private$job = .initJob(jobId)
	 	},
	 	
	 	print = function(...) {
	 		cat("Enrichment job id: ", private$jobId, sep = "")
	 		invisible(self)
	 	},
	 	
	 	currentStatus = function() {
	 		"Get Enrichment job status - Started/Finished, number of lines processed, etc."
	 		jobState = private$job$currentState()
	 		private$printCurrentState(jobState)
	 	},
	 	
	 	data = function(localFileName = NA_character_, runBlocking=TRUE) {
	 		"If \\code{runBlocking} is TRUE, block until the job finishes while showing processed rows counter, and return the result when available. If \\code{runBlocking} is FALSE return the data if available, else return NULL"
	 		if (!is.null(private$dataFrame)) {
	 			private$dataFrame
	 		} else if (runBlocking) {
	 			jobState = private$job$currentState()
				if (!jobState$isCompleted) {
	 				message("Blocking the R console until enrichment is finished.")
	 			}
				private$job$pollState(function(state) {
	 				private$printCurrentState(state)
					if (state$isCompleted) {
	 					result = .jobResultFromJson(state$result)
	 					if (result$isSucceeded) {
	 						downloadUrl = paste0(getSBserverURL(),"/api/downloadJobResult/", private$jobId)
	 						outputName = ifelse(is.na(localFileName), paste("enriched", private$jobId, sep = "-"), localFileName)
	 						enrichedFile = .download(downloadUrl, localFile = paste0(outputName, ".tsv.gz"), description = paste("enrichment result for job:", private$jobId))
	 						private$dataFrame = .loadEnrichedDataFrame(enrichedFile)
	 					} else {
	 						stop(paste("Enrichment failed with an error:", result$failure))
						}
	 					FALSE
	 				} else {
	 					TRUE
	 				}})
	 				private$dataFrame
	 			} else {
	 			message("Data isn't available locally. Use blockWaitingForData=TRUE to get the data when enriched data is ready")
	 			NULL
	 		}
	 	},
	 	
	 	jobReports = function() {
	 		"Show interactive list of the available enrich job reports - enter a report number to browse to the report."
	 		
	 		# Get enrichment execution reports
	 		state = private$job$currentState()
	 		result = .jobResultFromJson(state$result)
	 		reportList = if (is.null(result$success$reportFilenames)) list() else result$success$reportFilenames
	 		
	 		reportList = reportList[reportList != "typerErrorsReport.json"]
	 		names(reportList) = NULL
	 		reportListWithIndex = cbind(paste0("[",1:length(reportList),"]"), reportList)
	 		reportListWithIndex = apply(reportListWithIndex,1,paste, collapse = " ")
	 		writeLines(paste(unlist(reportListWithIndex), collapse = "\n"))
	 		n <- readline("Enter a number of report to show or <enter> otherwise:")
	 		n <- ifelse(grepl("\\D",n),-1,as.integer(n))
	 		if (!is.na(n) && n >= 1 && n <= length(reportList)) {
	 			message(paste("Showing",n))
	 			.showPredictResultReport(private$jobId, reportList[n])
	 		}
	 	},
	 	
	 	cancel = function() {
	 	  "Cancel the job"
	 		private$job$cancel()
	 	}
	 )
)

.loadEnrichedDataFrame = function(filePath) {
	df = read.table(filePath, sep = "\t", header = TRUE, comment.char = "")
	
	for (i in 1:ncol(df)) {
		if (length(levels(df[[i]])) == 1 && (levels(df[[i]]) == "false" || levels(df[[i]]) == "true")) {
			df[,i] = as.logical(as.character(df[,i]))
		} else if (length(levels(df[[i]])) == 2 && (levels(df[[i]]) == c("false","true"))) {
			df[,i] = as.logical(as.character(df[,i]))
		}
	}
	df
}