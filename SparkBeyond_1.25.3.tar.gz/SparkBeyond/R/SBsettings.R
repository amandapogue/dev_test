# Global variables

setSBserverHost = function(host = "http://127.0.0.1") {
	assign("SBhost", host, envir = globalenv())
	#print(paste("Setting server host to:", SBhost))
	return(SBhost)
}

getSBserverHost = function() {
	host = if (exists("SBhost")) SBhost else setSBserverHost()
	return(host)
}

getSBserverURL = function() {
	getSBserverHost()
}

printSBserverHost = function() {
	host = getSBserverHost()
	print(paste("Server host is:", host))
}

setSBserverPort = function(port = "9000") {
	assign("SBport", port, envir = globalenv())
	#print(paste("Setting server port to:", SBport))
	return(SBport)
}

getSBserverPort = function() {
	port = if (exists("SBport")) SBport else setSBserverPort()
	return(port)
}

printSBserverPort = function() {
	port = getSBserverPort()
	print(paste("Server port is:", port))
}

printSettings = function() {
	printSBserverHost()
	printSBserverPort()
}

#General:

#' A function to update the package from server
updatePackage = function() {
	.assertUserAuthenticated("You need to login in order to update the package")

	if (.isServerVersionOlderThan('1.11')) {
		stop(paste("Please use server version 1.11 or newer to update the client. Currently using server version:", SBServerVersion))
	} else {
		availableClientVersion = .getAvailablePackageVersion()
		clientVersion = .clientVersion()
		if (!is.null(availableClientVersion) && availableClientVersion == clientVersion) {
			message("No need to update the client, the latest version is already installed: ", availableClientVersion)
		} else if (!is.null(availableClientVersion) && availableClientVersion < clientVersion) {
			message("Currently installed version (", clientVersion, ") is newer then the version available for installation (", availableClientVersion, ")")

			userChoice = ""
			retryCount = 0
			while(userChoice != "y" && userChoice != "n" && retryCount < 3) {
				userChoice <- readline(prompt="Enter y to proceed or n to cancel the update: ")
				if(userChoice != "y" && userChoice != "n") {
					message("Invalid input")
					retryCount <- retryCount + 1
				}
			}

			if (userChoice=="y") {
				.install(SBhost)
			} else {
				message("Package update canceled")
			}
		} else {
			.install(SBhost)
		}
	}
}

#' login

#' Login to SparkBeyond server
#' @param username Username (usually in email format)
#' @param password Password, if not supplied - password massagebox is shown (available only from RStudio)
#' @param url URL or ip of the SparkBeyond Server. (Usually starts with http or https. May require also the port of the server).
#' @param apiKey API key (JWT token), self-issued by the user via Discovery UI for use with Python/R SDKs
login = function(username=NA, password=NA, url=NA, apiKey=NA, ...) {
	if(missing(url)) {
		extraParams <- list(...)
		if(!is.null(extraParams$domain)) {
			.Deprecated("url", old="domain")
			url = extraParams$domain
		}
		else {
			stop("No url was entered")
		}
	}

	if (nchar(url) < 6) stop("Please provide a url to log in to")
	if (substr(url, nchar(url), nchar(url)) == "/") url = substr(url, 1, nchar(url)-1) #remove trailing /
	if (substr(url, 1,4) != "http") warning("The provided url does not start with 'http' - please verify in case of failure")
	loginUrl <- paste0(url,"/login")

	if (!is.na(apiKey)) {
		loggedIn = authLogin(url, apiKey)

	} else {
		if (is.na(password)) {
			password = .rs.askForPassword("Please enter your SparkBeyond password:")
			if (is.null(password)) {
				stop("No password was entered")
			}
		}
		loggedIn = .usernamePasswordLogin(loginUrl, username, password)
	}
	
	setSBserverHost(url)

	if (!loggedIn) {
		stop ("Login failed. Please check your credentials.")
		
	} else {
		releaseNumber = serverVersion()$releaseNumber
		assign("SBServerVersion", package_version(releaseNumber), envir = globalenv())
		.assertServerVersionCompatibility()
		availableClientVersion = .getAvailablePackageVersion()
		currentUser()
		if(!is.null(availableClientVersion) && availableClientVersion > .clientVersion()) {
			message("Newer client version available: ", availableClientVersion, ", you can update by executing updatePackage()")
		}

		.updateWorldKnowledge()
	}
	loggedIn
}

.usernamePasswordLogin = function(loginUrl, username, password) {
	res = tryCatch(
		httr::POST(loginUrl, encode = "form", body = list(email=username, password=password, hash="")),
		error = function(cond) {
			if(grepl("certificate", cond)) {
				httr::set_config(httr::config(ssl_verifypeer = 0L, ssl_verifyhost = 0L))
				message("Please ask the system administrator to sign the SSL certificate.")
				httr::POST(loginUrl, encode = "form", body = list(email=username, password=password, hash=""))
			}
			else if (grepl("resolve host name", cond)) {
				stop(paste("SparkBeyond server does not exist at:",loginUrl),
						 call. = FALSE)
			} else if(grepl("connect to server", cond)) {
				stop(paste("Couldn't connect to the SparkBeyond server at:", loginUrl),
						 call. = FALSE)
			}
			else stop(cond)
		}
	)
	if(res$status_code >= 400) {
		stop(httr::content(res))
	}
	res$status_code == 200
}

#' Logout
logout = function() {
	logoutUrl <- paste0(getSBserverURL(), "/logout")
	loggedIn = currentUser(showInfo = FALSE)

	if(loggedIn) {
		res = .executeRequest(
		function() httr::GET(logoutUrl, encode = "form"),
		errorHandling = .withErrorHandling(onError = .onErrorBehavior$SILENT)
		)

		ifelse(!currentUser(showInfo = FALSE),
		{
			print ("You have been logged out")
			TRUE
		},
		FALSE
		)
	} else {
		print ("You are logged out")
	}
}

#' currentUser
#'
#' Current user information
currentUser = function(showInfo = TRUE) {
	currentUserUrl <- paste0(getSBserverURL(), "/api/v1/users/current")
	userInfo = .executeRequest(
	function() httr::GET(currentUserUrl, encode = "form"),
	errorHandling = .withErrorHandling(onError = .onErrorBehavior$SILENT),
	responseSerializer = .responseSerializers$JSON
	)
	if(!is.null(userInfo) && !is.null(userInfo$fullName)) {
		if (showInfo) print (paste("Hello", userInfo$fullName, "!  ", paste0("(",userInfo$email ,")"), " on ", getSBserverURL()))
		TRUE
	} else {
		if(showInfo) message("You are currently not logged in.")
		FALSE
	}
}

#' currentUser
#'
#' Current user email
currentUserEmail = function(showInfo = TRUE) {
	currentUserUrl <- paste0(getSBserverURL(), "/api/v1/users/current")
	userInfo = .executeRequest(
	function() httr::GET(currentUserUrl, encode = "form"),
	errorHandling = .withErrorHandling(onError = .onErrorBehavior$SILENT),
	responseSerializer = .responseSerializers$JSON
	)
	userInfo$email
}

#' projectRevisions
#'
#' Shows information on previous revisions of the project
#' @param projectName name of project
projectRevisions = function(projectName) {
	#if(!currentUser(FALSE)) stop("Please login")
	revisionsUrl = paste0(getSBserverURL(), "/analytics/revisions/", projectName)
	text = .executeRequest(
	function() httr::GET(revisionsUrl),
	responseSerializer = .responseSerializers$TEXT
	)

	if (nchar(text) == 0 || text == "[]") {
		warning(paste0("Failed to get revisions for project: ", projectName, ". Failed to parse the response:", text))
	}

	tryCatch({
		projectInfo = jsonlite::fromJSON(txt=text,simplifyDataFrame=TRUE)
		projectInfo$name = as.numeric(projectInfo$name)
		projectInfo[!names(projectInfo) == "jsonClass"]
	}, error = function(e) {
		warning(paste0("Failed to get revisions for project: ", projectName, ". Error: ", e$message))
	})
}


#' showProjectsLocks

#' Shows all the active projects that acquired a lock to prevent multiple project run under the same name
showProjectsLocks = function() {
	#if(!currentUser(FALSE)) stop("Please login")
	dblocksUrl <- paste0(getSBserverURL(),"/api2/dblocks")
	res = .executeRequest(
	function() httr::GET(dblocksUrl),
	responseSerializer = .responseSerializers$JSON
	)
}

#' removeProjectLock

#' remove a lock by id (see \code{\link{showProjectsLocks}})
removeProjectLock = function(lockId) {
	#if(!currentUser(FALSE)) stop("Please login")
	removeLocksUrl <- paste0(getSBserverURL(),"/api2/dblocks/",lockId,"/break")
	res = .executeRequest(function() httr::POST(removeLocksUrl))
}

#' showJobs

#' shows the status for all jobs
#'
#' A status of a job can be one of "queued", "running", "failed", "canceled", "done"
#' @param projectName Filter by project name.
#' @param revision Option to filter the returned list by revision number
#' @param status Filter by status.
#' @param showAllColumns A switch for whether to show only the job ID, project name, status, and elapsed (if available). Alternatively show all columns
#' @return a data frame with the jobs
showJobs = function(projectName = NA, revision = NA, status = NA, showAllColumns = FALSE) {
	if(!currentUser(FALSE)) stop("Please login")
	query = {if (!is.na(projectName) && is.na(status)) paste0("?project=",projectName)
	else if (is.na(projectName) && !is.na(status)) paste0("?status=",status)
	else if (!is.na(projectName) && !is.na(status)) paste0("?project=",projectName,"&status=",status)
	else ""}
	jobsUrl <- paste0(getSBserverURL(),paste0("/api2/jobs", query))
	jobs = .executeRequest(
	function() httr::GET(jobsUrl),
	errorHandling = .withErrorHandling(onError = .onErrorBehavior$SILENT),
	responseSerializer = .responseSerializers$JSON
	)

	finalJobs = if (length(jobs) > 0) {
		if (showAllColumns) jobs else {
			showCols = c("id", "project")
			if ("revision" %in% colnames(jobs)) showCols = c(showCols, "revision")
			if ("status" %in% colnames(jobs)) showCols = c(showCols, "status")
			if ("elapsed" %in% colnames(jobs)) showCols = c(showCols, "elapsed")
			jobs[,showCols]
		}
	} else {
		NULL
	}
	if ("revision" %in% colnames(finalJobs)) {
		finalJobs$revision = as.numeric(finalJobs$revision)
		if (!is.na(revision)) finalJobs = finalJobs[finalJobs$revision == revision,]
	}
	finalJobs
}

#' showJobById

#' get information for a specific job by job ID
#' @param jobId. The id of the job as defined by \code{\link{showJobs}}
showJobById = function(jobId) {
	#if(!currentUser(FALSE)) stop("Please login")
	jobsUrl <- paste0(getSBserverURL(),paste0("/api2/jobs/", jobId))
	.executeRequest(
	function() httr::GET(jobsUrl),
	errorHandling = .withErrorHandling(extractErrorFromJson = FALSE),
	responseSerializer = .responseSerializers$JSON
	)
}

#' cancelJob

#' cancels a queued job by a job ID
#' @param jobId. The id of the job as defined by \code{\link{showJobs}}
#' @return TRUE if succeeded. FALSE otherwise.
cancelJob = function(jobId) {
	res = .cancelJob(jobId, onError = .onErrorBehavior$SILENT)

	ifelse(!is.null(res) && res$status == 200, {
		print(paste("Job", jobId, "was canceled"))
		TRUE
	},{
		print(paste("Unable to cancel job", jobId, ". (Does this jobId exist in showJobs()?)"))
		#print(httr::content(res, as="text"))
		FALSE
	})
}

#' A function to clear the cache of a specific project
#' @param projectName The project name to clear (e.g., "titanic").
#' @return The response from the server.
clearCache = function(projectName) {
	#if(!currentUser(FALSE)) stop("Please login")
	cleanCacheUrl <- paste0(getSBserverURL(),"/api/cleanCache/",projectName)
	res = .executeRequest(
	function() httr::GET(cleanCacheUrl, httr::content_type_json()),
	errorHandling = .withErrorHandling(onError = .onErrorBehavior$SILENT)
	)
	if (!is.null(res) && res$status == 200) paste("Cleared:",projectName) else "Something went wrong"
}


#' A function to check whether the server is alive
#' @return The response from the server.
isServerAlive = function() {
	heartbeatUrl <- paste0(getSBserverURL(),"/api/heartbeat")
	res = .executeRequest(
	function() httr::GET(heartbeatUrl, httr::content_type_json()),
	errorHandling = .withErrorHandling(onError = .onErrorBehavior$SILENT),
	responseSerializer = .responseSerializers$TEXT
	)
	!is.null(res)
}

isKnowledgeServerAlive = function() { #add help, match with engine version
	if(!currentUser(showInfo = FALSE)) stop("This function requires you to be logged in")
	knowledgeServerPingUrl <- paste0(getSBserverURL(),"/knowledge/ping")
	content = .executeRequest(
	function() httr::GET(knowledgeServerPingUrl, httr::content_type_json()),
	responseSerializer = .responseSerializers$JSON
	)

	if(!content$allConnected){
		warning(paste(content$connectionTest$loginUrl, content$connectionTest$isConnected))
		for(connection in content$connectionTest$nextConnections) {
			warning(paste(connection$loginUrl, connection$isConnected))
		}
	}
	content$allConnected
}

#' A function to get the server version information
#' @return The server version information.
serverVersion = function() {
	buildInfoUrl <- paste0(getSBserverURL(),"/buildInfo")
	.executeRequest(
	function() httr::GET(buildInfoUrl, httr::content_type_json()),
	errorHandling = .withErrorHandling(onError = .onErrorBehavior$SILENT),
	responseSerializer = .responseSerializers$JSON
	)
}

#######################################################

doesFileExistOnServer = function(projectName, path) {
	#if(!currentUser(FALSE)) stop("Please login")
	serverUrl = getSBserverURL()
	CheckFileUrl = paste0(serverUrl, "/api/v1/files/Project/",path,"?project=",projectName)

	res = httr::HEAD(CheckFileUrl)

	if (res$status==200 && res$url == serverUrl) { #not logged in the first time
		res = httr::GET(CheckFileUrl)	#a the second time
		if (res$status==200 && res$url == serverUrl) stop("This operation requires authentication, please log in first")
	}
	res$status==200 && CheckFileUrl == res$url
}

.handleData = function(data, projectName, name, emptyValuePolicy = NULL, detectTypes=FALSE) {
  fileReference = uploadToServer(data, projectName, name)
  if (.isServerVersionOlderThan("1.23")) {
    .LocalFile$new(fileReference$path, fileReference, emptyValuePolicy)$toJson()
  }else {
    .createTabularInput(name = fileReference$path, fileReference = fileReference, emptyValuePolicy = emptyValuePolicy, detectTypes = detectTypes)$toJson()
  }
}

#' uploadToServer
#'
#' @param data dataFrame to be written to the server
#' @param projectName the name of the project to save the data under
#' @param name the prefix of the file name in which the data will be saved
uploadToServer = function(data, projectName, name) {
	.assertUserAuthenticated()  # workaround to allow quicker failure on large uploads
	if (length(class(data)) == 1 && class(data) == "character") data
	else {
		if (!"data.frame" %in% class(data) && !is(data, "Dataset")) stop("The provided data should of type data.frame, character or Dataset")

		filename = NULL
		compress = getOption("sparkbeyond.compressedUpload", default = TRUE)

		if(is(data, "Dataset")) filename = data$name
		else{
			#Upload optimization for large dataframes
			estimatedDataFrameSizeInMemory = utils::object.size(data)

			hash = digest::digest(data)
			filename =	if(compress) {
				paste0(name, "_", hash, ".tsv", ".gz")
			} else {
				paste0(name, "_", hash, ".tsv")
			}
		}
		fileServerPath = paste0("/uploaded/", filename)
		if(doesFileExistOnServer(projectName, filename)) {
			.FileReference$new("Project", filename, projectName)
		} else {
			tempFilePath = paste0(tempdir(), "/", filename)

			fixDataBeforeUpload = function(x){
				if(is.factor(x)) {
					as.character(x)
				} else if (class(x) == "Date" || class(x) == "POSIXct") {
					as.character(x, format = "%b %d, %Y %I:%M:%S%p %Z")
				} else if(is.character(x)) {
					gsub("\\\\", "\\\\\\\\",
					gsub("\'", "\\\\'",
					gsub('\"', '\\\\"',
					gsub("\r","\\\\r",
					gsub("\n","\\\\n",
					gsub("\f","\\\\f",
					gsub("\b","\\\\b",
					gsub("\v","\\\\v",
					gsub("\t","\\\\t", x)
					))))))))
				}
				else if(is.list(x)) {
					writeList = function(xi) {
						content = paste0(fixDataBeforeUpload(xi),collapse = ",")
						paste0("[",content,"]")
					}
					sapply(x, writeList)
				}
				else {
					x
				}
			}

			#### fix data before upload####
			data = data.frame(sapply(data, fixDataBeforeUpload))

			if(compress) {
				message(paste0("Compressing ", name, " before upload. Estimated size in memory: ", format(estimatedDataFrameSizeInMemory, units = "auto")))
				write.table(data, file=gzfile(tempFilePath), sep="\t", row.names=FALSE, quote = TRUE, qmethod = "escape")
				message(paste0("Compressed ", name, ". File size: ", utils:::format.object_size(file.info(tempFilePath)$size, units = "auto")))
			}
			else {
				message(paste0("Saving ", name, " before upload. Estimated size in memory: ", format(estimatedDataFrameSizeInMemory, units = "auto")))
				data.table::fwrite(data, file = tempFilePath, sep = "\t", row.names = FALSE, quote = TRUE, qmethod = "escape")
				message(paste0("Saved ", name, ". File size: ", utils:::format.object_size(file.info(tempFilePath)$size, units = "auto")))
			}

			uploadResult = uploadFile(tempFilePath, projectName, filename, checkIfExists = FALSE)
			file.remove(tempFilePath)
			uploadResult

		}

	}
}

#' uploadFileToServer
#'
#' @param filePath relative or absolute path to the file that should be upoloaded to the server
#' @param projectName the name of the project to save the data under
#' @param name the prefix of the file name in which the data will be saved
uploadFileToServer = function(filePath, projectName, name=NA, generateHash=TRUE) {
	.assertUserAuthenticated()   # workaround to allow quicker failure on large uploads
	originalFileName = basename(tools::file_path_sans_ext(filePath, compression = TRUE))
	originalFileNameWithExt = basename(filePath)
	originalFileExt = stringr::str_replace(originalFileNameWithExt, originalFileName, "")

	resourceName = if(generateHash) {
		hash = tools::md5sum(filePath)
		resourceName = paste0(originalFileName, "_", hash, originalFileExt)
	} else {
		originalFileNameWithExt
	}

	if(!is.na(name)) {
		resourceName = paste0(name, "_", resourceName)
	}

	uploadFile(filePath, projectName, resourceName)
}

#' uploadFile
#'
#' @param filePath relative or absolute path to the file that should be upoloaded to the server
#' @param projectName the name of the project to save the data under
#' @param resourceName resource name on server
#' @param checkIfExists check if the file was already uploaded to server
uploadFile = function(filePath, projectName, resourceName, checkIfExists=TRUE) {
	filename = basename(filePath)
	serverPath = paste0("/uploaded/", resourceName)

	if(checkIfExists && doesFileExistOnServer(projectName, resourceName)) {
		.FileReference$new("Project", resourceName, projectName)
	} else {
		uploadBody <- httr::upload_file(path = filePath)

		uploadUrl = paste0(getSBserverURL(),"/api/v1/files/Project/", resourceName,"?project=",projectName,
		"&autoRename=true&createProjectIfAbsent=true")

		progressBarConfig = httr::progress(type = "up")

		message(paste("Starting to upload", filename))
		response = .executeRequest(
            function() httr::PUT(url = uploadUrl, body = uploadBody, config = progressBarConfig),
            errorHandling = .withErrorHandling(retries = 2),
            responseSerializer = .responseSerializers$JSON
		)
		.FileReference$new(response$saved$location, response$saved$path, response$saved$projectName)
	}
}


#' getProjectDatasets
#'
#' Fetch a list of datasets uploaded to the project
#'
#' @param projectName The project name
getProjectDatasets = function(projectName) {
	res = .getProjectDatasets(projectName)

	if(length(res) == 0) {
		res
	}	else {
		res = apply(res, 1, function(file){
			fileReference = .FileReference$new(file[[1]], file[[2]], projectName)
			Dataset$new(fileReference = fileReference, project = projectName)
		})
		names(res) = unlist(lapply(res, function(x){
			unlist(strsplit(x$name, "\\."))[1]
		}))
		res
	}
}

.createTabularInput = function(name, fileReference, emptyValuePolicy, detectTypes) {
  localFileSource = .LocalFileSource$new(fileReference)
  parsingSettings = .detectParsingSettings(localFileSource$toJson())

  parsingSettings$format$isQuoted = TRUE
  parsingSettings$format$separator = "\\t"
  parsingSettings$format$useEscaping = TRUE

  formattedSource = .FormattedSource$new(localFileSource, parsingSettings)

  tabularInput = .TabularInput$new(name = name,
                                   source = formattedSource)

  if (!detectTypes) {
    tabularInput
  } else {
    typeDetectionSettings = list(
      emptyValuePolicy=emptyValuePolicy,
      customEmptyValues=NULL
    )
    typeAndTransformersDetectionSettings = list(typeDetectionSettings=typeDetectionSettings,
                                                generateColumnTransformations=TRUE)
    typingAndTransformationSettings = .detectTypingSettings(formattedSource$toJson(), typeAndTransformersDetectionSettings)

    .TypedTabularInput$new(tabularInput = tabularInput,
                           typingAndColumnTransformationSettings = typingAndTransformationSettings,
                           typeAndTransformationDetectionSettings = typeAndTransformersDetectionSettings)
  }
}

.detectTypingSettings = function(formattedSource, typeAndTransformersDetectionSettings){
  typeDetectionRequest = list(
    source = formattedSource,
    typeAndTransformationDetectionSettings = typeAndTransformersDetectionSettings
  )
  requestUrl = paste0(getSBserverURL(),"/api2/detectTypingSettings/",
                      formattedSource$source$location$project,
                      "/1")

  res = .executeRequest(
    function() httr::POST(url = requestUrl,
                          body = rjson::toJSON(typeDetectionRequest),
                          httr::content_type_json()),
    responseSerializer = .responseSerializers$JSON_RAW
  )
  res
}

.detectParsingSettings = function(localFileSource) {
  requestUrl = paste0(getSBserverURL(),"/api2/detectParsingSettings/",
                      localFileSource$location$projectName,
                      "/1")
  res = .executeRequest(
    function() httr::POST(url = requestUrl,
                          body = rjson::toJSON(localFileSource),
                          httr::content_type_json()),
    responseSerializer = .responseSerializers$JSON
  )
  res
}

.onLoad <- function(libname = find.package("SparkBeyond"), pkgname = "SparkBeyond") {
	httr::set_config(httr::add_headers('X-Requested-With' = 'XMLHttpRequest', 'X-SparkBeyond-Client' = paste('R SDK', utils::packageVersion('SparkBeyond'))))
	packageStartupMessage("SparkBeyond R SDK version: ", utils::packageVersion('SparkBeyond'))
	packageStartupMessage("Check out all the new updates in SparkBeyond latest release: https://knowledgebase.sparkbeyond.com/kb/16000050303")
}
