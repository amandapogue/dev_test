#' The name of the global environment variable where the authentication instance is stored
.authInstanceName <- "SBauth"


#' Authentication support for JWT with Keycloak 
#'
#' @docType class
#' @return Object of \code{\link{R6Class}} with methods JWT authentication, for internal use by the SDK.
#' @format \code{\link{R6Class}} object.
#' @field discoveryUrl the base URL of the Discovery Platform, e.g. http://localhost:9000
#' @field realm the name of the Keycloak realm used by the Discovery Platform, usually "sparkbeyond"
Auth <- R6::R6Class(
	"Auth",
	public = list(
		discoveryUrl = NULL,
		realm = NULL,
		
		initialize = function(discoveryUrl, apiKey) {
			self$discoveryUrl <- discoveryUrl
			private$offlineToken <- apiKey
			settings <- .loadKeycloakSettings(discoveryUrl)
			stopifnot(!is.null(settings$serverUrl))
			self$realm <- settings$realm
			private$keycloakUrl <- settings$serverUrl
			private$publicKey <- .loadPublicKey(private$buildOpenIdUrl("certs"))
		}
	),
	
	active = list(
		#' Get a valid acess token as string, refresh if necessary
		accessToken = function(value) {
			stopifnot(missing(value)) # this active field is read-only
			if (is.null(private$.accessTokenParsed) || .isExpired(private$.accessTokenParsed)) {
				token <- .refreshAccessToken(private$buildOpenIdUrl("token"), private$offlineToken)
				private$.accessTokenParsed <- jose::jwt_decode_sig(token, private$publicKey)
				private$.accessTokenString <- token
			}
			private$.accessTokenString
		}
	),
	
	private = list(
		#' The API key as received when this class is instantiated during login
		offlineToken = NULL,
		
		#' Base URL of the Keycloak authentication API, e.g. http://localhost:8080/auth
		keycloakUrl = NULL,
		
		#' Public key matching the private key Keycloak uses to sign JWT (multiple keys are not supported)
		publicKey = NULL,
		
		#' The value of the current access token as string
		.accessTokenString = NULL,
		
		#' The value of the current access token as parsed object
		.accessTokenParsed = NULL,
		
		#' Compile a URL for an OpenID-Connect endpoint provided by Keycloak
		#' @param endpoint name of the desired endpoint as string, e.g. "token", "certs", etc.
		buildOpenIdUrl = function(endpoint) {
			stopifnot(!is.null(private$keycloakUrl))
			url <- httr::parse_url(private$keycloakUrl)
			url$path <- paste0(.stripTrailingSlash(url$path), sprintf("/realms/%s/protocol/openid-connect/%s", self$realm, endpoint))
			httr::build_url(url)
		}
	)
)


.stripTrailingSlash = function(s) {
	gsub("/$", "", s)
}

#' Load Keycloak settings from the Discovery Platform (unsecured endpoint)
.loadKeycloakSettings = function(discoveryUrl) {
	url <- httr::parse_url(discoveryUrl)
	url$path <- paste0(.stripTrailingSlash(url$path), "/keycloak/settings")
	httr::content(httr::GET(httr::build_url(url)), "parsed")
}

#' Load a single public key from Keycloak - supporting more than one is not implemented.
#' If we reach a situation where we need to start rotating keys, this logic must be replaced
#' with an implementation capable of loading a number of keys and returning the one that 
#' matches the one used in the offline token (API key).
.loadPublicKey = function(certsUrl) {
	keys <- httr::content(httr::GET(certsUrl), "parsed")$keys

	# Handling more than one public key is not implemented, stop if necessary
	stopifnot(length(keys) == 1)
	
	# Dump to a file to make use of read_jwk(), as the jose library has no other functions to decode JWK
	keyFile <- tempfile()
	write(rjson::toJSON(keys[[1]]), keyFile)
	jose::read_jwk(keyFile)
}

#' Make a request to the token endpoint to refresh and return a valid access token
#' @param tokenUrl URL of the Keycloak token endpoint, such as http://localhost:8080/auth/realms/master/protocol/openid-connect/token
#' @param refreshToken the refresh token to use, in this context would contain the offline token (API key)
#' @param clientId the Keycloak client ID of this SDK, typically "discovery-sdk"
.refreshAccessToken = function(tokenUrl, refreshToken, clientId = 'discovery-sdk') {
	response = httr::POST(
		tokenUrl,
		encode = "form",
		body = list(
			client_id = clientId,
			grant_type = "refresh_token",
			refresh_token = refreshToken
		)
	)
	stopifnot(response$status_code == 200)
	httr::content(response, "parsed")$access_token
}


#' Check if a token has expired.
#' Note: if the token is set never to expire (exp=0), this check passes.
#' @param token token object with at least the \code{exp} property
#' @param allowedClockSkew permitted clock skew between the issuer of the token and this machine, in seconds 
.isExpired = function(token, allowedClockSkew = 5) {
	(token$exp > 0) && (as.integer(as.POSIXct(Sys.time())) + allowedClockSkew> token$exp)
}

#' Login using JWT authentication, follows the same semantics as the legacy login process.
#' This basically boils down to creating a global instance of the authentication class.
authLogin = function(discoveryUrl, apiKey) {
	auth <- Auth$new(discoveryUrl, apiKey)
	assign(.authInstanceName, auth, envir = globalenv())
	TRUE
}

#' Return httr headers that include authorization with the current token
authAddHeaders = function() {
	stopifnot(authIsEnabled())
	httr::add_headers('Authorization' = sprintf("Bearer %s", get(.authInstanceName)$accessToken))
}

#' Global helper to test if the new JWT authentication with Keycloak is currently in use
authIsEnabled = function() {
	exists(.authInstanceName)
}
