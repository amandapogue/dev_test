#' SB object that encapsulates a session
#' @field projectName the name of the project that this Session object is part of
#' @field revision an incremental number assigned to each learning iteration for this project
#' @examples
#' # Learning example
#' \donttest{
#' # Create a Session object from scratch
#' session = Session("project name", revision_id)
#' # Learn
#' session = learn("titanic", getData("titanic_train"), target="survived")
#' # Enrich
#' enrichmentJob = session$enrich(getData("titanic_train"), featureCount = 10)
#' enriched = enrichmentJob$data()
#' colnames(enriched)
#' # Predict
#' predictionJob = session$predict(getData("titanic_test"))
#' predicted = predictionJob$data()
#' colnames(predicted)
#' predicted[1:5,c("survived_predicted", "probability_0", "probability_1")]
#' #Evaluate
#' eval = session$evaluate()
#' #Show reports
#' session$reports()
#' session$showFeaturesTrain()
#' session$showConfusionMatrix()
#' }

Session = methods::setRefClass("Session",
    fields = list(
      artifact_loc = "character",
      jobId = "character",
      projectName = "character",
      revision = "numeric",
      schema = "list"
    ),
    methods = list(
      initialize = function(nameOfProject = NA, revisionNumber = NA, artifact_loc = NA, jobId = NA_character_) {
        "initializes a session using a projectName and revision number."
        if (!is.na(nameOfProject) && !is.na(revisionNumber)) {
        	artifact_loc <<- paste0(nameOfProject,"/",revisionNumber)
        	projectName <<- nameOfProject
        	revision <<- as.numeric(revisionNumber)
        	jobs = showJobs(projectName = projectName) #currently not using revision for backward compatibility 
        	if ("revision" %in% colnames(jobs)) {
        		jobId <<- as.character(jobs[jobs$revision == revision,]$id)
        	}
        } else {
	        artifact_loc <<- artifact_loc
	        tokens = strsplit(x = artifact_loc, split = "/")[[1]]
	        projectName <<- tokens[length(tokens) - 1]
	        revision <<- as.numeric(tokens[length(tokens)])
	        jobId <<- jobId
        }
        schema <<- list()
      },

      waitForProcess = function() { #TODO: number of mintues as parameter?
        "Blocking the R console until session is finished."
        serverResponded = FALSE
        i = 0
        curStreamingLine = 0
        curStatus = ""
        hasShownInputSchema = FALSE
        hasShownFeatures = FALSE
        isRunning = FALSE
        lastQueuePosition = -1
        message("You are now running in a Blocking Mode")
				message("In order to see the job queue, terminate the current command and run showJobs(status='queued')")
                
        readStreamingAPI = function(prevLine = 0) {
        	url = paste0(getSBserverURL(),"/api/notificationsLog/",projectName,"/",revision, "?path=UInotification.log&skipLines=",prevLine)
        	
        	txt = .executeRequest(
        		function() httr::GET(url),
        		errorHandling = .withErrorHandling(onError = .onErrorBehavior$SILENT),
        		responseSerializer = .responseSerializers$TEXT
        	)

        	if (!is.null(txt) && nchar(txt) > 0) {
        		message(txt)
        		length(strsplit(x = txt, split = "\n")[[1]]) # returning the number of lines read
        	} else {
        	    0
        	}
        }
        
        printFile = function(filename, onError = .onErrorBehavior$WARNING) {
            reportPath = paste0("/reports/", filename)
            reportText = .getNotificationLogReport(projectName, revision, path = reportPath, responseSerializer = .responseSerializers$TEXT, onError = onError)
            if (!is.null(reportText)) {
                writeLines(reportText)
                TRUE
            } else {
                FALSE
            }
        }
				
        queuedStatus = function() {
            queuedJobs = showJobs(status = "queued")
            if (!is.null(queuedJobs) && !is.na(jobId) && length(which(queuedJobs$id == jobId)) > 0) {
                curQueuePosition = which(queuedJobs$id == jobId)
            if (curQueuePosition != lastQueuePosition) {
                    message(paste("Learning job (", jobId ,") position in the queue is", curQueuePosition))
            }
                curQueuePosition
            }
        }
				
        runningStatus = function(curStreamingLineParam) {
            curStreamingLineAggregate = curStreamingLineParam + readStreamingAPI(curStreamingLineParam)

            curStatus = status()

            internalHasShownInputSchema = hasShownInputSchema
            if (!internalHasShownInputSchema) {
                internalHasShownInputSchema = printFile("preProcessing/inputSchema.txt", onError = .onErrorBehavior$SILENT)
            }
            internalHasShownFeatures = hasShownFeatures
            if (!internalHasShownFeatures) {
                f = features()
                if (!is.null(f)) {
                    featuresCount = nrow(f)
                    cntToShow = min(featuresCount, 50)
                    message(paste("Printing top", cntToShow, "features out of", featuresCount))
                    print(f[1:cntToShow,c("idx","feature","RIG", "lin. score", "support")]) #TODO: need to understand how to show this properly as a message
                    internalHasShownFeatures = TRUE
                }
            }

            list(curStatus = curStatus,
                     curStreamingLine = curStreamingLineAggregate,
                     hasShownInputSchema = internalHasShownInputSchema,
                     hasShownFeatures = internalHasShownFeatures
            )
        }
					
		jobFinished = FALSE
		finalStatus = NA
        while (!jobFinished) {
          i = i + 1
          
        	newCurStatus = showJobById(jobId)$status
        	switch(newCurStatus, 
        				 queued = {
        				 		lastQueuePosition = queuedStatus()
        				 },
        				 running = {
        				 		retStatuses = runningStatus(curStreamingLine)
        				 		curStreamingLine = retStatuses$curStreamingLine
        				 		hasShownInputSchema = retStatuses$hasShownInputSchema
        				 		hasShownFeatures = retStatuses$hasShownFeatures
        				 },
        				 failed = {
        				 		finalStatus = "Failed"
        				 		writeLines(showJobById(jobId)$error)
        				 		jobFinished = TRUE
        				 },
        				 canceled = {
        				 		message("Learning session was cancelled")
        				 		finalStatus = "Cancelled"
        				 		jobFinished = TRUE
        				 },
        				 done = {
        				 		runningStatus(curStreamingLine) # check to see if there are any last prints to do
        				 		printFile("model/evaluation.txt")
        				 		finalStatus = "Done"
        				 		jobFinished = TRUE
        				 },
        				 terminated = {
          				 	message("Learning session was terminated")
          				 	finalStatus = "Terminated"
          				 	jobFinished = TRUE
        				 }
        	)
           
          if (!jobFinished) {
          	secs = min(i*(3), 10)
          	Sys.sleep(secs)
          }
        }
				finalStatus
      },

      status = function() {
        "Checking the status of the session."
        if (!isServerAlive()) stop(paste("Server", getSBserverHost(), "is unavailable."))
      },

			################################## enrich #####################
      enrich = function(data, featureCount = NA,  contextDatasets = NULL , includeOriginals = FALSE, columnsWhiteList = NA, outputName = "enriched", runBlocking = TRUE, linesForContextMatchReport = NA_integer_, enforceBooleanNumeric = NULL, ...) {
        "Returns a data frame containing the enrichedData. 
        \\code{data} is a dataframe to be enriched.
        \\code{featureCount} set in order to limit the number of returned features.
        \\code{includeOriginals} set to TRUE in order to include the original columns in the enriched dataset.
        \\code{columnsWhiteList} - specify the original columns to be included in the result.
      	\\code{outputName} set to change the default result file name
      	\\code{linesForContextMatchReport} - number of rows to use for context match report, the default is 50000
      	\\coed{enforceBooleanNumeric} - if True, convert numeric features to boolean features with an optimal global
                cut-off point. If False, leave as numeric. If None, act as defined during training."
      	
        extraParams = list(...)
        # Experimental, not documented flag
        includeTyperErrorReport = if (!is.null(extraParams$includeTyperErrorReport)) {
        	includeTyperErrorReport = extraParams$includeTyperErrorReport
        	extraParams = extraParams[names(extraParams) != "includeTyperErrorReport"]
        	includeTyperErrorReport
        } else {
        	NULL
        }
        
        if (length(extraParams) > 0) {
        	warning("Unexpected parameters were passed to enrich function: ", paste(names(extraParams), collapse = ", "))
        }
                
        input = .handleData(data = data, projectName = projectName, name = "enrich")
       
        contextDatasets = .handleContexts(contextDatasets, projectName = projectName)
        
        params <- list(projectName = projectName,
        							revision = revision,
        							featureCount = featureCount,
        							outputName = outputName,
        							includeOriginals = includeOriginals,
        							columnsWhiteList = columnsWhiteList,
        							fileEscaping = FALSE,
        							contextDatasets = contextDatasets,
        							linesForContextMatchReport = linesForContextMatchReport,
        							includeTyperErrorReport = includeTyperErrorReport,
        							enforceBooleanNumeric = enforceBooleanNumeric
		)
        params = params[!is.na(params)]

      	params$input = input
      	message(paste("Enriching ",params$input$name))
        
        url <- paste0(getSBserverURL(),"/api/enrich")
        message(paste("Calling:", url))

        body = rjson::toJSON(params)
        res = .executeRequest(
        	function() httr::POST(url, body = body, httr::content_type_json()),
        	errorHandling = .withErrorHandling(message = "Enrichment failed"),
        	responseSerializer = .responseSerializers$JSON
        )
        
      	jobState = .jobStateFromJson(res)
      	enrichJobId = jobState$jobId
      	total = nrow(data)
      	enrichmentJob = EnrichmentJob$new(enrichJobId, totalRows = total)
      	quoted = function(str) paste0('"', str, '"')
      	message(paste("Enrich job ID is:", enrichJobId))
      	message(paste0("You can get back to following this enrichment job by running: ", 
      								 "EnrichmentJob$new(jobId=", quoted(enrichJobId), ")"))
      	
      	if (runBlocking) {
      		unusedRefToData = enrichmentJob$data(localFileName = outputName)
      	}
      	
      	enrichmentJob
      },

			################################## predict #####################
      predict = function(data, contextDatasets = NULL, includeOriginals = FALSE, includeEnriched = FALSE, includeExplanations = FALSE, columnsWhiteList = NA, outputName = "predicted", runBlocking = TRUE, linesForContextMatchReport = NA_integer_, ...) {
        "Returns prediction on a created model.
        \\code{data} is a dataframe to be predicted. contextDatasets - list of contexts with context information unique to the prediction (see more information in learn()).
        \\code{includeOriginals} - set to TRUE to include the original columns in the result.
        \\code{includeEnriched} - set to TRUE to include the enriched columns in the result.
        \\code{includeExplanations} - set to TRUE to include prediction explanations
        \\code{columnsWhiteList} - specify the original columns to be included in the result (\\code{includeOriginals} is required to be TRUE),
      	\\code{outputName} - set to change the default result file name,
      	\\code{linesForContextMatchReport} - number of rows to use for context match report, the default is 50000"

        extraParams = list(...)
        # Experimental, not documented flag
        includeTyperErrorReport = if (!is.null(extraParams$includeTyperErrorReport)) {
        	includeTyperErrorReport = extraParams$includeTyperErrorReport
        	extraParams = extraParams[names(extraParams) != "includeTyperErrorReport"]
        	includeTyperErrorReport
        } else {
        	NULL
        }
        
        if (length(extraParams) > 0) {
        	warning("Unexpected parameters were passed to enrich function: ", paste(extraParams, collapse = ", "))
        }
        
        input = .handleData(data = data, projectName = projectName, name = "predict")

        contextDatasets = .handleContexts(contextDatasets, projectName = projectName)

        params <- list(projectName = projectName,
        							revision = revision,
        							includeOriginals = includeOriginals, # From 1.10
        							includeEnriched = includeEnriched, # From 1.10
        							includeExplanations = includeExplanations,
        							columnsWhiteList = columnsWhiteList,
        							fileEscaping = FALSE,
        							contextDatasets = contextDatasets,
        							linesForContextMatchReport = linesForContextMatchReport,
        							includeTyperErrorReport = includeTyperErrorReport
        							)        							
        params = params[!is.na(params)]
        
      	params$input = input
      	message(paste("Predicting ",params$input$name))
        
        url <- paste0(getSBserverURL(),"/api/predict")
        message(paste("Calling:", url))

        body = rjson::toJSON(params)
        res = .executeRequest(
        	function() httr::POST(url, body = body, httr::content_type_json()),
        	errorHandling = .withErrorHandling(message = "Prediction failed"),
        	responseSerializer = .responseSerializers$JSON
        )
        
      
      	jobState = .jobStateFromJson(res)
      	predictJobId = jobState$jobId
      	total = nrow(data)
      	predictionJob = PredictionJob$new(predictJobId, totalRows = total)
      	quoted = function(str) paste0('"', str, '"')
      	message(paste("Predict job ID is:", predictJobId))
      	message(paste0("You can get back to following this prediction job by running: ", 
      								 "PredictionJob$new(jobId=", quoted(predictJobId), ")"))
      	
      	if (runBlocking) {
      		unusedRefToData = predictionJob$data(localFileName = outputName)
      	}
      	
      	predictionJob
      },

      ################################## relearn #####################
		relearnWithNewInputs = function(inputs, targetProject=NULL, showWebView=TRUE, runBlocking=TRUE) {
        "Start a new learning process base on this learning session with new input sources.
        \\code{inputs} - named list containing of the new input sources. Names are the names of the inputs from the original pipeline, as they appear in the web view, values are data frames containing the new inputs data.
        \\code{targetProject} - Name of the project to execute the learning in. If not specified, the learning will run in the same project as the original pipeline.
        \\code{showWebView} - control for whether to show a dynamic web view of the analysis in a browser. TRUE by default.
        \\code{runBlocking} - runBlocking: Block the R console while the session is running. FALSE by default."
			inputsOnServer = lapply(inputs, function(df) .handleData(data = df, projectName = ifelse(!is.null(targetProject), targetProject, projectName), name = "input"))	
				
        relearnSession = .runPipeline(projectName, inputsOnServer, revision, targetProject)
        
        if (showWebView) relearnSession$webView() 
        if (runBlocking) relearnSession$waitForProcess()
        
        relearnSession
      },

      ################################## evaluate #####################
      evaluate = function() {
        "Returns an evaluation object containing various information on the run including evaluation metric that was used, evaluation score, precision, confusion matrix, number of correct and incorrect instances, AUC information and more."
       	finalEvaluation = .getNotificationLogReport(projectName, revision, path = "/json/evaluation.json")
        
        if (finalEvaluation$isRegression) {
        	writeLines(finalEvaluation$evaluation$summary)
        } else {
        	writeLines(finalEvaluation$evaluation$classDetails)
        }
        
        finalEvaluation
      },

      features = function() {
        "Returns a dataset with top feature information"
      	.getNotificationLogReport(projectName, revision, path = "/reports/features/train_features.tsv", responseSerializer = .responseSerializers$DATA_FRAME, onError = .onErrorBehavior$SILENT)
      },

      showReport = function(report_name = NA){ #confine to a specific list
        "\\code{report_name} name of report to show"        
        .showReport(report_name, projectName, revision)
      },
      showContextObjects = function() {
        "Shows context objects report."
        showReport("features/contextObjects.html")
      },
      showFeaturesTrain = function() {
        "Shows features performance on train."
        showReport("features/train_features.html")
      },
      showFeaturesTest = function() {
        "Shows features performance on test."
        showReport("features/test_features.html")
      },
      showFeatureStability = function() {
        "Shows features stability report."
        showReport("features/featureStability.html")
      },
      #require model methods
      showConfusionMatrix = function(normalized = FALSE) { #verify that this was a classification problem
        "Shows a confusion matrix of a model."
        showReport(if (normalized) "model/confusionMatrix_normalized.html" else "model/confusionMatrix.html")
      },
      showModelComparison = function() {
        "Shows cross validation of various algorithms tested to create a model."
        showReport("model/modelComparison.html")
      },
      showFeatureClusters = function() {
        "Shows the representative feature clusters pdf report."
				showReport("/features/featureClusters/clusteringOfAllFeatures.pdf")
      },
			reports = function() {	
				"Shows all reports applicable for the current analysis."
				url = paste0(getSBserverURL(),"/analytics/reportStructure/", projectName,"/",revision)
				res = .executeRequest(
					function() httr::GET(url),
					responseSerializer = .responseSerializers$JSON
				)
				
				reportList = unlist(res)
				names(reportList) = NULL
				reportListWithIndex = cbind(paste0("[",1:length(reportList),"]"), reportList)
				reportListWithIndex = apply(reportListWithIndex,1,paste, collapse = " ")
				writeLines(paste(unlist(reportListWithIndex), collapse = "\n"))
				n <- readline("enter a number of report to show or <enter> otherwise:")
				n <- ifelse(grepl("\\D",n),-1,as.integer(n))
				if (!is.na(n) && n >= 1 && n <= length(reportList)) {
					message(paste("showing",n))
					showReport(reportList[n])
				}										
				reportList
			},
			exportModel = function(includeContexts = TRUE) {
				"Export model for prediction box. If prediction requires to supply ALL new contexts and no original contexts are needed, download of the contexts can be skipped be setting \\code{includeContexts} to FALSE"
				extcodeFile = if (.isServerVersionOlderThan(1.17))
				{
					"extcode.dat"
				}
				else
				{
					"extcode.ser"
				}
				featureExtractorUrl = paste0(getSBserverURL(), "/analytics/rawFile/", projectName,"/",revision,"/", extcodeFile)
				path = .download(url = featureExtractorUrl, localFile = extcodeFile, description = "feature extractor")
				message(paste("Successfully exported feature extractor to:", path))
				
				modelUrl = paste0(getSBserverURL(), "/analytics/rawFile/", projectName,"/",revision,"/model.ser")
				path = .download(url = modelUrl, localFile = "model.ser", description = "model")
				message(paste("Successfully exported model to:", path))
				
				if (includeContexts) {
					contextsUrl = paste0(getSBserverURL(), "/api2/downloadContexts/", projectName,"/",revision)
					path = .download(url = contextsUrl, description = "contexts")
					message(paste("Successfully exported contexts to:", path))
				}
			},
			exportModelToPredictionBox = function(predictionBoxUrl, authKey = "", uploadContexts = TRUE,
																						overwriteExisting = TRUE, overrideTargetGroupName = NULL) {
				"Export model directly to prediction box. predictionBoxUrl - prediction box URL, authKey - prediction box authentication key, overwriteExisting - override existing model, overrideTargetGroupName - save the model under a different name in porediction box (by default project name is used as model identifier)"
				.exportModelToPredictionBox(project = projectName, revision = revision, 
																		predictionBoxUrl = predictionBoxUrl, authKey = authKey, 
																		uploadContexts = uploadContexts,
																		overwriteExisting = overwriteExisting, overrideTargetGroupName = overrideTargetGroupName)
			},
			webView = function(show=TRUE){
				"Show a dynamic web view of the analysis."
				suppressWarnings({
					url <- paste0(getSBserverURL(),paste0("/getToken"))
					token = .executeRequest(
						function() httr::GET(url),
						responseSerializer = .responseSerializers$TEXT
					)
					htmlSource = paste0(getSBserverURL(), "/?token=", token,"#/visualPipeline/", projectName, "/", revision)
					if (show == T) browseURL(htmlSource)
					htmlSource
				})
			},
			revisions = function(){
				"Show previous revisions of a project."
				projectRevisions(projectName = projectName)
			},
			cancel = function(){
				"Cancel a queued / running job of this model"
				cancelJob(jobId = jobId)
			},
		################################## Typing #####################
		getSchema = function() {
			"Get the schema of inputs used in a model.
			Schema example: list(input1=list(col1=\"String\", col2=\"Int\"), input2=...).
			Input name can be used to perform the type checks by calling the \\code{checkTypes} method."
			if (length(schema) == 0) {
				url <- paste0(getSBserverURL(), "/analytics/modelInputSchema/", projectName, "/", revision)
				res = .executeRequest(
					function() httr::GET(url),
					errorHandling = .withErrorHandling(message = "Failed to get typing"),
					responseSerializer = .responseSerializers$JSON
				)
				schema <<- res[names(res) %in% c('inputs', 'contextInputs')]
			}
			
			lapply(schema, 
						 function(inputType) lapply(inputType, 
						 													 function(input) lapply(input, 
						 													 											 function(column) {
							 													 											 	column$unquote <- NULL
							 													 											 	column$trim <- NULL
							 													 											 	column$rawDefaultValue <- NULL
							 													 											 	column$type <- sub("Typer","",tail(unlist(strsplit(column$jsonClass, ".", fixed = T)), n = 1))
							 													 											 	column$jsonClass <- NULL
							 													 											 	if (is.list(column$defaultValue)) {
							 													 											 		column$defaultValue <- unlist(column$defaultValue)
							 													 											 		names(column$defaultValue) <- NULL
							 													 											 	}
							 													 											 	column
						 													 											 })))
		},
		checkTypes = function(inputName, data, fileEscaping = NULL, fileEncoding = NULL, takeRows = 10000, examplesPerColumn = NULL) {
			"Check types for a new data of a specific input.
			\\code{inputName} is the input which will use for typing.
			\\code{data} is the new dataframe.
			\\code{fileEscaping} a boolean value indicating if the data should be escaped. Default TRUE.
			\\code{fileEncoding} a string indicating of the data encoding to use. Default NULL.
			\\code{takeRows} number of rows to send to the server for type check. Default 10000.
			\\code{examplesPerColumn} number of examples to generate per column. Default 3."
			
			getSchema()
			fullSchema <- schema
			typers = if (inputName %in% names(fullSchema$inputs)) {
				fullSchema$inputs[[inputName]]
			} else if (inputName %in% names(fullSchema$contextInputs)) {
				fullSchema$contextInputs[[inputName]]
			} else{
				msg <- paste("Provided input name could not be found in input schema, avilable names are: ", paste(unique(unlist(lapply(schema,names))), collapse = ", "))
				stop(msg)
			}
			
			uploadedData = if (!is.null(takeRows) && nrow(data) > takeRows) {
				uploadedData <- head(data, takeRows)
			} else {
				data
			}
			
			params <- list(projectName = projectName,
										revision = revision,
										typers = typers,
										takeRows = takeRows,
										examplesPerColumn = examplesPerColumn
			)
			
			params$input = .handleData(data = uploadedData, projectName = projectName, name = "checkTypes")
			url <- paste0(getSBserverURL(), "/api/blockingTyperErrorReport")
			body = rjson::toJSON(params)
			res = .executeRequest(
				function() httr::POST(url, body = body, httr::content_type_json()),
				errorHandling = .withErrorHandling(message = "Check types failed"),
				responseSerializer = .responseSerializers$JSON
			)
			message("Total rows processed: ", res$rowsSeen)
			message("Rows with errors: ", res$rowsWithErrors)
			message("Percent of rows with errors: ", paste0(formatC(100 * (res$rowsWithErrors / res$rowsSeen)), "%"))
			.convertTyperErrorToDataFrame(res)
		}
  )
)