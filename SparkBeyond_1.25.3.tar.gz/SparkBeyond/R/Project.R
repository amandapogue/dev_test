#' getOrCreateProject
#'
#' Get or create a new project by name. In case the projec is created, the description, displayName,
#' and domain parameters are used.
#' @param projectName: String the project unique name.
#' @param description: Optional String, a description of the project. Only used upon project creation. Default value is empty string.
#' @param displayName: Optional String, a display name for the project, not unique. Only used upon project creation. Default value is empty string.
#' @param domain: Optional String, the domain to which the project related. Only used upon project creation. Default value is empty string.
getOrCreateProject = function(projecName, description = "", displayName = "", domain = NULL) {
	project = .getProject(projecName)
	if (is.null(project)) {
		project = .createProject(projecName, currentUserEmail(), description, displayName, domain)
	}
	project
}

#' getProjectRevisions
#'
#' Fetch a list of revisions under the project
#'
#' @param projectName the name of the project
#' @return A list of \code{\link{Revision}} instances. In case the project has no revisions, an empty list is returned.
getProjectRevisions = function(projectName) {
	revisions = .getProjectRevisions(projectName)

	if(length(revisions) == 0) {
		revisions
	}	else {
		res = c()
		for(i in 1:nrow(revisions)) # we cannot use `apply` here since revisions list is a nested DF
		{
			json = revisions[i,]
			rev = Revision$new(project = projectName)
			rev$fromJson(json)
			res = c(res, rev)
		}
		res
	}
}

#' The Project class represent a Discovery Platform project.
#'
#' @docType class
#' @keywords data
#' @return Object of \code{\link{R6Class}} with methods for Discovery Platform project managment.
#' @format \code{\link{R6Class}} object.
#' @examples
#' Project$new()
#' @field name A unique project name.
#' @field displayName A pretty name for display on the Discovery Platform.
#' @field domain The domain to which the project belongs.
#' @field description A description of the project purpose.
#' @section Methods:
#' \describe{
#'   \item{\code{toJson()}}{Json representation of the current project instance.}
#'   \item{\code{fromJson(projectJson)}}{Set the current project instance fields with the values from the json.}
#'   \item{\code{uploadData(data, name)}}{Upload data to the project.}
#'   \item{\code{getUploadedData()}}{Return a list of data frames uploaded to the server.}
#'   \item{\code{draft()}}{Return a local workspace, where the user can set up the pipeline and initiate Learning.}
#'
Project <- R6::R6Class(
	"Project",
	public = list(
		name = NULL,
		displayName = NULL,
		domain = NULL,
		description = NULL,

		initialize = function() {
		},
		toJson = function() {
			sprintf(
				'{
				"name": %s,
				"displayName": %s,
				"domain": %s,
				"description": %s
				}',
        self$name,
				self$displayName,
				self$domain,
				self$description)
		},

		fromJsonString = function(json) {
			projectJsonObject <- jsonlite::fromJSON(json)
			self$fromJson(projectJsonObject)
		},

		fromJson = function(projectJsonObject) {
			self$name = projectJsonObject$name
			self$displayName = projectJsonObject$displayName
			self$domain = projectJsonObject$domain
			self$description = projectJsonObject$description
		},

		uploadData = function(data, name = "Dataset") {
		  fileReference = uploadToServer(data, self$name, name)
		  Dataset$new(fileReference = fileReference, project = self$name)
		},

		getUploadedData = function(){
			getProjectDatasets(self$name)
		},

		getRevisions = function() {
			getProjectRevisions(self$name)
		},

		draft = function() {
		  Revision$new(project = self$name)
		}
	)
)

#' SparkBeyond Revision instance.
#'
#' @docType class
#' @keywords data
#' @return Object of \code{\link{R6Class}} with methods for Discovery Platform revision.
#' @format \code{\link{R6Class}} object.
#' @field project Project name.
#' @field revisionId Revision number.
#' @field state Learning status.
#' @field isChampion Whether this revision's score is the highest.
#' @field learningResult Revision learning job result.
#' @field trainData Train dataset.
#' @field testData Test dataset.
#' @field contexts Contexts list.
#' @section Methods:
#' \describe{
#'   \item{\code{fromJson(projectJson)}}{Set the current revision instance fields with the values from the json.}
#'   \item{\code{setTrainData(dataset)}}{Set the current draft train data.}
#'   \item{\code{setTestData(dataset)}}{Set the current draft test data.}
#'   \item{\code{addContextData(dataset)}}{Add context}
#'   \item{\code{learn(target,problemDefinition,preProcessing, featureGeneration,knowledge, modelBuilding,reporting,runBlocking,revisionDescription,learningMode,parentRevision)}}{Start a new learning process}
Revision <- R6::R6Class(
	"Revision",
	public = list(
		project = NULL,
		revisionId = NULL,
		state = NULL,
		isChampion = NULL,
		learningResult = NULL,
		trainData = NULL,
		testData = NULL,
		contexts = list(),
		initialize = function(project) {
			warning("The Revision class is in Beta, it is expected to change in future releases.")
		  self$project = project
		},
		fromJson = function(json) {
		  self$project = json$projectName
		  self$revisionId = json$id
		  self$state = json$learningState
		  self$isChampion = json$isChampion
		  self$learningResult = json$learningResult
		},
		setTrainData = function(dataset){
		  self$trainData = dataset
		},
		setTestData = function(dataset){
		  self$testData = dataset
		},
		addContextData = function(context){
		  self$contexts <- append(self$contexts, list(context))
		},
		learn = function(target,
		                 problemDefinition = problemDefinitionControl(),
		                 preProcessing = preProcessingControl(),
		                 featureGeneration = featureGenerationControl(),
		                 knowledge = knowledgeControl(),
		                 modelBuilding = modelBuildingControl(),
		                 reporting = reportingControl(),
		                 runBlocking = TRUE,
		                 revisionDescription = "",
		                 learningMode = NA,
		                 parentRevision = NA){
		  learn(projectName = self$project,
		        target = target,
		        trainData = self$trainData,
		        testData = self$testData,
		        contextDatasets = self$contexts,
		        problemDefinition = problemDefinition,
		        preProcessing = preProcessing,
		        featureGeneration = featureGeneration,
		        knowledge = knowledge,
		        modelBuilding = modelBuilding,
		        reporting = reporting,
		        runBlocking = runBlocking,
		        revisionDescription = revisionDescription,
		        learningMode = learningMode,
		        parentRevision = parentRevision)
		}
	)
)
