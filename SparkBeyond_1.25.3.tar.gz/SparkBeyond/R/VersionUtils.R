.isServerVersionOlderThan = function(version) {
	SBServerVersion < version
}

.clientVersion = function() {
	utils::packageVersion('SparkBeyond')
}

.toMajorMinorVersion = function(fullVersion) {
	fullPackageVersion <- if (is.character(fullVersion)) {
		package_version(fullVersion)
	} else {
		fullVersion
	}
	
	package_version(paste(fullPackageVersion$major, fullPackageVersion$minor, sep = '.'))
}

# returns version in major.minor format
.minimumSupportedServerVersion = function(clientVersion) {
	majorMinorClientVersion = .toMajorMinorVersion(clientVersion)
	minimumSupportedServerVersion = majorMinorClientVersion
	minimumSupportedServerVersion[1, 2] = majorMinorClientVersion$minor - 1
	minimumSupportedServerVersion
}

# returns version in major.minor format
.maximumSupportedServerVersion = function(clientVersion) {
	.toMajorMinorVersion(clientVersion)
}

.assertClientServerVersionCompatibility = function(clientVersion, serverVersion) {
	majorMinorClientVersion = .toMajorMinorVersion(clientVersion)
	majorMinorServerVersion = .toMajorMinorVersion(serverVersion)
	
	if (majorMinorClientVersion == majorMinorServerVersion) {
		# Ideal situation
	} else if (majorMinorServerVersion < .minimumSupportedServerVersion(clientVersion)) {
		stop(paste0("This client release (", clientVersion, ") supports server release ", .minimumSupportedServerVersion(clientVersion), " or higher. The server you are connecting to is of release ", serverVersion, ". Please contact your system administrator to get the server upgraded."))
	} else if (majorMinorServerVersion > .maximumSupportedServerVersion(clientVersion)) {
		stop(paste0("This client release (", clientVersion, ") supports server release ", .minimumSupportedServerVersion(clientVersion), "-", .maximumSupportedServerVersion(clientVersion),
								". The server you are connecting to is of release ", serverVersion, ". Please update your client by calling updatePackage()."))
	} else if (majorMinorClientVersion > majorMinorServerVersion) {
		warning(paste0("A newer server release (", majorMinorClientVersion, ") is available. Please note that this client release (", clientVersion, ") supports server release which you are connected to  (", serverVersion, "), but will not support new capabilities added in ", majorMinorClientVersion, "."))
	}
}

.assertServerVersionCompatibility = function() {
	.assertClientServerVersionCompatibility(.clientVersion(), SBServerVersion)
}

# Format the deprecation message
# 
# old - name of the old function/class that is deprecated.
# new (Optional) - name of the new function/class that is reccomended as a replacement
# version - version in which function/class was deprecated
.deprecationMessage = function(old, new=NULL, version) {
	message = paste0("'", old, "' is deprecated starting from version ", version, ".")
	if (!is.null(new)) {
		message = paste0(message, "\nUse '", new, "' instead.")
	}
	message
}
