#' All supported algorithms
#' @usage 
#' algorithms$scikit$RandomForest
#' algorithms$R$RXGBoost
#' @examples
#' \donttest{
#' model = learn(projectName = "my_project",
#'               trainData = trainData,
#'               target = "result",
#'               modelBuilding = modelBuildingControl(algorithmsWhiteList = list(algorithms$R$RXGBoost)))
#' }

algorithms = list(
	
		Weka = list(
			BayesianLogisticRegression = "weka.classifiers.bayes.BayesianLogisticRegression",
			BayesNet = "weka.classifiers.bayes.BayesNet",
			NaiveBayes = "weka.classifiers.bayes.NaiveBayes",
			LeastMedSq = "weka.classifiers.functions.LeastMedSq",
			LibLINEAR = "weka.classifiers.functions.LibLINEAR",
			LibSVM = "weka.classifiers.functions.LibSVM",
			LinearRegression = "weka.classifiers.functions.LinearRegression",
			Logistic = "weka.classifiers.functions.Logistic",
			SMO = "weka.classifiers.functions.SMO",
			SMOreg = "weka.classifiers.functions.SMOreg",
			VotedPerceptron = "weka.classifiers.functions.VotedPerceptron",
			IBk = "weka.classifiers.lazy.IBk",
			AdaBoostM1 = "weka.classifiers.meta.AdaBoostM1",
			Bagging = "weka.classifiers.meta.Bagging",
			ClassificationViaClustering = "weka.classifiers.meta.ClassificationViaClustering",
			ClassificationViaRegression = "weka.classifiers.meta.ClassificationViaRegression",
			Decorate = "weka.classifiers.meta.Decorate",
			LogitBoost = "weka.classifiers.meta.LogitBoost",
			RandomSubSpace = "weka.classifiers.meta.RandomSubSpace",
			RegressionByDiscretization = "weka.classifiers.meta.RegressionByDiscretization",
			DecisionTable = "weka.classifiers.rules.DecisionTable",
			ZeroR = "weka.classifiers.rules.ZeroR",
			RandomForest = "weka.classifiers.trees.RandomForest",
			REPTree = "weka.classifiers.trees.REPTree",
			J48 = "J48"
		),

		scikit = list(
			AdaBoost = "SciKitLearnAdaBoost",
			Bagging = "SciKitLearnBagging",
			DecisionTree = "SciKitLearnDecisionTree",
			ElasticNet = "SciKitLearnElasticNet",
			ElasticNetCVRegressor = "SciKitLearnElasticNetCVRegressor",
			GradientBoosting = "SciKitLearnGradientBoosting",
			Lasso = "SciKitLearnLasso",
			LassoCV = "SciKitLearnLassoCV",
			LassoLarsCV = "SciKitLearnLassoLarsCV",
			LinearRegression = "SciKitLearnLinearRegression",
			LogisticRegressionClassifier = "SciKitLearnLogisticRegressionClassifier",
			LogisticRegressionCVClassifier = "SciKitLearnLogisticRegressionCVClassifier",
			NuSVMRegressor = "SciKitLearnNuSVMRegressor",
			RandomForest = "SciKitLearnRandomForest",
			Ridge = "SciKitLearnRidge",
			SGD = "SciKitLearnSGD",
			SVM = "SciKitLearnSVM",
			XGBoost = "SciKitLearnXGBoost",
			LightGBM = "LightGBM",
			KerasDeepLearning = "KerasDeepLearning"
		),

        statsmodels = list(
            GLM = "StatsModelsGLM",
			GLMRegularized = "StatsModelsGLMRegularized"
        ),

		R = list(
			RCaretGBM = "RCaretGBM",
			RLassoGlmNet = "RLassoGlmNet",
			RRandomForest = "RRandomForest",
			RRidgeGlmNet = "RRidgeGlmNet",
			RRpartDecisionTree = "RRpartDecisionTree",
			RXGBoost = "RXGBoost"
		),

		MLlib = list(
			MLlibDecisionTree = "MLlibDecisionTree",
			MLlibGBTRegressor = "MLlibGBTRegressor",
			MLlibLinearModel = "MLlibLinearModel",
			MLlibRandomForest = "MLlibRandomForest"
		),
		
		ZeroR="ZeroR",
		
		Ensembles = list(
			BoundedStackXGBoostLinearRegression = "BoundedStack(XGBoost,LinearRegression)",
			StackXGBoostLinearRegression = "Stack(XGBoost,LinearRegression)",
			BoundedSortedStackXGBoostLinearRegression = "BoundedSortedStack(XGBoost,LinearRegression)",
			SortedStackXGBoostLinearRegression = "SortedStack(XGBoost,LinearRegression)"
		)
)

