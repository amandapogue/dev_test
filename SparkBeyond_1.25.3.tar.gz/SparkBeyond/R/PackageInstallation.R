
.install = function(url=NULL) {
	
	validateServerURL = function(url) {
		heartbeatUrl <- paste0(url, "/api/heartbeat")
		tryCatch ({
			response = httr::GET(heartbeatUrl, httr::content_type_json())
			if(httr::status_code(response) != 200 || httr::content(response) != "ALIVE") {
				stop("Couldn't connect to the server, please verify that server url ", url, " is correct")
			} 
		}, error = function(e) {
			stop("Couldn't connect to the server: ", e$message, ". Please verify that server url ", url, " is correct")
		})
	}
	
	downloadPackage = function(url, localPath) {
		download_url = paste(url, 'sdk/r', sep = '/')
		
		message(paste("Downloading the R SDK package from:", download_url))
		
		response = httr::GET(download_url, config = httr::progress(type = "down"), httr::write_disk(localPath, overwrite = TRUE))
		status = httr::status_code(response) 
		if(status == 200) {
			if ('content-disposition' %in% names(httr::headers(response)) && grepl('SparkBeyond', httr::headers(response)$'content-disposition')) {
				message("Successfully downloaded the package")
			} else {
				 stop("Failed to download the package: unexpected content type")
			}
		} else {
			stop(paste0("Failed to download the package from: ", download_url, ", response status: ", status, ", error: ", httr::content(response, as = "text")))
		}
	}

	url <- if(!is.null(url)) {
		url
	} else if (exists("SBdomain") && !is.null(SBdomain)) {
		SBdomain
	} else {
		enteredURL = readline(prompt="Enter your server url: ")
		if (is.null(enteredURL)) {
			stop("No url was entered")
		}
		enteredURL
	}
	
	# Remove the last slash if needed
	if(substr(url, nchar(url), nchar(url)) == "/") {
		url = substr(url, 1, nchar(url)-1)
	}
	
	if (!require("devtools", quietly = TRUE)) install.packages("devtools")
	
	httr::set_config(httr::config(ssl_verifypeer = 0L, ssl_verifyhost = 0L))
	
	validateServerURL(url)
	
	baseTempDir = tempdir()
	tempFilePath = paste(baseTempDir, "SparkBeyond.tar.gz", sep='/')
	tempExtractedFolderPath = paste(baseTempDir, "SparkBeyond", sep='/')
	
	if(file.exists(tempFilePath)) file.remove(tempFilePath)
	unlink(tempExtractedFolderPath, recursive = TRUE)
	
	downloadPackage(url, tempFilePath)
	
	if(.Platform$OS.type == "windows") {
		untar(tempFilePath, exdir = baseTempDir, extras = '--force-local')
	} else {
		untar(tempFilePath, exdir = baseTempDir)
	}
	
	message("Installing the package")
	tryCatch(
		devtools::install_local(tempExtractedFolderPath),
		error = function(e) {
			if("simpleError" %in% class(e) && grepl("argument", e$message) && grepl("quiet", e$message) && grepl("missing", e$message)) {
				# Devtools bug
				warning("
  Installation failed due to a known bug in some versions of devtools package. 
  To fix it please remove the devtools package by executing 'remove.packages(\"devtools\")', 
  then restart the R session and execute the installation script.
  If the issue persists, please contact support.")
			}
			stop(e)
		}
	)
}

.createStandaloneInstaller = function(path='installer.R') {
	installFunctionName = deparse(substitute(.install))
	installFunctionExecution = paste0("\n\n", installFunctionName, "()\n")
	
	dump(installFunctionName, file=path)
	
	sink(file = path, append = TRUE)
	cat(installFunctionExecution)
	sink()
}
